package org.xms.g.maps;




/**
 * xms A View which displays a Street View panorama(with data obtained from the Maps service).<br/>
 * Wrapper class for com.huawei.hms.maps.StreetViewPanoramaView, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.StreetViewPanoramaView: A View which displays a Street View panorama(with data obtained from the Huawei Maps service).<br/>
 */
public class StreetViewPanoramaView extends android.widget.FrameLayout implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    private boolean wrapper = true;
    
    
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context) A View which displays a Street View panorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context)
     *
     * @param param0 the param should instanceof android content Context
     */
    public StreetViewPanoramaView(android.content.Context param0) {
        super(param0);
        this.setHInstance(new HImpl(param0));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,android.util.AttributeSet) A View which displays a Street View panorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,android.util.AttributeSet)
     *
     * @param param0 the param should instanceof android content Context
     * @param param1 the param should instanceof android util AttributeSet
     */
    public StreetViewPanoramaView(android.content.Context param0, android.util.AttributeSet param1) {
        super(param0, param1);
        this.setHInstance(new HImpl(param0, param1));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,android.util.AttributeSet,int) A View which displays a Street View panorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,android.util.AttributeSet,int)
     *
     * @param param0 the param should instanceof android content Context
     * @param param1 the param should instanceof android util AttributeSet
     * @param param2 the param should instanceof int
     */
    public StreetViewPanoramaView(android.content.Context param0, android.util.AttributeSet param1, int param2) {
        super(param0, param1, param2);
        this.setHInstance(new HImpl(param0, param1, param2));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,org.xms.g.maps.StreetViewPanoramaOptions) A View which displays a Street View panorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.StreetViewPanoramaView(android.content.Context,com.huawei.hms.maps.StreetViewPanoramaOptions)
     *
     * @param param0 the param should instanceof android content Context
     * @param param1 the param should instanceof maps StreetViewPanoramaOptions
     */
    public StreetViewPanoramaView(android.content.Context param0, org.xms.g.maps.StreetViewPanoramaOptions param1) {
        super(param0);
        this.setHInstance(new HImpl(param0, ((com.huawei.hms.maps.StreetViewPanoramaOptions) ((param1) == null ? null : (param1.getHInstance())))));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.getStreetViewPanoramaAsync(org.xms.g.maps.OnStreetViewPanoramaReadyCallback) Sets a callback object which will be triggered when the StreetViewPanorama instance is ready to be used.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.getStreetViewPanoramaAsync(com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback)
     *
     * @param param0 The callback object that will be triggered when the panorama is ready to be used
     */
    public void getStreetViewPanoramaAsync(org.xms.g.maps.OnStreetViewPanoramaReadyCallback param0) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).getStreetViewPanoramaAsync(((param0) == null ? null : (param0.getHInstanceOnStreetViewPanoramaReadyCallback())))");
            ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).getStreetViewPanoramaAsync(((param0) == null ? null : (param0.getHInstanceOnStreetViewPanoramaReadyCallback())));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance())).getStreetViewPanoramaAsyncCallSuper(((param0) == null ? null : (param0.getHInstanceOnStreetViewPanoramaReadyCallback())))");
            ((HImpl) ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance())).getStreetViewPanoramaAsyncCallSuper(((param0) == null ? null : (param0.getHInstanceOnStreetViewPanoramaReadyCallback())));
        }
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onCreate(android.os.Bundle) You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onCreate(android.os.Bundle)
     *
     * @param param0 the param should instanceof android os Bundle
     */
    public final void onCreate(android.os.Bundle param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onCreate(param0)");
        ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onCreate(param0);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onDestroy() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onDestroy()
     *
     */
    public void onDestroy() {
        if (wrapper) {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onDestroy()");
                ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onDestroy();
        } else {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onDestroy()");
                ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onDestroy();
        }
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onLowMemory() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onLowMemory()
     *
     */
    public final void onLowMemory() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onLowMemory()");
        ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onLowMemory();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onPause() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onPause()
     *
     */
    public final void onPause() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onPause()");
        ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onPause();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onResume() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onResume()
     *
     */
    public void onResume() {
        if (wrapper) {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onResume()");
                ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onResume();
        } else {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onResume()");
                ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onResume();
        }
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onSaveInstanceState(android.os.Bundle) You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaView.onSaveInstanceState(android.os.Bundle)
     *
     * @param param0 the param should instanceof android os Bundle
     */
    public final void onSaveInstanceState(android.os.Bundle param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onSaveInstanceState(param0)");
        ((com.huawei.hms.maps.StreetViewPanoramaView) this.getHInstance()).onSaveInstanceState(param0);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onStart() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     *
     */
    public void onStart() {
        if (wrapper) {
            
            return;
        } else {
            
            return;
        }
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.onStop() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     *
     */
    public void onStop() {
        if (wrapper) {
            
            return;
        } else {
            
            return;
        }
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.setHInstance(java.lang.Object) set HInstance.<br/>
     *
     * @param param0 the param should be instanceof java lang Object
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
        this.removeAllViews();
        this.addView(((com.huawei.hms.maps.StreetViewPanoramaView) hInstance));
        this.setClickable(true);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the return obejct is hInstance
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.StreetViewPanoramaView.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps StreetViewPanoramaView object
     */
    public static org.xms.g.maps.StreetViewPanoramaView dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.StreetViewPanoramaView) param0);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.StreetViewPanoramaView;
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaView.wrapInst(org.xms.g.utils.XBox) wrapInst.<br/>
     *
     * @param param0 the param should instanceof utils XBox
     * @return the return object is maps StreetViewPanoramaView
     */
    public org.xms.g.maps.StreetViewPanoramaView wrapInst(org.xms.g.utils.XBox param0) {
        hInstance = param0.getHInstance();
        wrapper = true;
        return this;
    }
    
    private class HImpl extends com.huawei.hms.maps.StreetViewPanoramaView {
        
        
        
        public void getStreetViewPanoramaAsync(com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback param0) {
            org.xms.g.maps.StreetViewPanoramaView.this.getStreetViewPanoramaAsync(((param0) == null ? null : (new org.xms.g.maps.OnStreetViewPanoramaReadyCallback.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void getStreetViewPanoramaAsyncCallSuper(com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback param0) {
            super.getStreetViewPanoramaAsync(param0);
        }
        
        public HImpl(android.content.Context param0) {
            super(param0);
        }
        
        public HImpl(android.content.Context param0, android.util.AttributeSet param1) {
            super(param0, param1);
        }
        
        public HImpl(android.content.Context param0, android.util.AttributeSet param1, int param2) {
            super(param0, param1, param2);
        }
        
        public HImpl(android.content.Context param0, com.huawei.hms.maps.StreetViewPanoramaOptions param1) {
            super(param0, param1);
        }
    }
}