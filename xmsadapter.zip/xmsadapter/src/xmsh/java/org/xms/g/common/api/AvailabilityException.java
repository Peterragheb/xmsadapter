package org.xms.g.common.api;

/**
 * Contains the result of an availability check for one or more Apis.<br/>
 * Wrapper class for com.huawei.hms.common.api.AvailabilityException, but only the HMS API are provided.<br/>
 * com.huawei.hms.common.api.AvailabilityException: <br/>
 */
public class AvailabilityException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.common.api.AvailabilityException.AvailabilityException(org.xms.g.utils.XBox) constructor of AvailabilityException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AvailabilityException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public org.xms.g.common.ConnectionResult getConnectionResult(org.xms.g.common.api.ExtensionApi<? extends org.xms.g.common.api.Api.ApiOptions> param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.AvailabilityException.getMessage() Lists the ConnectionResult per API.<br/>
     * com.huawei.hms.common.api.AvailabilityException.getMessage()
     *
     * @return Lists the ConnectionResult per API
     */
    public java.lang.String getMessage() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.AvailabilityException) this.getHInstance()).getMessage()");
        return ((com.huawei.hms.common.api.AvailabilityException) this.getHInstance()).getMessage();
    }
    
    /**
     * org.xms.g.common.api.AvailabilityException.setHInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 Instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.common.api.AvailabilityException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return Instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.common.api.AvailabilityException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.AvailabilityException.<br/>
     *
     * @param param0 the input object
     * @return casted AvailabilityException object
     */
    public static org.xms.g.common.api.AvailabilityException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.AvailabilityException) param0);
    }
    
    /**
     * org.xms.g.common.api.AvailabilityException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.common.api.AvailabilityException;
    }
}