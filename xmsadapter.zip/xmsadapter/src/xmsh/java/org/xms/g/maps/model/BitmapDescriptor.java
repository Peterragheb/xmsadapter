package org.xms.g.maps.model;

/**
 * xms Defines a Bitmap image.<br/>
 * Wrapper class for com.huawei.hms.maps.model.BitmapDescriptor, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.BitmapDescriptor: Defines a bitmap image. You can obtain a BitmapDescriptor using BitmapDescriptorFactory. A bitmap image can be used for a marker icon or ground overlay.<br/>
 */
public final class BitmapDescriptor extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.BitmapDescriptor.BitmapDescriptor(org.xms.g.utils.XBox) Defines a Bitmap image.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptor.BitmapDescriptor(): <a href="https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/bitmapdescriptor-0000001050152403-V5">https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/bitmapdescriptor-0000001050152403-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public BitmapDescriptor(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptor.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.BitmapDescriptor.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model BitmapDescriptor object
     */
    public static org.xms.g.maps.model.BitmapDescriptor dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.BitmapDescriptor) param0);
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptor.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.BitmapDescriptor;
    }
}