package org.xms.g.common.api;

/**
 * A Result with a boolean value.<br/>
 * Wrapper class for com.huawei.hms.common.api.BooleanResult, but only the HMS API are provided.<br/>
 * com.huawei.hms.common.api.BooleanResult: A Result with a boolean value.<br/>
 */
public class BooleanResult extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.common.api.BooleanResult.BooleanResult(org.xms.g.utils.XBox) constructor of BooleanResult with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public BooleanResult(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.equals(java.lang.Object) Checks whether two instances are equal.<br/>
     * com.huawei.hms.common.api.BooleanResult.equals(java.lang.Object)
     *
     * @param param0 the other BooleanResult Instance
     * @return True if two instances are equal
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.getStatus() Returns the status of this result.<br/>
     * com.huawei.hms.common.api.BooleanResult.getStatus()
     *
     * @return the status of this result
     */
    public org.xms.g.common.api.Status getStatus() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).getStatus()");
        com.huawei.hms.support.api.client.Status hReturn = ((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).getStatus();
        return ((hReturn) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.getValue() return the value of BooleanResult.<br/>
     * com.huawei.hms.common.api.BooleanResult.getValue()
     *
     * @return the boolean value of this result
     */
    public boolean getValue() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).getValue()");
        return ((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).getValue();
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.hashCode() Return a hash value of instance.<br/>
     * com.huawei.hms.common.api.BooleanResult.hashCode()
     *
     * @return a hash value
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.common.api.BooleanResult) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.BooleanResult.<br/>
     *
     * @param param0 the input object
     * @return casted BooleanResult object
     */
    public static org.xms.g.common.api.BooleanResult dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.BooleanResult) param0);
    }
    
    /**
     * org.xms.g.common.api.BooleanResult.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.common.api.BooleanResult;
    }
}