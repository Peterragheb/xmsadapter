package org.xms.g.maps.model;

/**
 * xms A Tile Overlay is a set of images which are displayed on top of the base map tiles.<br/>
 * Wrapper class for com.huawei.hms.maps.model.TileOverlay, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.TileOverlay: Represents a tile overlay. A tile overlay is a set of images to be displayed on a map. It can be transparent and enable you to add new functions to an existing map.<br/>
 */
public final class TileOverlay extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.TileOverlay.TileOverlay(org.xms.g.utils.XBox) A Tile Overlay is a set of images which are displayed on top of the base map tiles.<br/>
     * com.huawei.hms.maps.model.TileOverlay.TileOverlay(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlay-0000001050153293-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlay-0000001050153293-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public TileOverlay(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.clearTileCache() Clears the tile cache so that all tiles will be requested again from the TileProvider. The current tiles from this tile overlay will also be cleared from the map after calling this method. The API maintains a small in-memory cache of tiles. If you want to cache tiles for longer, you should implement an on-disk cache.<br/>
     * com.huawei.hms.maps.model.TileOverlay.clearTileCache(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#clearTileCache()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#clearTileCache()</a><br/>
     *
     */
    public final void clearTileCache() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).clearTileCache()");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).clearTileCache();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.equals(java.lang.Object) Tests if this TileOverlay is equal to another.<br/>
     * com.huawei.hms.maps.model.TileOverlay.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#equals(Object)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#equals(Object)</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getFadeIn() Gets whether the overlay tiles should fade in.<br/>
     * com.huawei.hms.maps.model.TileOverlay.getFadeIn(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getFadeIn()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getFadeIn()</a><br/>
     *
     * @return true if the tiles are to fade in; false if they are not
     */
    public final boolean getFadeIn() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getFadeIn()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getFadeIn();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getId() Gets this tile overlay's id.<br/>
     * com.huawei.hms.maps.model.TileOverlay.getId(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getId()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getId()</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getId()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getTransparency() Gets the transparency of this tile overlay.<br/>
     * com.huawei.hms.maps.model.TileOverlay.getTransparency(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getTransparency()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getTransparency()</a><br/>
     *
     * @return the transparency of this tile overlay
     */
    public final float getTransparency() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getTransparency()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getTransparency();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getZIndex() Gets the zIndex of this tile overlay.<br/>
     * com.huawei.hms.maps.model.TileOverlay.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#getZIndex()</a><br/>
     *
     * @return the zIndex of the tile overlay
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.TileOverlay.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#hashCode()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#hashCode()</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.isVisible() Gets the visibility of this tile overlay. Note that this does not return whether the tile overlay is actually within the screen's viewport, but whether it will be drawn if it is contained in the screen's viewport.<br/>
     * com.huawei.hms.maps.model.TileOverlay.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#isVisible()</a><br/>
     *
     * @return this tile overlay's visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.remove() Removes this tile overlay from the map.<br/>
     * com.huawei.hms.maps.model.TileOverlay.remove(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#remove()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#remove()</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).remove()");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setFadeIn(boolean) Sets whether the overlay tiles should fade in.<br/>
     * com.huawei.hms.maps.model.TileOverlay.setFadeIn(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setFadeIn(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setFadeIn(boolean)</a><br/>
     *
     * @param param0 true to make the tiles fade in; false to render them instantly
     */
    public final void setFadeIn(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setFadeIn(param0)");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setFadeIn(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setTransparency(float) Sets the transparency of this tile overlay. See the documentation at the top of this class for more information.<br/>
     * com.huawei.hms.maps.model.TileOverlay.setTransparency(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setTransparency(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setTransparency(float)</a><br/>
     *
     * @param param0 a float in the range [0..1] where 0 means that the tile overlay is opaque and 1 means that the tile overlay is transparent
     */
    public final void setTransparency(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setTransparency(param0)");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setTransparency(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setVisible(boolean) Sets the visibility of this tile overlay. When not visible, a tile overlay is not drawn, but it keeps all its other properties. Tile overlays are visible by default.<br/>
     * com.huawei.hms.maps.model.TileOverlay.setVisible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setVisible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setVisible(boolean)</a><br/>
     *
     * @param param0 true to make this overlay visible; false to make it invisible
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setVisible(param0)");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setZIndex(float) Sets the zIndex of this tile overlay. See the documentation at the top of this class for more information.<br/>
     * com.huawei.hms.maps.model.TileOverlay.setZIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setZIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlay#setZIndex(float)</a><br/>
     *
     * @param param0 the zIndex of this tile overlay
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setZIndex(param0)");
        ((com.huawei.hms.maps.model.TileOverlay) this.getHInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.TileOverlay.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model TileOverlay object
     */
    public static org.xms.g.maps.model.TileOverlay dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.TileOverlay) param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.TileOverlay;
    }
}