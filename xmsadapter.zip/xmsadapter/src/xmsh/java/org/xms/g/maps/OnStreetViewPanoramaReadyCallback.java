package org.xms.g.maps;

/**
 * xms Callback interface for when the Street View panorama is ready to be used.<br/>
 * Wrapper class for com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback: Called when a street view panorama is ready for use. Currently, street view panorama�Crelated classes are not supported, including StreetViewPanoramaCamera, StreetViewPanoramaFragment, StreetViewPanoramaOptions, StreetViewPanoramaView, and SupportStreetViewPanoramaFragment.<br/>
 */
public interface OnStreetViewPanoramaReadyCallback extends org.xms.g.utils.XInterface {
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama) Callback interface for when the Street View panorama is ready to be used.<br/>
     * com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(com.huawei.hms.maps.StreetViewPanorama): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-onstreetviewpanoramareadyc#onStreetViewPanoramaReady(StreetViewPanorama)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-onstreetviewpanoramareadyc#onStreetViewPanoramaReady(StreetViewPanorama)</a><br/>
     *
     * @param param0 A non-null instance of a StreetViewPanorama associated with the StreetViewPanoramaFragment or StreetViewPanoramaView that defines the callback
     */
    public void onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama param0);
    
    default java.lang.Object getZInstanceOnStreetViewPanoramaReadyCallback() {
        return getHInstanceOnStreetViewPanoramaReadyCallback();
    }
    
    default com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback getHInstanceOnStreetViewPanoramaReadyCallback() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback() {
            
            public void onStreetViewPanoramaReady(com.huawei.hms.maps.StreetViewPanorama param0) {
                org.xms.g.maps.OnStreetViewPanoramaReadyCallback.this.onStreetViewPanoramaReady(((param0) == null ? null : (new org.xms.g.maps.StreetViewPanorama(new org.xms.g.utils.XBox(param0)))));
            }
        };
    }
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.OnStreetViewPanoramaReadyCallback.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps OnStreetViewPanoramaReadyCallback object
     */
    public static org.xms.g.maps.OnStreetViewPanoramaReadyCallback dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.OnStreetViewPanoramaReadyCallback) param0);
    }
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback;
        }
        return param0 instanceof org.xms.g.maps.OnStreetViewPanoramaReadyCallback;
    }
    
    /**
     * xms Callback interface for when the Street View panorama is ready to be used.<br/>
     * Wrapper class for , but only the HMS API are provided.<br/>
     * : <br/>
     */
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.maps.OnStreetViewPanoramaReadyCallback {
        
        /**
         * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl .<br/>
         *
         * @param param0 this param is utils XBox
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.XImpl.onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama) Callback interface for when the Street View panorama is ready to be used.<br/>
         * com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(com.huawei.hms.maps.StreetViewPanorama): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-onstreetviewpanoramareadyc#onStreetViewPanoramaReady(StreetViewPanorama)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-onstreetviewpanoramareadyc#onStreetViewPanoramaReady(StreetViewPanorama)</a><br/>
         *
         * @param param0 A non-null instance of a StreetViewPanorama associated with the StreetViewPanoramaFragment or StreetViewPanoramaView that defines the callback
         */
        public void onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback) this.getHInstance()).onStreetViewPanoramaReady(((com.huawei.hms.maps.StreetViewPanorama) ((param0) == null ? null : (param0.getHInstance()))))");
            ((com.huawei.hms.maps.OnStreetViewPanoramaReadyCallback) this.getHInstance()).onStreetViewPanoramaReady(((com.huawei.hms.maps.StreetViewPanorama) ((param0) == null ? null : (param0.getHInstance()))));
        }
    }
}