package org.xms.g.measurement;

/**
 * This class provide content to applications.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public class AppMeasurementContentProvider extends android.content.ContentProvider implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.AppMeasurementContentProvider(org.xms.g.utils.XBox) constructor of AppMeasurementContentProvider with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AppMeasurementContentProvider(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.AppMeasurementContentProvider() constructor of AppMeasurementContentProvider.<br/>
     *
     */
    public AppMeasurementContentProvider() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void attachInfo(android.content.Context param0, android.content.pm.ProviderInfo param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int delete(android.net.Uri param0, java.lang.String param1, java.lang.String[] param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public java.lang.String getType(android.net.Uri param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public android.net.Uri insert(android.net.Uri param0, android.content.ContentValues param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public boolean onCreate() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public android.database.Cursor query(android.net.Uri param0, java.lang.String[] param1, java.lang.String param2, java.lang.String[] param3, java.lang.String param4) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int update(android.net.Uri param0, android.content.ContentValues param1, java.lang.String param2, java.lang.String[] param3) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.measurement.AppMeasurementContentProvider.<br/>
     *
     * @param param0 the input object
     * @return casted AppMeasurementContentProvider object
     */
    public static org.xms.g.measurement.AppMeasurementContentProvider dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementContentProvider.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}