package org.xms.g.security;

/**
 * A utility class for installing a dynamically updatable Provider to replace the platform default provider.<br/>
 * Wrapper class for com.huawei.hms.security.SecComponentInstallWizard, but only the HMS API are provided.<br/>
 * com.huawei.hms.security.SecComponentInstallWizard: not found.<br/>
 */
public class ProviderInstaller extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.security.ProviderInstaller.ProviderInstaller(org.xms.g.utils.XBox) Constructor of XObject with XBox.<br/>
     *
     * @param param0 xBox the wrapper of xms instance
     */
    public ProviderInstaller(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.security.ProviderInstaller.ProviderInstaller() Constructor of XObject with null.<br/>
     *
     */
    public ProviderInstaller() {
        super(((org.xms.g.utils.XBox) null));
    }
    
    /**
     * org.xms.g.security.ProviderInstaller.getPROVIDER_NAME() Gets Constant Value is "GmsCore_OpenSSL".<br/>
     *
     * @return Constant Value:"GmsCore_OpenSSL"
     */
    public static java.lang.String getPROVIDER_NAME() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.security.ProviderInstaller.installIfNeeded(android.content.Context) Installs the dynamically updatable security provider, if it's not already installed.<br/>
     * com.huawei.hms.security.SecComponentInstallWizard.install(android.content.Context)
     *
     * @param param0 the android context
     */
    public static void installIfNeeded(android.content.Context param0) throws org.xms.g.common.ExtensionPlayServicesRepairableException, org.xms.g.common.ExtensionPlayServicesNotAvailableException {
        try {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.security.SecComponentInstallWizard.install(param0)");
            com.huawei.hms.security.SecComponentInstallWizard.install(param0);
        }
        catch (com.huawei.hms.api.HuaweiServicesRepairableException e) {
            throw new org.xms.g.common.ExtensionPlayServicesRepairableException(new org.xms.g.utils.XBox(e));
        }
        catch (com.huawei.hms.api.HuaweiServicesNotAvailableException e) {
            throw new org.xms.g.common.ExtensionPlayServicesNotAvailableException(new org.xms.g.utils.XBox(e));
        }
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public static void installIfNeededAsync(android.content.Context param0, org.xms.g.security.ProviderInstaller.ProviderInstallListener param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.security.ProviderInstaller.dynamicCast(java.lang.Object) Dynamic cast the input object to org.xms.g.security.ProviderInstaller.<br/>
     *
     * @param param0 the input object
     * @return casted WalletConstants object
     */
    public static org.xms.g.security.ProviderInstaller dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.security.ProviderInstaller) param0);
    }
    
    /**
     * org.xms.g.security.ProviderInstaller.isInstance(java.lang.Object) Judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.security.SecComponentInstallWizard;
    }
    
    /**
     * Callback for notification of the result of provider installation.<br/>
     * Wrapper class for com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener, but only the HMS API are provided.<br/>
     * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener: not found.<br/>
     */
    public static interface ProviderInstallListener extends org.xms.g.utils.XInterface {
        
        /**
         * org.xms.g.security.ProviderInstaller.ProviderInstallListener.onProviderInstallFailed(int,android.content.Intent) Called when installing the provider fails. This method is always called on the UI thread.<br/>
         * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener.onFailed(int,android.content.Intent)
         *
         * @param param0 error code for the failure, for use with showErrorDialogFragment(Activity, int, int) or showErrorNotification(Context, ConnectionResult)
         * @param param1 if non-null, an intent that can be used to install or update Google Play Services such that the provider can be installed
         */
        public void onProviderInstallFailed(int param0, android.content.Intent param1);
        
        /**
         * org.xms.g.security.ProviderInstaller.ProviderInstallListener.onProviderInstalled() Called when installing the provider succeeds. This method is always called on the UI thread.<br/>
         * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener.onSuccess()
         *
         */
        public void onProviderInstalled();
        
        default java.lang.Object getZInstanceProviderInstallListener() {
            return getHInstanceProviderInstallListener();
        }
        
        default com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener getHInstanceProviderInstallListener() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener) ((org.xms.g.utils.XGettable) this).getHInstance());
            }
            return new com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener() {
                
                public void onFailed(int param0, android.content.Intent param1) {
                    org.xms.g.security.ProviderInstaller.ProviderInstallListener.this.onProviderInstallFailed(param0, param1);
                }
                
                public void onSuccess() {
                    org.xms.g.security.ProviderInstaller.ProviderInstallListener.this.onProviderInstalled();
                }
            };
        }
        
        /**
         * org.xms.g.security.ProviderInstaller.ProviderInstallListener.dynamicCast(java.lang.Object) Dynamic cast the input object to org.xms.g.security.ProviderInstaller.ProviderInstallListener.<br/>
         *
         * @param param0 the input object
         * @return casted WalletConstants object
         */
        public static org.xms.g.security.ProviderInstaller.ProviderInstallListener dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.security.ProviderInstaller.ProviderInstallListener) param0);
        }
        
        /**
         * org.xms.g.security.ProviderInstaller.ProviderInstallListener.isInstance(java.lang.Object) Judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener;
            }
            return param0 instanceof org.xms.g.security.ProviderInstaller.ProviderInstallListener;
        }
        
        /**
         * Callback for notification of the result of provider installation.<br/>
         * Wrapper class for com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener, but only the HMS API are provided.<br/>
         * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener: not found.<br/>
         */
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.security.ProviderInstaller.ProviderInstallListener {
            
            /**
             * org.xms.g.security.ProviderInstaller.ProviderInstallListener.XImpl.XImpl(org.xms.g.utils.XBox) Constructor of XObject with XBox.<br/>
             *
             * @param param0 XBox the wrapper of xms instance
             */
            public XImpl(org.xms.g.utils.XBox param0) {
                super(param0);
            }
            
            /**
             * org.xms.g.security.ProviderInstaller.ProviderInstallListener.XImpl.onProviderInstallFailed(int,android.content.Intent) Called when installing the provider fails. This method is always called on the UI thread.<br/>
             * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener.onFailed(int,android.content.Intent)
             *
             * @param param0 error code for the failure, for use with showErrorDialogFragment(Activity, int, int) or showErrorNotification(Context, ConnectionResult)
             * @param param1 if non-null, an intent that can be used to install or update Google Play Services such that the provider can be installed
             */
            public void onProviderInstallFailed(int param0, android.content.Intent param1) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener) this.getHInstance()).onFailed(param0, param1)");
                ((com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener) this.getHInstance()).onFailed(param0, param1);
            }
            
            /**
             * org.xms.g.security.ProviderInstaller.ProviderInstallListener.XImpl.onProviderInstalled() Called when installing the provider succeeds. This method is always called on the UI thread.<br/>
             * com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener.onSuccess()
             *
             */
            public void onProviderInstalled() {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener) this.getHInstance()).onSuccess()");
                ((com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener) this.getHInstance()).onSuccess();
            }
        }
    }
}