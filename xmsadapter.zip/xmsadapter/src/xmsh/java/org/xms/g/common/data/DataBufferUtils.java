package org.xms.g.common.data;

/**
 * Utilities for working with DataBuffer objects.<br/>
 * Wrapper class for com.huawei.hms.common.data.DataBufferUtils, but only the HMS API are provided.<br/>
 * com.huawei.hms.common.data.DataBufferUtils: <br/>
 */
public final class DataBufferUtils extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.common.data.DataBufferUtils.DataBufferUtils(org.xms.g.utils.XBox) constructor of DataBufferUtils with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public DataBufferUtils(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.freezeAndClose(org.xms.g.common.data.DataBuffer<XE>) Utility helper method to freeze a DataBuffer into a list of concrete entities. The DataBuffer provided here must contain elements that implement the Freezable interface.<br/>
     * com.huawei.hms.common.data.DataBufferUtils.freezeAndClose(com.huawei.hms.common.data.DataBuffer<E>)
     *
     * @param param0 DataBuffer to freeze contents from
     * @return ArrayList of objects represented by the buffer
     */
    public static <XT extends java.lang.Object, XE extends org.xms.g.common.data.Freezable<XT>> java.util.ArrayList<XT> freezeAndClose(org.xms.g.common.data.DataBuffer<XE> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.common.data.DataBufferUtils.freezeAndClose(((param0) == null ? null : (param0.getHInstanceDataBuffer())))");
        java.util.ArrayList hReturn = com.huawei.hms.common.data.DataBufferUtils.freezeAndClose(((param0) == null ? null : (param0.getHInstanceDataBuffer())));
        return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<Object, XT>() {
            
            public XT apply(java.lang.Object param0) {
                return ((XT) org.xms.g.utils.Utils.getXmsObjectWithHmsObject(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.hasData(org.xms.g.common.data.DataBuffer<?>) Utility function to determine whether a data buffer has data or not.<br/>
     * com.huawei.hms.common.data.DataBufferUtils.hasData(com.huawei.hms.common.data.DataBuffer<?>)
     *
     * @param param0 The data buffer to check
     * @return Whether the data buffer has data or not
     */
    public static boolean hasData(org.xms.g.common.data.DataBuffer<?> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.common.data.DataBufferUtils.hasData(((param0) == null ? null : (param0.getHInstanceDataBuffer())))");
        return com.huawei.hms.common.data.DataBufferUtils.hasData(((param0) == null ? null : (param0.getHInstanceDataBuffer())));
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.hasNextPage(org.xms.g.common.data.DataBuffer<?>) Utility function to get the "next page" pagination token from a data buffer.<br/>
     * com.huawei.hms.common.data.DataBufferUtils.hasNextPage(com.huawei.hms.common.data.DataBuffer<?>)
     *
     * @param param0 The data buffer to check
     * @return Whether the data buffer has next page or not
     */
    public static boolean hasNextPage(org.xms.g.common.data.DataBuffer<?> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.common.data.DataBufferUtils.hasNextPage(((param0) == null ? null : (param0.getHInstanceDataBuffer())))");
        return com.huawei.hms.common.data.DataBufferUtils.hasNextPage(((param0) == null ? null : (param0.getHInstanceDataBuffer())));
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.hasPrevPage(org.xms.g.common.data.DataBuffer<?>) Utility function to get the "prev page" pagination token from a data buffer.<br/>
     * com.huawei.hms.common.data.DataBufferUtils.hasPrevPage(com.huawei.hms.common.data.DataBuffer<?>)
     *
     * @param param0 The data buffer to check
     * @return boolean Whether the data buffer has prev page or not
     */
    public static boolean hasPrevPage(org.xms.g.common.data.DataBuffer<?> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.common.data.DataBufferUtils.hasPrevPage(((param0) == null ? null : (param0.getHInstanceDataBuffer())))");
        return com.huawei.hms.common.data.DataBufferUtils.hasPrevPage(((param0) == null ? null : (param0.getHInstanceDataBuffer())));
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.data.DataBufferUtils.<br/>
     *
     * @param param0 the input object
     * @return casted DataBufferUtils object
     */
    public static org.xms.g.common.data.DataBufferUtils dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.data.DataBufferUtils) param0);
    }
    
    /**
     * org.xms.g.common.data.DataBufferUtils.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.common.data.DataBufferUtils;
    }
}