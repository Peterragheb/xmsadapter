package org.xms.g.actions;

/**
 * Constants for intents to perform in-app search from a Search Action.<br/>
 * Wrapper class for com.huawei.hms.actions.SearchIntents, but only the HMS API are provided.<br/>
 * com.huawei.hms.actions.SearchIntents: HMS api does not provide in this Class. More details about the related GMS api can be seenin the reference below.<br/>
 */
public class SearchIntents extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.actions.SearchIntents.SearchIntents(org.xms.g.utils.XBox) constructor of with ItemListIntents XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public SearchIntents(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.actions.SearchIntents.getACTION_SEARCH() Intent action for performing an in-app search.<br/>
     * com.huawei.hms.actions.SearchIntents.ACTION_SEARCH
     *
     * @return return object is String
     */
    public static java.lang.String getACTION_SEARCH() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.actions.SearchIntents.ACTION_SEARCH");
        return com.huawei.hms.actions.SearchIntents.ACTION_SEARCH;
    }
    
    /**
     * org.xms.g.actions.SearchIntents.getEXTRA_QUERY() Intent extra specifying the text query to use as a string for ACTION_SEARCH.<br/>
     * com.huawei.hms.actions.SearchIntents.EXTRA_QUERY
     *
     * @return return object is String
     */
    public static java.lang.String getEXTRA_QUERY() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.actions.SearchIntents.EXTRA_QUERY");
        return com.huawei.hms.actions.SearchIntents.EXTRA_QUERY;
    }
    
    /**
     * org.xms.g.actions.SearchIntents.dynamicCast(java.lang.Object) dynamic cast the input object to SearchIntents.<br/>
     *
     * @param param0 the param should instanceof java.lang.Object
     * @return SearchIntents object
     */
    public static org.xms.g.actions.SearchIntents dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.actions.SearchIntents) param0);
    }
    
    /**
     * org.xms.g.actions.SearchIntents.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.actions.SearchIntents;
    }
}