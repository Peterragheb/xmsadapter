package org.xms.g.maps.model;

/**
 * xms An immutable class representing a dash used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Dash, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Dash: Extends PatternItem and represents a dash used in the stroke pattern for a polyline or the outline of a polygon or circle.<br/>
 */
public final class Dash extends org.xms.g.maps.model.PatternItem {
    
    /**
     * org.xms.g.maps.model.Dash.Dash(org.xms.g.utils.XBox) An immutable class representing a dash used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.huawei.hms.maps.model.Dash.Dash(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/dash-0000001050152605-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/dash-0000001050152605-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Dash(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Dash.Dash(float) An immutable class representing a dash used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.huawei.hms.maps.model.Dash.Dash(float): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/dash-0000001050152605-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/dash-0000001050152605-V5</a><br/>
     *
     * @param param0 Length in pixels. Negative value will be clamped to zero
     */
    public Dash(float param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.Dash(param0));
    }
    
    /**
     * org.xms.g.maps.model.Dash.getLength() Length in pixels(non-negative).<br/>
     * com.huawei.hms.maps.model.Dash.length: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-dash">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-dash</a><br/>
     *
     * @return the return object is float
     */
    public float getLength() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Dash) this.getHInstance()).length");
        return ((com.huawei.hms.maps.model.Dash) this.getHInstance()).length;
    }
    
    /**
     * org.xms.g.maps.model.Dash.toString() to String.<br/>
     * com.huawei.hms.maps.model.Dash.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-dash">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-dash</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Dash) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.Dash) this.getHInstance()).toString();
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.Dash.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Dash.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Dash object
     */
    public static org.xms.g.maps.model.Dash dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Dash) param0);
    }
    
    /**
     * org.xms.g.maps.model.Dash.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Dash;
    }
}