package org.xms.g.maps.model;

/**
 * xms An immutable class that aggregates all camera position parameters.<br/>
 * Wrapper class for com.huawei.hms.maps.model.StreetViewPanoramaCamera, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.StreetViewPanoramaCamera: An immutable class that aggregates all camera position parameters.<br/>
 */
public class StreetViewPanoramaCamera extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.CREATOR: <a href=""></a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.StreetViewPanoramaCamera createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.StreetViewPanoramaCamera hReturn = com.huawei.hms.maps.model.StreetViewPanoramaCamera.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.StreetViewPanoramaCamera(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.StreetViewPanoramaCamera[] newArray(int param0) {
            return new org.xms.g.maps.model.StreetViewPanoramaCamera[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.StreetViewPanoramaCamera(org.xms.g.utils.XBox) An immutable class that aggregates all camera position parameters.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.StreetViewPanoramaCamera()
     *
     * @param param0 the param should instanceof utils XBox
     */
    public StreetViewPanoramaCamera(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.getBearing() Direction that the camera is pointing in, in degrees clockwise from north.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.bearing
     *
     * @return the return object is float
     */
    public float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).bearing");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).bearing;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.getTilt() The angle, in degrees, of the camera from the horizon of the panorama. See tilt for details of restrictions on the range of values.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.tilt
     *
     * @return the return object is float
     */
    public float getTilt() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).tilt");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).tilt;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.getZoom() Zoom level near the centre of the screen. See zoom for the definition of the camera's zoom level.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.zoom
     *
     * @return the return object is float
     */
    public float getZoom() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).zoom");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).zoom;
    }
    
    public static org.xms.g.maps.model.StreetViewPanoramaCamera.Builder builder() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.StreetViewPanoramaCamera.builder()");
        com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = com.huawei.hms.maps.model.StreetViewPanoramaCamera.builder();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.builder(org.xms.g.maps.model.StreetViewPanoramaCamera) Creates a builder for a Street View panorama camera.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.builder(com.huawei.hms.maps.model.StreetViewPanoramaCamera)
     *
     * @param param0 the param should instanceof maps model StreetViewPanoramaCamera
     * @return the return object is maps model StreetViewPanoramaCamera Builder
     */
    public static org.xms.g.maps.model.StreetViewPanoramaCamera.Builder builder(org.xms.g.maps.model.StreetViewPanoramaCamera param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.StreetViewPanoramaCamera.builder(((com.huawei.hms.maps.model.StreetViewPanoramaCamera) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = com.huawei.hms.maps.model.StreetViewPanoramaCamera.builder(((com.huawei.hms.maps.model.StreetViewPanoramaCamera) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.equals(java.lang.Object) equals.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.equals(java.lang.Object)
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.getOrientation() Returns the particular camera's tilt and bearing as an orientation.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.getOrientation()
     *
     * @return orientation Tilt and bearing of the camera
     */
    public org.xms.g.maps.model.StreetViewPanoramaOrientation getOrientation() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).getOrientation()");
        com.huawei.hms.maps.model.StreetViewPanoramaOrientation hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).getOrientation();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.hashCode()
     *
     * @return the return object is int
     */
    public int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.toString() to String.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.toString()
     *
     * @return the return object is java lang String
     */
    public java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.writeToParcel(android.os.Parcel,int)
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.StreetViewPanoramaCamera) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaCamera.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model StreetViewPanoramaCamera object
     */
    public static org.xms.g.maps.model.StreetViewPanoramaCamera dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.StreetViewPanoramaCamera) param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaCamera.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.StreetViewPanoramaCamera;
    }
    
    /**
     * Builds panorama cameras.<br/>
     * Wrapper class for com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder, but only the HMS API are provided.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder: Builds panorama cameras.<br/>
     */
    public static final class Builder extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.Builder(org.xms.g.utils.XBox) Builds panorama cameras.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.Builder()
         *
         * @param param0 the param should instanceof utils XBox
         */
        public Builder(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.Builder() Builds panorama cameras.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.Builder()
         *
         */
        public Builder() {
            super(((org.xms.g.utils.XBox) null));
            this.setHInstance(new com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder());
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.Builder(org.xms.g.maps.model.StreetViewPanoramaCamera) constructor of Builder.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.Builder(com.huawei.hms.maps.model.StreetViewPanoramaCamera)
         *
         * @param param0 maps model StreetViewPanoramaCamera
         */
        public Builder(org.xms.g.maps.model.StreetViewPanoramaCamera param0) {
            super(((org.xms.g.utils.XBox) null));
            this.setHInstance(new com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder(((com.huawei.hms.maps.model.StreetViewPanoramaCamera) ((param0) == null ? null : (param0.getHInstance())))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.getBearing() bearing.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.bearing
         *
         * @return the return object is float
         */
        public float getBearing() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).bearing");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).bearing;
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.getTilt() getTilt.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.tilt
         *
         * @return the return object is float
         */
        public float getTilt() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).tilt");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).tilt;
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.getZoom() getZoom.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.zoom
         *
         * @return the return object is float
         */
        public float getZoom() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).zoom");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).zoom;
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.bearing(float) Sets the direction that the camera is pointing in, in degrees clockwise from north.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.bearing(float)
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model StreetViewPanoramaCamera Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaCamera.Builder bearing(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).bearing(param0)");
            com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).bearing(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.build() Builds a StreetViewPanoramaCamera.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.build()
         *
         * @return the return object is maps model StreetViewPanoramaCamera
         */
        public final org.xms.g.maps.model.StreetViewPanoramaCamera build() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).build()");
            com.huawei.hms.maps.model.StreetViewPanoramaCamera hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).build();
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.orientation(org.xms.g.maps.model.StreetViewPanoramaOrientation) Sets the camera tilt and bearing based upon the given orientation's tilt and bearing.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.orientation(com.huawei.hms.maps.model.StreetViewPanoramaOrientation)
         *
         * @param param0 the param should instanceof maps model StreetViewPanoramaOrientation
         * @return the return object is maps model StreetViewPanoramaCamera Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaCamera.Builder orientation(org.xms.g.maps.model.StreetViewPanoramaOrientation param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).orientation(((com.huawei.hms.maps.model.StreetViewPanoramaOrientation) ((param0) == null ? null : (param0.getHInstance()))))");
            com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).orientation(((com.huawei.hms.maps.model.StreetViewPanoramaOrientation) ((param0) == null ? null : (param0.getHInstance()))));
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.tilt(float) Sets the angle, in degrees, of the camera from the horizon of the panorama. This value is restricted to being between-90(directly down)and 90(directly up).<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.tilt(float)
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model StreetViewPanoramaCamera Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaCamera.Builder tilt(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).tilt(param0)");
            com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).tilt(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.zoom(float) Sets the zoom level of the camera.<br/>
         * com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder.zoom(float)
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model StreetViewPanoramaCamera Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaCamera.Builder zoom(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).zoom(param0)");
            com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder) this.getHInstance()).zoom(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.<br/>
         *
         * @param param0 the param should instanceof java lang Object
         * @return cast maps model StreetViewPanoramaCamera Builder object
         */
        public static org.xms.g.maps.model.StreetViewPanoramaCamera.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.maps.model.StreetViewPanoramaCamera.Builder) param0);
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaCamera.Builder.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.StreetViewPanoramaCamera.Builder;
        }
    }
}