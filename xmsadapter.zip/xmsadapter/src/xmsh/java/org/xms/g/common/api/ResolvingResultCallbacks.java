package org.xms.g.common.api;

/**
 * ResultCallbacks which automatically start resolutions for failures. Contains separate callbacks for success and unresolvable failures.<br/>
 * Wrapper class for com.huawei.hms.support.api.client.ResolvingResultCallbacks, but only the HMS API are provided.<br/>
 * com.huawei.hms.support.api.client.ResolvingResultCallbacks: <br/>
 */
public abstract class ResolvingResultCallbacks<XR extends org.xms.g.common.api.Result> extends org.xms.g.common.api.ResultCallbacks<XR> {
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.ResolvingResultCallbacks(org.xms.g.utils.XBox) constructor of ResolvingResultCallbacks with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ResolvingResultCallbacks(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.ResolvingResultCallbacks(android.app.Activity,int) Create new callbacks that automatically resolve failure.<br/>
     * com.huawei.hms.support.api.client.ResolvingResultCallbacks.ResolvingResultCallbacks(android.app.Activity,int)
     *
     * @param param0 Activity to use for displaying UI to resolve failures
     * @param param1 If >= 0, this code will be passed to onActivityResult(int, int, Intent) after the user completes a resolution
     */
    public ResolvingResultCallbacks(android.app.Activity param0, int param1) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new HImpl(param0, param1));
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.onSuccess(XR) Called when the Result is ready and was successful.<br/>
     * com.huawei.hms.support.api.client.ResolvingResultCallbacks.onSuccess(XR)
     *
     * @param param0 The result from the API call. Never null
     */
    public abstract void onSuccess(XR param0);
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.onUnresolvableFailure(org.xms.g.common.api.Status) Called when a non-resolvable failure occurs or starting a resolution fails.<br/>
     *
     * @param param0 Status resulting from the API call. Guaranteed to be non-null and unsuccessful
     */
    public abstract void onUnresolvableFailure(org.xms.g.common.api.Status param0);
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ResolvingResultCallbacks.<br/>
     *
     * @param param0 the input object
     * @return casted ResolvingResultCallbacks object
     */
    public static org.xms.g.common.api.ResolvingResultCallbacks dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.common.api.ResolvingResultCallbacks) {
            return ((org.xms.g.common.api.ResolvingResultCallbacks) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.huawei.hms.support.api.client.ResolvingResultCallbacks hReturn = ((com.huawei.hms.support.api.client.ResolvingResultCallbacks) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.common.api.ResolvingResultCallbacks.XImpl(new org.xms.g.utils.XBox(hReturn));
        }
        return ((org.xms.g.common.api.ResolvingResultCallbacks) param0);
    }
    
    /**
     * org.xms.g.common.api.ResolvingResultCallbacks.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.support.api.client.ResolvingResultCallbacks;
    }
    
    private class HImpl<R extends com.huawei.hms.support.api.client.Result> extends com.huawei.hms.support.api.client.ResolvingResultCallbacks<R> {
        
        public void onSuccess(R param0) {
            java.lang.Object[] params = new java.lang.Object[1];
            java.lang.Class[] types = new java.lang.Class[1];
            params[0] = param0;
            types[0] = org.xms.g.common.api.Result.class;
            org.xms.g.utils.Utils.invokeMethod(org.xms.g.common.api.ResolvingResultCallbacks.this, "onSuccess", params, types, true);
        }
        
        public void onUnresolvableFailure(com.huawei.hms.support.api.client.Status param0) {
            org.xms.g.common.api.ResolvingResultCallbacks.this.onUnresolvableFailure(((param0) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(param0)))));
        }
        
        protected HImpl(android.app.Activity param0, int param1) {
            super(param0, param1);
        }
    }
    
    /**
     * Wrapper class of ResultCallbacks which automatically start resolutions for failures. Contains separate callbacks for success and unresolvable failures.<br/>
     * Wrapper class for com.huawei.hms.support.api.client.ResolvingResultCallbacks, but only the HMS API are provided.<br/>
     * com.huawei.hms.support.api.client.ResolvingResultCallbacks: <br/>
     */
    public static class XImpl<XR extends org.xms.g.common.api.Result> extends org.xms.g.common.api.ResolvingResultCallbacks<XR> {
        
        /**
         * org.xms.g.common.api.ResolvingResultCallbacks.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.common.api.ResolvingResultCallbacks.XImpl.onSuccess(XR) Called when the Result is ready and was successful.<br/>
         * com.huawei.hms.support.api.client.ResolvingResultCallbacks.onSuccess(XR)
         *
         * @param param0 The result from the API call. Never null
         */
        public void onSuccess(XR param0) {
            com.huawei.hms.support.api.client.Result hObj0 = ((com.huawei.hms.support.api.client.Result) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onSuccess(hObj0)");
            ((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onSuccess(hObj0);
        }
        
        /**
         * org.xms.g.common.api.ResolvingResultCallbacks.XImpl.onUnresolvableFailure(org.xms.g.common.api.Status) Called when a non-resolvable failure occurs or starting a resolution fails.<br/>
         * com.huawei.hms.support.api.client.ResolvingResultCallbacks.onUnresolvableFailure(com.huawei.hms.support.api.client.Status)
         *
         * @param param0 Status resulting from the API call. Guaranteed to be non-null and unsuccessful
         */
        public void onUnresolvableFailure(org.xms.g.common.api.Status param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onUnresolvableFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
            ((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onUnresolvableFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
        }
        
        /**
         * org.xms.g.common.api.ResolvingResultCallbacks.XImpl.onFailure(org.xms.g.common.api.Status) Called when the Result is ready and a failure occurred.<br/>
         * com.huawei.hms.support.api.client.ResolvingResultCallbacks.onFailure(com.huawei.hms.support.api.client.Status)
         *
         * @param param0 Status resulting from the API call. Guaranteed to be non-null and unsuccessful
         */
        public void onFailure(org.xms.g.common.api.Status param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
            ((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
        }
        
        /**
         * org.xms.g.common.api.ResolvingResultCallbacks.XImpl.onResult(XR) Called when the Result is ready.<br/>
         * com.huawei.hms.support.api.client.ResolvingResultCallbacks.onResult(R)
         *
         * @param param0 The result from the API call. Never null
         */
        public void onResult(XR param0) {
            com.huawei.hms.support.api.client.Result hObj0 = ((com.huawei.hms.support.api.client.Result) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onResult(hObj0)");
            ((com.huawei.hms.support.api.client.ResolvingResultCallbacks) this.getHInstance()).onResult(hObj0);
        }
    }
}