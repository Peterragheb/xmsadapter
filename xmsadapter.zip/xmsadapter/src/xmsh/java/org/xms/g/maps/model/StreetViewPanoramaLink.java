package org.xms.g.maps.model;

/**
 * xms An immutable class that represents a link to another Street View panorama.<br/>
 * Wrapper class for com.huawei.hms.maps.model.StreetViewPanoramaLink, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.StreetViewPanoramaLink: An immutable class that represents a link to another Street View panorama.<br/>
 */
public class StreetViewPanoramaLink extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.CREATOR: <a href=""></a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.StreetViewPanoramaLink createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.StreetViewPanoramaLink hReturn = com.huawei.hms.maps.model.StreetViewPanoramaLink.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.StreetViewPanoramaLink(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.StreetViewPanoramaLink[] newArray(int param0) {
            return new org.xms.g.maps.model.StreetViewPanoramaLink[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.StreetViewPanoramaLink(org.xms.g.utils.XBox) An immutable class that represents a link to another Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.StreetViewPanoramaLink(com.huawei.hms.utils.XBox)
     *
     * @param param0 the param should instanceof utils XBox
     */
    public StreetViewPanoramaLink(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.getBearing() The direction of the linked Street View panorama, in degrees clockwise from north.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.bearing
     *
     * @return the return object is float
     */
    public float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).bearing");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).bearing;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.getPanoId() Panorama ID of the linked Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.panoId
     *
     * @return the return object is java lang String
     */
    public java.lang.String getPanoId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).panoId");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).panoId;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.equals(java.lang.Object) equals.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.equals(java.lang.Object)
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.hashCode()
     *
     * @return the return object is int
     */
    public int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.toString() to String.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.toString()
     *
     * @return the return object is java lang String
     */
    public java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLink.writeToParcel(android.os.Parcel,int)
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.StreetViewPanoramaLink) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaLink.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model StreetViewPanoramaLink object
     */
    public static org.xms.g.maps.model.StreetViewPanoramaLink dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.StreetViewPanoramaLink) param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLink.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.StreetViewPanoramaLink;
    }
}