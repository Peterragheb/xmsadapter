package org.xms.g.analytics;

/**
 * Deprecated Analytics Logger interface. Analytics will log to logcat under GAv4 tag using Android Log system. By default only ERROR, WARN and INFO levels are enabled.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public interface Logger extends org.xms.g.utils.XInterface {
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void error(java.lang.Exception param0);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void error(java.lang.String param0);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int getLogLevel();
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void info(java.lang.String param0);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void setLogLevel(int param0);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void verbose(java.lang.String param0);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void warn(java.lang.String param0);
    
    default java.lang.Object getZInstanceLogger() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    default java.lang.Object getHInstanceLogger() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.Logger.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.analytics.Logger.<br/>
     *
     * @param param0 the input object
     * @return casted Logger object
     */
    public static org.xms.g.analytics.Logger dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.Logger.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * Deprecated Analytics Logger interface. Analytics will log to logcat under GAv4 tag using Android Log system. By default only ERROR, WARN and INFO levels are enabled.<br/>
     * Wrapper class for , but only the HMS API are provided.<br/>
     * : <br/>
     */
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.analytics.Logger {
        
        /**
         * org.xms.g.analytics.Logger.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void error(java.lang.Exception param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void error(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public int getLogLevel() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void info(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void setLogLevel(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void verbose(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void warn(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
    
    /**
     * This class was deprecated.See Logger interface for details.<br/>
     * Wrapper class for , but only the HMS API are provided.<br/>
     * : <br/>
     */
    public static class LogLevel extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.LogLevel(org.xms.g.utils.XBox) constructor of LogLevel with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public LogLevel(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.LogLevel() constructor of LogLevel.<br/>
         *
         */
        public LogLevel() {
            super(((org.xms.g.utils.XBox) null));
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.getERROR() Return the constant value.<br/>
         *
         * @return Constant Value:3
         */
        public static int getERROR() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.getINFO() Return the constant value.<br/>
         *
         * @return Constant Value:1
         */
        public static int getINFO() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.getVERBOSE() Return the constant value.<br/>
         *
         * @return Constant Value:0
         */
        public static int getVERBOSE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.getWARNING() Return the constant value.<br/>
         *
         * @return Constant Value:2
         */
        public static int getWARNING() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.analytics.Logger.LogLevel.<br/>
         *
         * @param param0 the input object
         * @return the casted LogLevel object
         */
        public static org.xms.g.analytics.Logger.LogLevel dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.g.analytics.Logger.LogLevel.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}