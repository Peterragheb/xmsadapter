package org.xms.g.common;

/**
 * Indicates services is not available.<br/>
 * Wrapper class for com.huawei.hms.api.HuaweiServicesNotAvailableException, but only the HMS API are provided.<br/>
 * com.huawei.hms.api.HuaweiServicesNotAvailableException: the HuaweiServicesNotAvailableException.<br/>
 */
public final class ExtensionPlayServicesNotAvailableException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.ExtensionPlayServicesNotAvailableException(org.xms.g.utils.XBox) constructor of ExtensionPlayServicesNotAvailableException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionPlayServicesNotAvailableException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.ExtensionPlayServicesNotAvailableException(int) constructor of ExtensionPlayServicesNotAvailableException.<br/>
     * com.huawei.hms.api.HuaweiServicesNotAvailableException.HuaweiServicesNotAvailableException(int)
     *
     * @param param0 the errorCode
     */
    public ExtensionPlayServicesNotAvailableException(int param0) {
        this.setHInstance(new com.huawei.hms.api.HuaweiServicesNotAvailableException(param0));
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.getErrorCode() return the value of errorCode.<br/>
     * com.huawei.hms.api.HuaweiServicesNotAvailableException.errorCode
     *
     * @return the ErrorCode
     */
    public int getErrorCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiServicesNotAvailableException) this.getHInstance()).errorCode");
        return ((com.huawei.hms.api.HuaweiServicesNotAvailableException) this.getHInstance()).errorCode;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.ExtensionPlayServicesNotAvailableException.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionPlayServicesNotAvailableException object
     */
    public static org.xms.g.common.ExtensionPlayServicesNotAvailableException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.ExtensionPlayServicesNotAvailableException) param0);
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.api.HuaweiServicesNotAvailableException;
    }
}