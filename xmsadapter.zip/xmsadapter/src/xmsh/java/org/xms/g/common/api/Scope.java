package org.xms.g.common.api;

/**
 * Describes the authorization request for OAuth2.0 which has security implications for the user, and requesting additional scopes will result in authorization dialogs.<br/>
 * Wrapper class for com.huawei.hms.support.api.entity.auth.Scope, but only the HMS API are provided.<br/>
 * com.huawei.hms.support.api.entity.auth.Scope: Describes the authorization request for OAuth2.0, which affects user security. When authorization is requested, an authorization dialog box is displayed.<br/>
 */
public final class Scope extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.support.api.entity.auth.Scope.CREATOR: <a href=""></a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.common.api.Scope createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.support.api.entity.auth.Scope hReturn = com.huawei.hms.support.api.entity.auth.Scope.CREATOR.createFromParcel(param0);
            return new org.xms.g.common.api.Scope(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.common.api.Scope[] newArray(int param0) {
            return new org.xms.g.common.api.Scope[param0];
        }
    };
    
    /**
     * org.xms.g.common.api.Scope.Scope(org.xms.g.utils.XBox) constructor of Scope with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public Scope(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.api.Scope.Scope(java.lang.String) Creates a new scope using the specified URI.<br/>
     * com.huawei.hms.support.api.entity.auth.Scope.Scope(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section03313201607">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section03313201607</a><br/>
     *
     * @param param0 URI of the scope
     */
    public Scope(java.lang.String param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.support.api.entity.auth.Scope(param0));
    }
    
    /**
     * org.xms.g.common.api.Scope.equals(java.lang.Object) Determines whether two instances are equal.<br/>
     * com.huawei.hms.support.api.entity.auth.Scope.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section857317474820">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section857317474820</a><br/>
     *
     * @param param0 Objects to be compared
     * @return Comparison result: equal if true, and unequal if false
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.common.api.Scope.hashCode() hashCode of a compute instance.<br/>
     * com.huawei.hms.support.api.entity.auth.Scope.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section2482195825115">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section2482195825115</a><br/>
     *
     * @return hash code
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.common.api.Scope.toString() Constructs and outputs the string of an instance.<br/>
     * com.huawei.hms.support.api.entity.auth.Scope.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section170184875211">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section170184875211</a><br/>
     *
     * @return the string of an instance
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).toString()");
        return ((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.common.api.Scope.writeToParcel(android.os.Parcel,int) used in serialization and deserialization.<br/>
     * com.huawei.hms.support.api.entity.auth.Scope.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section5488115785018">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/scope-0000001050123083#EN-US_TOPIC_0000001050123083__section5488115785018</a><br/>
     *
     * @param param0 Parcel object
     * @param param1 Writing mode
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.support.api.entity.auth.Scope) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.Scope.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Scope.<br/>
     *
     * @param param0 the input object
     * @return casted Scope object
     */
    public static org.xms.g.common.api.Scope dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.Scope) param0);
    }
    
    /**
     * org.xms.g.common.api.Scope.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.support.api.entity.auth.Scope;
    }
}