package org.xms.g.tasks;

/**
 * A function that is called to continue execution after completion of a Task.<br/>
 * Wrapper class for com.huawei.hmf.tasks.Continuation, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.Continuation: Contains a function that is called to continue execution after the completion of a task.<br/>
 */
public interface Continuation<XTResult, XTContinuationResult> extends org.xms.g.utils.XInterface {
    
    /**
     * org.xms.g.tasks.Continuation.then(org.xms.g.tasks.Task<XTResult>) Returns the result of applying this Continuation to Task.<br/>
     * com.huawei.hmf.tasks.Continuation.then(com.google.android.gms.tasks.Task<TResult>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/continuation-0000001050123097#EN-US_TOPIC_0000001050123097__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/continuation-0000001050123097#EN-US_TOPIC_0000001050123097__section32821622269</a><br/>
     *
     * @param param0 the completed Task. Never null
     * @throws java.lang.Exception if the result couldn't be produced
     * @return the return object is XTContinuationResult
     */
    public XTContinuationResult then(org.xms.g.tasks.Task<XTResult> param0) throws java.lang.Exception;
    
    default java.lang.Object getZInstanceContinuation() {
        return getHInstanceContinuation();
    }
    
    default <TResult, TContinuationResult> com.huawei.hmf.tasks.Continuation<TResult, TContinuationResult> getHInstanceContinuation() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hmf.tasks.Continuation<TResult, TContinuationResult>) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hmf.tasks.Continuation<TResult, TContinuationResult>() {
            
            public TContinuationResult then(com.huawei.hmf.tasks.Task<TResult> param0) throws java.lang.Exception {
                XTContinuationResult xResult = ((XTContinuationResult) org.xms.g.tasks.Continuation.this.then(((param0) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(param0))))));
                return ((TContinuationResult) org.xms.g.utils.Utils.getInstanceInInterface(xResult, true));
            }
        };
    }
    
    /**
     * org.xms.g.tasks.Continuation.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.Continuation.<br/>
     *
     * @param param0 the input object
     * @return casted Continuation object
     */
    public static org.xms.g.tasks.Continuation dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.Continuation) param0);
    }
    
    /**
     * org.xms.g.tasks.Continuation.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hmf.tasks.Continuation;
        }
        return param0 instanceof org.xms.g.tasks.Continuation;
    }
    
    /**
     * A function that is called to continue execution after completion of a Task.<br/>
     * Wrapper class for com.huawei.hmf.tasks.Continuation, but only the HMS API are provided.<br/>
     * com.huawei.hmf.tasks.Continuation: Contains a function that is called to continue execution after the completion of a task.<br/>
     */
    public static class XImpl<XTResult, XTContinuationResult> extends org.xms.g.utils.XObject implements org.xms.g.tasks.Continuation<XTResult, XTContinuationResult> {
        
        /**
         * org.xms.g.tasks.Continuation.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.tasks.Continuation.XImpl.then(org.xms.g.tasks.Task<XTResult>) Returns the result of applying this Continuation to Task.<br/>
         * com.huawei.hmf.tasks.Continuation.then(com.google.android.gms.tasks.Task<TResult>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/continuation-0000001050123097#EN-US_TOPIC_0000001050123097__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/continuation-0000001050123097#EN-US_TOPIC_0000001050123097__section32821622269</a><br/>
         *
         * @param param0 the completed Task. Never null
         * @throws java.lang.Exception if the result couldn't be produced
         * @return the return object is XTContinuationResult
         */
        public XTContinuationResult then(org.xms.g.tasks.Task<XTResult> param0) throws java.lang.Exception {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hmf.tasks.Continuation) this.getHInstance()).then(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))))");
            java.lang.Object hmsObj = ((com.huawei.hmf.tasks.Continuation) this.getHInstance()).then(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))));
            return ((XTContinuationResult) org.xms.g.utils.Utils.getXmsObjectWithHmsObject(hmsObj));
        }
    }
}