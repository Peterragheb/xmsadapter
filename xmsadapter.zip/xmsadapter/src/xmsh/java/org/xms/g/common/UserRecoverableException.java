package org.xms.g.common;

/**
 * UserRecoverableExceptions signal errors that can be recovered with user action, such as a user login.<br/>
 * Wrapper class for com.huawei.hms.api.UserRecoverableException, but only the HMS API are provided.<br/>
 * com.huawei.hms.api.UserRecoverableException: the UserRecoverableException.<br/>
 */
public class UserRecoverableException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.UserRecoverableException.UserRecoverableException(org.xms.g.utils.XBox) constructor of UserRecoverableException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public UserRecoverableException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.UserRecoverableException(java.lang.String,android.content.Intent) constructor of UserRecoverableExceptionbr./> Support running environments including both HMS and GMS which are chosen by users.<br/>
     * com.huawei.hms.api.UserRecoverableException.UserRecoverableException(java.lang.String,android.content.Intent)
     *
     * @param param0 the msg
     * @param param1 the intent
     */
    public UserRecoverableException(java.lang.String param0, android.content.Intent param1) {
        this.setHInstance(new HImpl(param0, param1));
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.getIntent() Getter for an Intent that when supplied to startActivityForResult(Intent, int), will allow user intervention.<br/>
     * com.huawei.hms.api.UserRecoverableException.getIntent()
     *
     * @return Intent representing the ameliorating user action
     */
    public android.content.Intent getIntent() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.UserRecoverableException) this.getHInstance()).getIntent()");
            return ((com.huawei.hms.api.UserRecoverableException) this.getHInstance()).getIntent();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.api.UserRecoverableException) this.getHInstance())).getIntentCallSuper()");
            return ((HImpl) ((com.huawei.hms.api.UserRecoverableException) this.getHInstance())).getIntentCallSuper();
        }
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.UserRecoverableException.<br/>
     *
     * @param param0 the input object
     * @return casted UserRecoverableException object
     */
    public static org.xms.g.common.UserRecoverableException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.UserRecoverableException) param0);
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.api.UserRecoverableException;
    }
    
    private class HImpl extends com.huawei.hms.api.UserRecoverableException {
        
        public android.content.Intent getIntent() {
            return org.xms.g.common.UserRecoverableException.this.getIntent();
        }
        
        public android.content.Intent getIntentCallSuper() {
            return super.getIntent();
        }
        
        public HImpl(java.lang.String param0, android.content.Intent param1) {
            super(param0, param1);
        }
    }
}