package org.xms.g.maps.model;

/**
 * xms An immutable class that contains details of the user's current Street View panorama.<br/>
 * Wrapper class for com.huawei.hms.maps.model.StreetViewPanoramaLocation, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.StreetViewPanoramaLocation: An immutable class that contains details of the user's current Street View panorama.<br/>
 */
public class StreetViewPanoramaLocation extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.StreetViewPanoramaLocation createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.StreetViewPanoramaLocation hReturn = com.huawei.hms.maps.model.StreetViewPanoramaLocation.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.StreetViewPanoramaLocation(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.StreetViewPanoramaLocation[] newArray(int param0) {
            return new org.xms.g.maps.model.StreetViewPanoramaLocation[param0];
        }
    };
    private boolean wrapper = true;
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.StreetViewPanoramaLocation(org.xms.g.utils.XBox) An immutable class that contains details of the user's current Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.StreetViewPanoramaLocation()
     *
     * @param param0 the param should instanceof utils XBox
     */
    public StreetViewPanoramaLocation(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.StreetViewPanoramaLocation(org.xms.g.maps.model.StreetViewPanoramaLink[],org.xms.g.maps.model.LatLng,java.lang.String) An immutable class that contains details of the user's current Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.StreetViewPanoramaLocation(com.huawei.hms.maps.model.StreetViewPanoramaLink[],com.huawei.hms.maps.model.LatLng,java.lang.String)
     *
     * @param param0 Identification string for the current Street View panorama
     * @param param1 List of StreetViewPanoramaLink reachable from the current position
     * @param param2 The location of the current Street View panorama
     */
    public StreetViewPanoramaLocation(org.xms.g.maps.model.StreetViewPanoramaLink[] param0, org.xms.g.maps.model.LatLng param1, java.lang.String param2) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new HImpl(((com.huawei.hms.maps.model.StreetViewPanoramaLink[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hms.maps.model.StreetViewPanoramaLink.class, x -> (com.huawei.hms.maps.model.StreetViewPanoramaLink)x.getHInstance())), ((com.huawei.hms.maps.model.LatLng) ((param1) == null ? null : (param1.getHInstance()))), param2));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.getLinks() Array of StreetViewPanoramaLink able to be reached from the current position.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.links
     *
     * @return the return object is maps model StreetViewPanoramaLink[]
     */
    public org.xms.g.maps.model.StreetViewPanoramaLink[] getLinks() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).links");
        com.huawei.hms.maps.model.StreetViewPanoramaLink[] hReturn = null;
        hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).links;
        return org.xms.g.utils.Utils.genericArrayCopy(hReturn, org.xms.g.maps.model.StreetViewPanoramaLink.class, new org.xms.g.utils.Function<com.huawei.hms.maps.model.StreetViewPanoramaLink, org.xms.g.maps.model.StreetViewPanoramaLink>() {
            
            public org.xms.g.maps.model.StreetViewPanoramaLink apply(com.huawei.hms.maps.model.StreetViewPanoramaLink param0) {
                return new org.xms.g.maps.model.StreetViewPanoramaLink(new org.xms.g.utils.XBox(param0));
            }
        });
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.getPanoId() The panorama ID of the current Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.panoId
     *
     * @return the return object is java lang String
     */
    public java.lang.String getPanoId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).panoId");
        return ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).panoId;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.getPosition() The location of the current Street View panorama.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.position
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getPosition() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).position");
        com.huawei.hms.maps.model.LatLng hReturn = null;
        hReturn = ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).position;
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.equals(java.lang.Object) equals.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.equals(java.lang.Object)
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public boolean equals(java.lang.Object param0) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).equals(param0)");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).equals(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).equalsCallSuper(param0)");
            return ((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).equalsCallSuper(param0);
        }
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.hashCode()
     *
     * @return the return object is int
     */
    public int hashCode() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).hashCode()");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).hashCode();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).hashCodeCallSuper()");
            return ((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).hashCodeCallSuper();
        }
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.toString() to String.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.toString()
     *
     * @return the return object is java lang String
     */
    public java.lang.String toString() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).toString()");
            return ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).toString();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).toStringCallSuper()");
            return ((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).toStringCallSuper();
        }
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.StreetViewPanoramaLocation.writeToParcel(android.os.Parcel,int)
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).writeToParcel(param0, param1)");
            ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance()).writeToParcel(param0, param1);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).writeToParcelCallSuper(param0, param1)");
            ((HImpl) ((com.huawei.hms.maps.model.StreetViewPanoramaLocation) this.getHInstance())).writeToParcelCallSuper(param0, param1);
        }
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaLocation.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model StreetViewPanoramaLocation object
     */
    public static org.xms.g.maps.model.StreetViewPanoramaLocation dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.StreetViewPanoramaLocation) param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaLocation.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.StreetViewPanoramaLocation;
    }
    
    private class HImpl extends com.huawei.hms.maps.model.StreetViewPanoramaLocation {
        
        public boolean equals(java.lang.Object param0) {
            return org.xms.g.maps.model.StreetViewPanoramaLocation.this.equals(param0);
        }
        
        public int hashCode() {
            return org.xms.g.maps.model.StreetViewPanoramaLocation.this.hashCode();
        }
        
        public java.lang.String toString() {
            return org.xms.g.maps.model.StreetViewPanoramaLocation.this.toString();
        }
        
        public void writeToParcel(android.os.Parcel param0, int param1) {
            org.xms.g.maps.model.StreetViewPanoramaLocation.this.writeToParcel(param0, param1);
        }
        
        public boolean equalsCallSuper(java.lang.Object param0) {
            return super.equals(param0);
        }
        
        public int hashCodeCallSuper() {
            return super.hashCode();
        }
        
        public java.lang.String toStringCallSuper() {
            return super.toString();
        }
        
        public void writeToParcelCallSuper(android.os.Parcel param0, int param1) {
            super.writeToParcel(param0, param1);
        }
        
        public HImpl(com.huawei.hms.maps.model.StreetViewPanoramaLink[] param0, com.huawei.hms.maps.model.LatLng param1, java.lang.String param2) {
            super(param0, param1, param2);
        }
        
        protected HImpl(android.os.Parcel param0) {
            super(param0);
        }
    }
}