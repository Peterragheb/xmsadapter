package org.xms.g.maps.model;

/**
 * xms An immutable class representing a pair of latitude and longitude coordinates, stored as degrees.<br/>
 * Wrapper class for com.huawei.hms.maps.model.LatLng, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.LatLng: An immutable class that represents the longitude and latitude, in degrees.<br/>
 */
public final class LatLng extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.LatLng.CREATOR: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.LatLng createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.LatLng hReturn = com.huawei.hms.maps.model.LatLng.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.LatLng[] newArray(int param0) {
            return new org.xms.g.maps.model.LatLng[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.LatLng.LatLng(org.xms.g.utils.XBox) An immutable class representing a pair of latitude and longitude coordinates, stored as degrees.<br/>
     * com.huawei.hms.maps.model.LatLng.LatLng(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public LatLng(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLng.LatLng(double,double) Constructs a LatLng with the given latitude and longitude, measured in degrees.<br/>
     * com.huawei.hms.maps.model.LatLng.LatLng(double,double): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/latlng-0000001050150800-V5</a><br/>
     *
     * @param param0 The point's latitude. This will be clamped to between -90 degrees and +90 degrees inclusive
     * @param param1 The point's longitude. This will be normalized to be within -180 degrees inclusive and +180 degrees exclusive
     */
    public LatLng(double param0, double param1) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.LatLng(param0, param1));
    }
    
    /**
     * org.xms.g.maps.model.LatLng.getLatitude() Latitude, in degrees.<br/>
     * com.huawei.hms.maps.model.LatLng.latitude: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @return the return object is double
     */
    public double getLatitude() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).latitude");
        return ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).latitude;
    }
    
    /**
     * org.xms.g.maps.model.LatLng.getLongitude() Longitude, in degrees.<br/>
     * com.huawei.hms.maps.model.LatLng.getLongitude(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @return the return object is double
     */
    public double getLongitude() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).longitude");
        return ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).longitude;
    }
    
    /**
     * org.xms.g.maps.model.LatLng.equals(java.lang.Object) Tests if this LatLng is equal to another.<br/>
     * com.huawei.hms.maps.model.LatLng.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLng.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.LatLng.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.LatLng.toString() to String.<br/>
     * com.huawei.hms.maps.model.LatLng.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.LatLng.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.LatLng.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-latlng</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.LatLng) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.LatLng) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.LatLng.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.LatLng.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model LatLng object
     */
    public static org.xms.g.maps.model.LatLng dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.LatLng) param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLng.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.LatLng;
    }
}