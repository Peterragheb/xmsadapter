package org.xms.g.measurement;

/**
 * An Service used by Analytics.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public final class AppMeasurementService extends android.app.Service implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.measurement.AppMeasurementService.AppMeasurementService(org.xms.g.utils.XBox) constructor of AppMeasurementService with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AppMeasurementService(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.AppMeasurementService() constructor of AppMeasurementService.<br/>
     *
     */
    public AppMeasurementService() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final android.os.IBinder onBind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onCreate() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onDestroy() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onRebind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final int onStartCommand(android.content.Intent param0, int param1, int param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final boolean onUnbind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.measurement.AppMeasurementService.<br/>
     *
     * @param param0 the input object
     * @return casted AppMeasurementService object
     */
    public static org.xms.g.measurement.AppMeasurementService dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}