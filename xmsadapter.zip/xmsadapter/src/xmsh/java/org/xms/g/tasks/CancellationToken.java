package org.xms.g.tasks;




/**
 * Propagates notification that operations should be canceled.<br/>
 * Wrapper class for com.huawei.hmf.tasks.CancellationToken, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.CancellationToken: Cancels a task using the CancellationToken object.<br/>
 */
public abstract class CancellationToken extends org.xms.g.utils.XObject {
    
    
    
    /**
     * org.xms.g.tasks.CancellationToken.CancellationToken(org.xms.g.utils.XBox) constructor of CancellationToken with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public CancellationToken(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.tasks.CancellationToken.isCancellationRequested() Checks if cancellation has been requested from the CancellationTokenSource.<br/>
     * com.huawei.hmf.tasks.CancellationToken.isCancellationRequested(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cancellationtoken-0000001050123105-V5#EN-US_TOPIC_0000001050123105__section10478151064312">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cancellationtoken-0000001050123105-V5#EN-US_TOPIC_0000001050123105__section10478151064312</a><br/>
     *
     * @return true if cancellation is requested, false otherwise
     */
    public abstract boolean isCancellationRequested();
    
    /**
     * org.xms.g.tasks.CancellationToken.onCanceledRequested(org.xms.g.tasks.OnTokenCanceledListener) Adds an OnTokenCanceledListener to this CancellationToken.<br/>
     * com.huawei.hmf.tasks.CancellationToken.register(com.huawei.hmf.tasks.OnTokenCanceledListener)
     *
     * @param param0 the listener that will fire once the cancellation request succeeds
     * @return CancellationToken instance added with the listener
     */
    public abstract org.xms.g.tasks.CancellationToken onCanceledRequested(org.xms.g.tasks.OnTokenCanceledListener param0);
    
    /**
     * org.xms.g.tasks.CancellationToken.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.CancellationToken.<br/>
     *
     * @param param0 the input object
     * @return casted CancellationToken object
     */
    public static org.xms.g.tasks.CancellationToken dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.CancellationToken) param0);
    }
    
    /**
     * org.xms.g.tasks.CancellationToken.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hmf.tasks.CancellationToken;
    }
    
    /**
     * Propagates notification that operations should be canceled.<br/>
     * Wrapper class for com.huawei.hmf.tasks.CancellationToken, but only the HMS API are provided.<br/>
     * com.huawei.hmf.tasks.CancellationToken: Cancels a task using the CancellationToken object.<br/>
     */
    public static class XImpl extends org.xms.g.tasks.CancellationToken {
        
        
        
        /**
         * org.xms.g.tasks.CancellationToken.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.tasks.CancellationToken.XImpl.isCancellationRequested() Checks if cancellation has been requested from the CancellationTokenSource.<br/>
         * com.huawei.hmf.tasks.CancellationToken.isCancellationRequested(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cancellationtoken-0000001050123105-V5#EN-US_TOPIC_0000001050123105__section10478151064312">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cancellationtoken-0000001050123105-V5#EN-US_TOPIC_0000001050123105__section10478151064312</a><br/>
         *
         * @return true if cancellation is requested, false otherwise
         */
        public boolean isCancellationRequested() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hmf.tasks.CancellationToken) this.getHInstance()).isCancellationRequested()");
            return ((com.huawei.hmf.tasks.CancellationToken) this.getHInstance()).isCancellationRequested();
        }
        
        /**
         * org.xms.g.tasks.CancellationToken.XImpl.onCanceledRequested(org.xms.g.tasks.OnTokenCanceledListener) Adds an OnTokenCanceledListener to this CancellationToken.<br/>
         * com.huawei.hmf.tasks.CancellationToken.register(com.huawei.hmf.tasks.OnTokenCanceledListener)
         *
         * @param param0 the listener that will fire once the cancellation request succeeds
         * @return CancellationToken instance added with the listener
         */
        public org.xms.g.tasks.CancellationToken onCanceledRequested(org.xms.g.tasks.OnTokenCanceledListener param0) {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hmf.tasks.CancellationToken) this.getHInstance()).register(action)");
            com.huawei.hmf.tasks.CancellationToken hReturn = null;
            Runnable action = new Runnable() {
                @Override
                public void run() {
                    param0.onCanceled();
                }
            };
            hReturn = ((com.huawei.hmf.tasks.CancellationToken) this.getHInstance()).register(action);
            if (hReturn == null) {
                return null;
            }
            return new org.xms.g.tasks.CancellationToken.XImpl(new org.xms.g.utils.XBox(hReturn));
        }
    }
}