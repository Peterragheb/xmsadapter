package org.xms.g.maps.model;

/**
 * xms Defines options for a TileOverlay.<br/>
 * Wrapper class for com.huawei.hms.maps.model.TileOverlayOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.TileOverlayOptions: Defines attributes of a TileOverlay object.<br/>
 */
public final class TileOverlayOptions extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.TileOverlayOptions.CREATOR: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.TileOverlayOptions createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.TileOverlayOptions hReturn = com.huawei.hms.maps.model.TileOverlayOptions.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.TileOverlayOptions[] newArray(int param0) {
            return new org.xms.g.maps.model.TileOverlayOptions[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.TileOverlayOptions(org.xms.g.utils.XBox) Defines options for a TileOverlay.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.TileOverlayOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public TileOverlayOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.TileOverlayOptions() Defines options for a TileOverlay.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.TileOverlayOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tileoverlayoptions-0000001050153331-V5</a><br/>
     *
     */
    public TileOverlayOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.TileOverlayOptions());
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.fadeIn(boolean) Specifies whether the tiles should fade in.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.fadeIn(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#fadeIn(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#fadeIn(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this TileOverlayOptions object with a new visibility setting
     */
    public final org.xms.g.maps.model.TileOverlayOptions fadeIn(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).fadeIn(param0)");
        com.huawei.hms.maps.model.TileOverlayOptions hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).fadeIn(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.getFadeIn() Gets whether the tiles should fade in.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.getFadeIn(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getFadeIn()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getFadeIn()</a><br/>
     *
     * @return true if the tiles are to fade in; false if it is not
     */
    public final boolean getFadeIn() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getFadeIn()");
        return ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getFadeIn();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.getTileProvider() Gets the tile provider set for this TileOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.getTileProvider(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getTileProvider()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getTileProvider()</a><br/>
     *
     * @return the TileProvider of the tile overlay
     */
    public final org.xms.g.maps.model.TileProvider getTileProvider() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getTileProvider()");
        com.huawei.hms.maps.model.TileProvider hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getTileProvider();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileProvider.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.getTransparency() Gets the transparency set for this TileOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.getTransparency(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getTransparency()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getTransparency()</a><br/>
     *
     * @return the transparency of the tile overlay
     */
    public final float getTransparency() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getTransparency()");
        return ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getTransparency();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.getZIndex() Gets the zIndex set for this TileOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#getZIndex()</a><br/>
     *
     * @return the zIndex of the tile overlay
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.isVisible() Gets the visibility setting for this TileOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#isVisible()</a><br/>
     *
     * @return true if the tile overlay is to be visible; false if it is not
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.tileProvider(org.xms.g.maps.model.TileProvider) Specifies the tile provider to use for this tile overlay.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.tileProvider(com.huawei.hms.maps.model.TileProvider): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#tileProvider(TileProvider)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#tileProvider(TileProvider)</a><br/>
     *
     * @param param0 the TileProvider to use for this tile overlay
     * @return the object for which the method was called, with the new tile provider set
     */
    public final org.xms.g.maps.model.TileOverlayOptions tileProvider(org.xms.g.maps.model.TileProvider param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).tileProvider(((param0) == null ? null : (param0.getHInstanceTileProvider())))");
        com.huawei.hms.maps.model.TileOverlayOptions hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).tileProvider(((param0) == null ? null : (param0.getHInstanceTileProvider())));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.transparency(float) Specifies the transparency of the tile overlay. The default transparency is 0(opaque).<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.transparency(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#transparency(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#transparency(float)</a><br/>
     *
     * @param param0 a float in the range [0..1] where 0 means that the tile overlay is opaque and 1 means that the tile overlay is transparent
     * @throws java.lang.IllegalArgumentException if the transparency is outside the range[0..1]
     * @return this TileOverlayOptions object with a new transparency setting
     */
    public final org.xms.g.maps.model.TileOverlayOptions transparency(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).transparency(param0)");
        com.huawei.hms.maps.model.TileOverlayOptions hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).transparency(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.visible(boolean) Specifies the visibility for the tile overlay. The default visibility is true.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.visible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#visible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#visible(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this TileOverlayOptions object with a new visibility setting
     */
    public final org.xms.g.maps.model.TileOverlayOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).visible(param0)");
        com.huawei.hms.maps.model.TileOverlayOptions hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).visible(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#writeToParcel()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#writeToParcel()</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.zIndex(float) Specifies the tile overlay's zIndex, i.e., the order in which it will be drawn where overlays with larger values are drawn above those with lower values. See the documentation at the top of this class for more information about zIndex.<br/>
     * com.huawei.hms.maps.model.TileOverlayOptions.zIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#zIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tileoverlayo#zIndex(float)</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this TileOverlayOptions object with a new zIndex set
     */
    public final org.xms.g.maps.model.TileOverlayOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).zIndex(param0)");
        com.huawei.hms.maps.model.TileOverlayOptions hReturn = ((com.huawei.hms.maps.model.TileOverlayOptions) this.getHInstance()).zIndex(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.TileOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.TileOverlayOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model TileOverlayOptions object
     */
    public static org.xms.g.maps.model.TileOverlayOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.TileOverlayOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlayOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.TileOverlayOptions;
    }
}