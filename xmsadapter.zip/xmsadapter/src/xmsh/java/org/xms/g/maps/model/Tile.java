package org.xms.g.maps.model;

/**
 * xms Contains information about a Tile that is returned by a TileProvider.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Tile, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Tile: Defines the minimum unit of a tile overlay. To create a Tile object, call the TileProvider method.<br/>
 */
public final class Tile extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.Tile.CREATOR: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.Tile createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.Tile hReturn = com.huawei.hms.maps.model.Tile.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.Tile(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.Tile[] newArray(int param0) {
            return new org.xms.g.maps.model.Tile[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.Tile.Tile(org.xms.g.utils.XBox) Defines the minimum unit of a tile overlay.<br/>
     * com.huawei.hms.maps.model.Tile.Tile(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Tile(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Tile.Tile(int,int,byte[]) Defines the minimum unit of a tile overlay.<br/>
     * com.huawei.hms.maps.model.Tile.Tile(int,int,byte[]): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tile-0000001050153285-V5</a><br/>
     *
     * @param param0 A byte array containing the image data. The image will be created from this data by calling decodeByteArray(byte[], int, int)
     * @param param1 the width of the image in pixels
     * @param param2 the height of the image in pixels
     */
    public Tile(int param0, int param1, byte[] param2) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.Tile(param0, param1, param2));
    }
    
    /**
     * org.xms.g.maps.model.Tile.getData() A byte array containing the image data. The image will be created from this data by calling decodeByteArray(byte[], int, int).<br/>
     * com.huawei.hms.maps.model.Tile.data: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile</a><br/>
     *
     * @return the return object is byte[]
     */
    public byte[] getData() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Tile) this.getHInstance()).data");
        return ((com.huawei.hms.maps.model.Tile) this.getHInstance()).data;
    }
    
    /**
     * org.xms.g.maps.model.Tile.getHeight() The height of the image encoded by data in pixels.<br/>
     * com.huawei.hms.maps.model.Tile.height: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile</a><br/>
     *
     * @return the return object is int
     */
    public int getHeight() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Tile) this.getHInstance()).height");
        return ((com.huawei.hms.maps.model.Tile) this.getHInstance()).height;
    }
    
    /**
     * org.xms.g.maps.model.Tile.getWidth() The width of the image encoded by data in pixels.<br/>
     * com.huawei.hms.maps.model.Tile.width: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile</a><br/>
     *
     * @return the return object is int
     */
    public int getWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Tile) this.getHInstance()).width");
        return ((com.huawei.hms.maps.model.Tile) this.getHInstance()).width;
    }
    
    /**
     * org.xms.g.maps.model.Tile.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.Tile.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-tile</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Tile) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.Tile) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.Tile.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Tile.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Tile object
     */
    public static org.xms.g.maps.model.Tile dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Tile) param0);
    }
    
    /**
     * org.xms.g.maps.model.Tile.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Tile;
    }
}