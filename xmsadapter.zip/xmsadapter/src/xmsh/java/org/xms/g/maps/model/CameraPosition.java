package org.xms.g.maps.model;

/**
 * xms An immutable class that aggregates all camera position parameters such as location, zoom level, tilt angle, and bearing.<br/>
 * Wrapper class for com.huawei.hms.maps.model.CameraPosition, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.CameraPosition: An immutable class that encapsulates all camera attributes.<br/>
 */
public final class CameraPosition extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.CameraPosition.CameraPosition(org.xms.g.utils.XBox) An immutable class that aggregates all camera position parameters such as location, zoom level, tilt angle, and bearing.<br/>
     * com.huawei.hms.maps.model.CameraPosition.CameraPosition(): <a href="https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cameraposition-0000001050152443-V5">https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cameraposition-0000001050152443-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public CameraPosition(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.CameraPosition(org.xms.g.maps.model.LatLng,float,float,float) An immutable class that aggregates all camera position parameters such as location, zoom level, tilt angle, and bearing.<br/>
     * com.huawei.hms.maps.model.CameraPosition.CameraPosition(com.huawei.hms.maps.model.LatLng,float,float,float): <a href="https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cameraposition-0000001050152443-V5">https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cameraposition-0000001050152443-V5</a><br/>
     *
     * @param param0 Direction that the camera is pointing in, in degrees clockwise from north. This value will be normalized to be within 0 degrees inclusive and 360 degrees exclusive
     * @param param1 Zoom level at target. See zoom(float) for details of restrictions
     * @param param2 The camera angle, in degrees, from the nadir (directly down). See tilt(float) for details of restrictions
     * @param param3 The target location to align with the center of the screen
     * @throws java.lang.NullPointerException if target is null
     * @throws java.lang.IllegalArgumentException if tilt is outside the range of 0 to 90 degrees inclusive
     */
    public CameraPosition(org.xms.g.maps.model.LatLng param0, float param1, float param2, float param3) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.CameraPosition(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1, param2, param3));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.getBearing() Direction that the camera is pointing in, in degrees clockwise from north.<br/>
     * com.huawei.hms.maps.model.CameraPosition.bearing: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is float
     */
    public float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).bearing");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).bearing;
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.getTarget() The location that the camera is pointing at.<br/>
     * com.huawei.hms.maps.model.CameraPosition.target: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getTarget() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).target");
        com.huawei.hms.maps.model.LatLng hReturn = null;
        hReturn = ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).target;
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.getTilt() The angle, in degrees, of the camera angle from the nadir(directly facing the Earth). See tilt(float)for details of restrictions on the range of values.<br/>
     * com.huawei.hms.maps.model.CameraPosition.tilt: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is float
     */
    public float getTilt() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).tilt");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).tilt;
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.getZoom() Zoom level near the center of the screen. See zoom(float)for the definition of the camera's zoom level.<br/>
     * com.huawei.hms.maps.model.CameraPosition.zoom: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is float
     */
    public float getZoom() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).zoom");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).zoom;
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.builder(org.xms.g.maps.model.CameraPosition) Obtains a CameraPosition.Builder object for modifying camera attributes.<br/>
     * com.huawei.hms.maps.model.CameraPosition.builder(com.huawei.hms.maps.model.CameraPosition): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#builder(CameraPosition)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#builder(CameraPosition)</a><br/>
     *
     * @param param0 the param should instanceof maps model CameraPosition
     * @return the return object is maps model CameraPosition Builder
     */
    public static org.xms.g.maps.model.CameraPosition.Builder builder(org.xms.g.maps.model.CameraPosition param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.CameraPosition.builder(((com.huawei.hms.maps.model.CameraPosition) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.CameraPosition.Builder hReturn = com.huawei.hms.maps.model.CameraPosition.builder(((com.huawei.hms.maps.model.CameraPosition) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.builder() Obtains a CameraPosition.Builder object for modifying camera attributes.<br/>
     * com.huawei.hms.maps.model.CameraPosition.builder(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#builder()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#builder()</a><br/>
     *
     * @return the return object is maps model CameraPosition Builder
     */
    public static org.xms.g.maps.model.CameraPosition.Builder builder() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.CameraPosition.builder()");
        com.huawei.hms.maps.model.CameraPosition.Builder hReturn = com.huawei.hms.maps.model.CameraPosition.builder();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.createFromAttributes(android.content.Context,android.util.AttributeSet) Creates a CameraPosition object with specified attributes.<br/>
     * com.huawei.hms.maps.model.CameraPosition.createFromAttributes(android.content.Context,android.util.AttributeSet): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#createFromAttributes(Context,AttributeSet)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#createFromAttributes(Context,AttributeSet)</a><br/>
     *
     * @param param0 the param should instanceof android content Context
     * @param param1 the param should instanceof android util AttributeSet
     * @return the return object is maps model CameraPosition
     */
    public static final org.xms.g.maps.model.CameraPosition createFromAttributes(android.content.Context param0, android.util.AttributeSet param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.CameraPosition.createFromAttributes(param0, param1)");
        com.huawei.hms.maps.model.CameraPosition hReturn = com.huawei.hms.maps.model.CameraPosition.createFromAttributes(param0, param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.equals(java.lang.Object) weather equals .<br/>
     * com.huawei.hms.maps.model.CameraPosition.equals(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.fromLatLngZoom(org.xms.g.maps.model.LatLng,float) Constructs a CameraPosition pointed for a particular target and zoom level. The resultant bearing is North, and the viewing angle is perpendicular to the Earth's surface. i.e., directly facing the Earth's surface, with the top of the screen pointing North.<br/>
     * com.huawei.hms.maps.model.LatLng.fromLatLngZoom(com.huawei.hms.maps.model.LatLng,float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#fromLatLngZoom(LatLng,float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition#fromLatLngZoom(LatLng,float)</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @param param1 the param should instanceof float
     * @return the return object is maps model CameraPosition
     */
    public static final org.xms.g.maps.model.CameraPosition fromLatLngZoom(org.xms.g.maps.model.LatLng param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.CameraPosition.fromLatLngZoom(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1)");
        com.huawei.hms.maps.model.CameraPosition hReturn = com.huawei.hms.maps.model.CameraPosition.fromLatLngZoom(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.CameraPosition.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.toString() to String.<br/>
     * com.huawei.hms.maps.model.CameraPosition.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.writeToParcel(android.os.Parcel,int) write To Parcel.<br/>
     * com.huawei.hms.maps.model.CameraPosition.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cameraposition</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.CameraPosition) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.CameraPosition.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model CameraPosition object
     */
    public static org.xms.g.maps.model.CameraPosition dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.CameraPosition) param0);
    }
    
    /**
     * org.xms.g.maps.model.CameraPosition.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.CameraPosition;
    }
    
    /**
     * Builds camera position.<br/>
     * Wrapper class for com.huawei.hms.maps.model.CameraPosition.Builder, but only the HMS API are provided.<br/>
     * com.huawei.hms.maps.model.CameraPosition.Builder: An internal API of the CameraPosition class. The API contains the build(), bearing(float bearing), target(LatLng location), tilt(float tilt), and zoom(float zoom) methods.<br/>
     */
    public static final class Builder extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.Builder(org.xms.g.utils.XBox) Builds camera position.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.Builder(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5</a><br/>
         *
         * @param param0 the param should instanceof utils XBox
         */
        public Builder(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.Builder() Builds camera position.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.Builder(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5</a><br/>
         *
         */
        public Builder() {
            super(((org.xms.g.utils.XBox) null));
            this.setHInstance(new com.huawei.hms.maps.model.CameraPosition.Builder());
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.Builder(org.xms.g.maps.model.CameraPosition) Builds camera position.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.Builder(com.huawei.hms.maps.model.CameraPosition): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/cameraposition-builder-0000001050150514-V5</a><br/>
         *
         * @param param0 the param should instanceof maps model CameraPosition
         */
        public Builder(org.xms.g.maps.model.CameraPosition param0) {
            super(((org.xms.g.utils.XBox) null));
            this.setHInstance(new com.huawei.hms.maps.model.CameraPosition.Builder(((com.huawei.hms.maps.model.CameraPosition) ((param0) == null ? null : (param0.getHInstance())))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.bearing(float) Sets the direction that the camera is pointing in, in degrees clockwise from north.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.bearing(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#bearing(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#bearing(float)</a><br/>
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model CameraPosition Builder
         */
        public final org.xms.g.maps.model.CameraPosition.Builder bearing(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).bearing(param0)");
            com.huawei.hms.maps.model.CameraPosition.Builder hReturn = ((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).bearing(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.build() Builds a CameraPosition object.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.build(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#build()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#build()</a><br/>
         *
         * @return the return object is maps model CameraPosition
         */
        public final org.xms.g.maps.model.CameraPosition build() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).build()");
            com.huawei.hms.maps.model.CameraPosition hReturn = ((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).build();
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.target(org.xms.g.maps.model.LatLng) Sets the location that the camera is pointing at.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.target(com.huawei.hms.maps.model.LatLng): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#target(LatLng)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#target(LatLng)</a><br/>
         *
         * @param param0 the param should instanceof maps model LatLng
         * @return the return object is maps model CameraPosition Builder
         */
        public final org.xms.g.maps.model.CameraPosition.Builder target(org.xms.g.maps.model.LatLng param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).target(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))))");
            com.huawei.hms.maps.model.CameraPosition.Builder hReturn = ((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).target(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))));
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.tilt(float) Sets the angle of the camera from the nadir(directly facing the Earth's surface).<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.tilt(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#tilt(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#tilt(float)</a><br/>
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model CameraPosition Builder
         */
        public final org.xms.g.maps.model.CameraPosition.Builder tilt(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).tilt(param0)");
            com.huawei.hms.maps.model.CameraPosition.Builder hReturn = ((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).tilt(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.zoom(float) Sets the zoom level of the camera.<br/>
         * com.huawei.hms.maps.model.CameraPosition.Builder.zoom(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#zoom(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-camerapositionb#zoom(float)</a><br/>
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model CameraPosition Builder
         */
        public final org.xms.g.maps.model.CameraPosition.Builder zoom(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).zoom(param0)");
            com.huawei.hms.maps.model.CameraPosition.Builder hReturn = ((com.huawei.hms.maps.model.CameraPosition.Builder) this.getHInstance()).zoom(param0);
            return ((hReturn) == null ? null : (new org.xms.g.maps.model.CameraPosition.Builder(new org.xms.g.utils.XBox(hReturn))));
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.CameraPosition.Builder.<br/>
         *
         * @param param0 the param should instanceof java lang Object
         * @return cast maps model CameraPosition Builder object
         */
        public static org.xms.g.maps.model.CameraPosition.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.maps.model.CameraPosition.Builder) param0);
        }
        
        /**
         * org.xms.g.maps.model.CameraPosition.Builder.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.CameraPosition.Builder;
        }
    }
}