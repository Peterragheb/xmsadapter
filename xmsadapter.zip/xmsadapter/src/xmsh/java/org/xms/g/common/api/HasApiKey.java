package org.xms.g.common.api;

/**
 * Anything that has an ApiKey.This is used to allow clients to be exposed via interface instead of subclass. Those interfaces can be declared as extending this, and Api's will automatically fulfill the interface.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public interface HasApiKey<XO extends org.xms.g.common.api.Api.ApiOptions> extends org.xms.g.utils.XInterface {
    
    /**
     * XMS does not provide this api.<br/>
     */
    public java.lang.Object getApiKey();
    
    default java.lang.Object getZInstanceHasApiKey() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    default java.lang.Object getHInstanceHasApiKey() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.HasApiKey.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.HasApiKey.<br/>
     *
     * @param param0 the input object
     * @return casted HasApiKey object
     */
    public static org.xms.g.common.api.HasApiKey dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.HasApiKey.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * Wrapper class of HasApiKey that has an ApiKey.This is used to allow clients to be exposed via interface instead of subclass. Those interfaces can be declared as extending this, and Api's will automatically fulfill the interface.<br/>
     * Wrapper class for , but only the HMS API are provided.<br/>
     * : <br/>
     */
    public static class XImpl<XO extends org.xms.g.common.api.Api.ApiOptions> extends org.xms.g.utils.XObject implements org.xms.g.common.api.HasApiKey<XO> {
        
        /**
         * org.xms.g.common.api.HasApiKey.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public java.lang.Object getApiKey() {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}