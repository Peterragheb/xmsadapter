package org.xms.g.tasks;

/**
 * Listener called when a Task completes.<br/>
 * Wrapper class for com.huawei.hmf.tasks.OnCompleteListener<TResult>, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.OnCompleteListener<TResult>: Called when the task is completed.<br/>
 */
public interface OnCompleteListener<XTResult> extends org.xms.g.utils.XInterface {
    
    /**
     * org.xms.g.tasks.OnCompleteListener.onComplete(org.xms.g.tasks.Task<XTResult>) Called when the Task completes.<br/>
     * com.huawei.hmf.tasks.OnCompleteListener.onComplete(com.google.android.gms.tasks.Task<TResult>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/oncompletelistener-0000001050121142#EN-US_TOPIC_0000001050121142__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/oncompletelistener-0000001050121142#EN-US_TOPIC_0000001050121142__section32821622269</a><br/>
     *
     * @param param0 the completed Task. Never null
     */
    public void onComplete(org.xms.g.tasks.Task<XTResult> param0);
    
    default java.lang.Object getZInstanceOnCompleteListener() {
        return getHInstanceOnCompleteListener();
    }
    
    default <TResult> com.huawei.hmf.tasks.OnCompleteListener<TResult> getHInstanceOnCompleteListener() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hmf.tasks.OnCompleteListener<TResult>) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hmf.tasks.OnCompleteListener<TResult>() {
            
            public void onComplete(com.huawei.hmf.tasks.Task<TResult> param0) {
                org.xms.g.tasks.OnCompleteListener.this.onComplete(((param0) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(param0)))));
            }
        };
    }
    
    /**
     * org.xms.g.tasks.OnCompleteListener.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.OnCompleteListener.<br/>
     *
     * @param param0 the input object
     * @return casted OnCompleteListener object
     */
    public static org.xms.g.tasks.OnCompleteListener dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.OnCompleteListener) param0);
    }
    
    /**
     * org.xms.g.tasks.OnCompleteListener.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hmf.tasks.OnCompleteListener;
        }
        return param0 instanceof org.xms.g.tasks.OnCompleteListener;
    }
    
    /**
     * Listener called when a Task completes.<br/>
     * Wrapper class for com.huawei.hmf.tasks.OnCompleteListener<TResult>, but only the HMS API are provided.<br/>
     * com.huawei.hmf.tasks.OnCompleteListener<TResult>: Called when the task is completed.<br/>
     */
    public static class XImpl<XTResult> extends org.xms.g.utils.XObject implements org.xms.g.tasks.OnCompleteListener<XTResult> {
        
        /**
         * org.xms.g.tasks.OnCompleteListener.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.tasks.OnCompleteListener.XImpl.onComplete(org.xms.g.tasks.Task<XTResult>) Called when the Task completes.<br/>
         * com.huawei.hmf.tasks.OnCompleteListener.onComplete(com.google.android.gms.tasks.Task<TResult>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/oncompletelistener-0000001050121142#EN-US_TOPIC_0000001050121142__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/oncompletelistener-0000001050121142#EN-US_TOPIC_0000001050121142__section32821622269</a><br/>
         *
         * @param param0 the completed Task. Never null
         */
        public void onComplete(org.xms.g.tasks.Task<XTResult> param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hmf.tasks.OnCompleteListener) this.getHInstance()).onComplete(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))))");
            ((com.huawei.hmf.tasks.OnCompleteListener) this.getHInstance()).onComplete(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))));
        }
    }
}