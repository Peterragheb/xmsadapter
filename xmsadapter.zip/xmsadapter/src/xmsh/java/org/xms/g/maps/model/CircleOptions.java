package org.xms.g.maps.model;

/**
 * xms Defines options for a Circle.<br/>
 * Wrapper class for com.huawei.hms.maps.model.CircleOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.CircleOptions: Defines attributes for a Circle object.<br/>
 */
public final class CircleOptions extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.CircleOptions.CircleOptions(org.xms.g.utils.XBox) Defines options for a Circle.<br/>
     * com.huawei.hms.maps.model.CircleOptions.CircleOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/circleoptions-0000001050150596-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/circleoptions-0000001050150596-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public CircleOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.CircleOptions() Defines options for a Circle.<br/>
     * com.huawei.hms.maps.model.CircleOptions.CircleOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/circleoptions-0000001050150596-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/circleoptions-0000001050150596-V5</a><br/>
     *
     */
    public CircleOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.CircleOptions());
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.center(org.xms.g.maps.model.LatLng) Sets the center using a LatLng.<br/>
     * com.huawei.hms.maps.model.CircleOptions.center(com.huawei.hms.maps.model.LatLng): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#center(LatLng)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#center(LatLng)</a><br/>
     *
     * @param param0 The geographic center as a LatLng
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions center(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).center(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).center(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.clickable(boolean) Specifies whether this circle is clickable. The default setting is false.<br/>
     * com.huawei.hms.maps.model.CircleOptions.clickable(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#clickable(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#clickable(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this CircleOptions object with a new clickability setting
     */
    public final org.xms.g.maps.model.CircleOptions clickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).clickable(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).clickable(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.fillColor(int) Sets the fill color.<br/>
     * com.huawei.hms.maps.model.CircleOptions.fillColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#fillColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#fillColor(int)</a><br/>
     *
     * @param param0 color in the Color format
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions fillColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).fillColor(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).fillColor(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getCenter() Returns the center as a LatLng.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getCenter(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getCenter()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getCenter()</a><br/>
     *
     * @return The geographic center as a LatLng
     */
    public final org.xms.g.maps.model.LatLng getCenter() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getCenter()");
        com.huawei.hms.maps.model.LatLng hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getCenter();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getFillColor() Returns the fill color.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getFillColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getFillColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getFillColor()</a><br/>
     *
     * @return The color in the Color format
     */
    public final int getFillColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getFillColor()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getFillColor();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getRadius() Returns the circle's radius, in meters.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getRadius(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getRadius()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getRadius()</a><br/>
     *
     * @return The radius in meters
     */
    public final double getRadius() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getRadius()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getRadius();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokeColor() Returns the stroke color.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getStrokeColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokeColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokeColor()</a><br/>
     *
     * @return The color in the Color format
     */
    public final int getStrokeColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokeColor()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokeColor();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokePattern() Returns the stroke pattern set in this CircleOptions object for the circle's outline.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getStrokePattern(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokePattern()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokePattern()</a><br/>
     *
     * @return the stroke pattern of the circle's outline
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getStrokePattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokePattern()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokePattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.huawei.hms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokeWidth() Returns the stroke width.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getStrokeWidth(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokeWidth()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getStrokeWidth()</a><br/>
     *
     * @return The width in screen pixels
     */
    public final float getStrokeWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokeWidth()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getStrokeWidth();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getZIndex() Returns the zIndex.<br/>
     * com.huawei.hms.maps.model.CircleOptions.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#getZIndex()</a><br/>
     *
     * @return The zIndex value
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isClickable() Gets the clickability setting for the circle.<br/>
     * com.huawei.hms.maps.model.CircleOptions.isClickable(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#isClickable()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#isClickable()</a><br/>
     *
     * @return true if the circle is clickable; false if it is not
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).isClickable()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isVisible() Checks whether the circle is visible.<br/>
     * com.huawei.hms.maps.model.CircleOptions.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#isVisible()</a><br/>
     *
     * @return true if the circle is visible; false if it is invisible
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.radius(double) Sets the radius in meters.<br/>
     * com.huawei.hms.maps.model.CircleOptions.radius(double): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#radius(double)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#radius(double)</a><br/>
     *
     * @param param0 radius in meters
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions radius(double param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).radius(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).radius(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokeColor(int) Sets the stroke color.<br/>
     * com.huawei.hms.maps.model.CircleOptions.strokeColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokeColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokeColor(int)</a><br/>
     *
     * @param param0 color in the Color format
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions strokeColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokeColor(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokeColor(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokePattern(java.util.List) Sets a stroke pattern for the circle's outline. The default stroke pattern is solid, represented by null.<br/>
     * com.huawei.hms.maps.model.CircleOptions.strokePattern(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokePattern(List%3CPatternItem%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokePattern(List%3CPatternItem%3E)</a><br/>
     *
     * @param param0 the param should instanceof java util List
     * @return the return object is maps model CircleOptions
     */
    public final org.xms.g.maps.model.CircleOptions strokePattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokeWidth(float) Sets the stroke width.<br/>
     * com.huawei.hms.maps.model.CircleOptions.strokeWidth(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokeWidth(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#strokeWidth(float)</a><br/>
     *
     * @param param0 width in screen pixels
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions strokeWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokeWidth(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).strokeWidth(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.visible(boolean) Sets the visibility.<br/>
     * com.huawei.hms.maps.model.CircleOptions.visible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#visible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#visible(boolean)</a><br/>
     *
     * @param param0 false to make this circle invisible
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).visible(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).visible(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.zIndex(float) Sets the zIndex.<br/>
     * com.huawei.hms.maps.model.CircleOptions.zIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#zIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-circleoptions#zIndex(float)</a><br/>
     *
     * @param param0 zIndex value
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).zIndex(param0)");
        com.huawei.hms.maps.model.CircleOptions hReturn = ((com.huawei.hms.maps.model.CircleOptions) this.getHInstance()).zIndex(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.CircleOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model CircleOptions object
     */
    public static org.xms.g.maps.model.CircleOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.CircleOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.CircleOptions;
    }
}