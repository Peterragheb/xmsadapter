package org.xms.g.common.api;




/**
 * Transforms a Result by making a subsequent API call.<br/>
 * Wrapper class for com.huawei.hms.support.api.client.ResultConvert, but only the HMS API are provided.<br/>
 * com.huawei.hms.support.api.client.ResultConvert: <br/>
 */
public abstract class ResultTransform<XR extends org.xms.g.common.api.Result, XS extends org.xms.g.common.api.Result> extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    
    
    /**
     * org.xms.g.common.api.ResultTransform.ResultTransform(org.xms.g.utils.XBox) constructor of ResultTransform with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ResultTransform(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ResultTransform.ResultTransform() constructor of ResultTransform.<br/>
     * com.huawei.hms.support.api.client.ResultConvert.ResultConvert()
     *
     */
    public ResultTransform() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new HImpl());
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ResultTransform.createFailedResult(org.xms.g.common.api.Status) Creates a failed result with the given Status.<br/>
     * com.huawei.hms.support.api.client.ResultConvert.newFailedPendingResult(com.huawei.hms.support.api.client.Status)
     *
     * @param param0 Status instance
     * @return PendingResult instance
     */
    public final org.xms.g.common.api.PendingResult<XS> createFailedResult(org.xms.g.common.api.Status param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).newFailedPendingResult(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.support.api.client.PendingResult hReturn = ((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).newFailedPendingResult(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.common.api.PendingResult.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.common.api.ResultTransform.onFailure(org.xms.g.common.api.Status) Called when the PendingResult to be transformed returns a failure.<br/>
     * com.huawei.hms.support.api.client.ResultConvert.onFailed(com.huawei.hms.support.api.client.Status)
     *
     * @param param0 The status of the failure
     * @return The status of the result of the transformation. Must not be success or null
     */
    public org.xms.g.common.api.Status onFailure(org.xms.g.common.api.Status param0) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).onFailed(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
            com.huawei.hms.support.api.client.Status hReturn = ((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).onFailed(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
            return ((hReturn) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(hReturn))));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance())).onFailedCallSuper(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
            com.huawei.hms.support.api.client.Status hReturn = ((HImpl) ((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance())).onFailedCallSuper(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
            return ((hReturn) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(hReturn))));
        }
    }
    
    /**
     * org.xms.g.common.api.ResultTransform.onSuccess(XR) Transforms the result of a successful API call.<br/>
     * com.huawei.hms.support.api.client.ResultConvert.onSuccess(com.huawei.hms.support.api.client.Result)
     *
     * @param param0 The successful result to be transformed. Never null. If this result is Releasable it will be automatically released after this transform is applied; it is not necessary to release the result inside onSuccess. It is an error to set callbacks on this result. Any callbacks set on this result will be overridden and will not be called
     * @return The result of the transformation. Normally the result of another API call. To shortcut execution and directly yield a failure, return either:null, which is translated into a Status with code ERROR; or a specific failure created using createFailedResult(Status)
     */
    public abstract org.xms.g.common.api.PendingResult<XS> onSuccess(XR param0);
    
    /**
     * org.xms.g.common.api.ResultTransform.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ResultTransform.<br/>
     *
     * @param param0 the input object
     * @return casted ResultTransform object
     */
    public static org.xms.g.common.api.ResultTransform dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.ResultTransform) param0);
    }
    
    /**
     * org.xms.g.common.api.ResultTransform.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.support.api.client.ResultConvert;
    }
    
    private class HImpl<R extends com.huawei.hms.support.api.client.Result, S extends com.huawei.hms.support.api.client.Result> extends com.huawei.hms.support.api.client.ResultConvert<R, S> {
        
        
        
        public com.huawei.hms.support.api.client.Status onFailed(com.huawei.hms.support.api.client.Status param0) {
            org.xms.g.common.api.Status xResult = org.xms.g.common.api.ResultTransform.this.onFailure(((param0) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(param0)))));
            return ((com.huawei.hms.support.api.client.Status) ((xResult) == null ? null : (xResult.getHInstance())));
        }
        
        public com.huawei.hms.support.api.client.Status onFailedCallSuper(com.huawei.hms.support.api.client.Status param0) {
            return super.onFailed(param0);
        }
        
        public com.huawei.hms.support.api.client.PendingResult onSuccess(com.huawei.hms.support.api.client.Result param0) {
            throw new java.lang.RuntimeException("Stub");
        }
        
        public HImpl() {
            super();
        }
    }
    
    /**
     * Wrapper class of ResultTransform which transforms a Result by making a subsequent API call.<br/>
     * Wrapper class for com.huawei.hms.support.api.client.ResultConvert, but only the HMS API are provided.<br/>
     * com.huawei.hms.support.api.client.ResultConvert: <br/>
     */
    public static class XImpl<XR extends org.xms.g.common.api.Result, XS extends org.xms.g.common.api.Result> extends org.xms.g.common.api.ResultTransform<XR, XS> {
        
        
        
        /**
         * org.xms.g.common.api.ResultTransform.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.common.api.ResultTransform.XImpl.onSuccess(XR) Transforms the result of a successful API call.<br/>
         * com.huawei.hms.support.api.client.ResultConvert.onSuccess(com.huawei.hms.support.api.client.Result)
         *
         * @param param0 The successful result to be transformed. Never null. If this result is Releasable it will be automatically released after this transform is applied; it is not necessary to release the result inside onSuccess. It is an error to set callbacks on this result. Any callbacks set on this result will be overridden and will not be called
         * @return The result of the transformation. Normally the result of another API call. To shortcut execution and directly yield a failure, return either:null, which is translated into a Status with code ERROR; or a specific failure created using createFailedResult(Status)
         */
        public org.xms.g.common.api.PendingResult<XS> onSuccess(XR param0) {
            
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).onSuccess(((com.huawei.hms.support.api.client.Result) hObj0))");
            java.lang.Object hObj0 = org.xms.g.utils.Utils.getInstanceInInterface(param0, true);
            com.huawei.hms.support.api.client.PendingResult hReturn = null;
            hReturn = ((com.huawei.hms.support.api.client.ResultConvert) this.getHInstance()).onSuccess(((com.huawei.hms.support.api.client.Result) hObj0));
            if (hReturn == null)
                return null;
            return new org.xms.g.common.api.PendingResult.XImpl(new org.xms.g.utils.XBox(hReturn));
        }
    }
}