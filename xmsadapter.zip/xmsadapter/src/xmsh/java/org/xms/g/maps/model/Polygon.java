package org.xms.g.maps.model;

/**
 * xms A polygon on the earth's surface.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Polygon, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Polygon: Defines a polygon on the surface of the Earth. A polygon can be convex or concave. It can span the 180 meridian and have holes that are not filled in.<br/>
 */
public final class Polygon extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.Polygon.Polygon(org.xms.g.utils.XBox) A polygon on the earth's surface.<br/>
     * com.huawei.hms.maps.model.Polygon.Polygon(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygon-0000001050151020-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygon-0000001050151020-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Polygon(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.equals(java.lang.Object) Checks whether a polygon object equals another.<br/>
     * com.huawei.hms.maps.model.Polygon.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#equals(Object)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#equals(Object)</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getFillColor() Obtains the fill color of a polygon, in ARGB format.<br/>
     * com.huawei.hms.maps.model.Polygon.getFillColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getFillColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getFillColor()</a><br/>
     *
     * @return the color in ARGB format
     */
    public final int getFillColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getFillColor()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getFillColor();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getHoles() Returns a snapshot of the holes of this polygon at this time.The list returned is a copy of the list of holes and so changes to the polygon's holes will not be reflected by this list, nor will changes to this list be reflected by the polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.getHoles(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getHoles()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getHoles()</a><br/>
     *
     * @return the return object is java util List<java util List<LatLng>>
     */
    public final java.util.List<java.util.List<org.xms.g.maps.model.LatLng>> getHoles() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getHoles()");
        java.util.List<java.util.List<com.huawei.hms.maps.model.LatLng>> hReturn = ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getHoles();
        return org.xms.g.utils.Utils.mapList(hReturn, e -> org.xms.g.utils.Utils.mapList2X(e, true));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getId() Gets this polygon's id. The id will be unique amongst all Polygons on a map.<br/>
     * com.huawei.hms.maps.model.Polygon.getId(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getId()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getId()</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getId()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getPoints() Returns a snapshot of the vertices of this polygon at this time.The list returned is a copy of the list of vertices and so changes to the polygon's vertices will not be reflected by this list, nor will changes to this list be reflected by the polygon. To change the vertices of the polygon, call setPoints(List).<br/>
     * com.huawei.hms.maps.model.Polygon.getPoints(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getPoints()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getPoints()</a><br/>
     *
     * @return the return object is java util List<LatLng>
     */
    public final java.util.List<org.xms.g.maps.model.LatLng> getPoints() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getPoints()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getPoints();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
            
            public org.xms.g.maps.model.LatLng apply(com.huawei.hms.maps.model.LatLng param0) {
                return new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getStrokeColor() Gets the stroke color of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.getStrokeColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeColor()</a><br/>
     *
     * @return the color in ARGB format
     */
    public final int getStrokeColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeColor()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeColor();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getStrokeJointType() Gets the stroke joint type used at all vertices of the polygon's outline. See JointType for possible values.<br/>
     * com.huawei.hms.maps.model.Polygon.getStrokeJointType(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeJointType()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeJointType()</a><br/>
     *
     * @return the stroke joint type
     */
    public final int getStrokeJointType() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeJointType()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeJointType();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getStrokePattern() Gets the stroke pattern of this polygon's outline.<br/>
     * com.huawei.hms.maps.model.Polygon.getStrokePattern(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokePattern()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokePattern()</a><br/>
     *
     * @return the stroke pattern
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getStrokePattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokePattern()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokePattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.huawei.hms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getStrokeWidth() Gets the stroke width of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.getStrokeWidth(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeWidth()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getStrokeWidth()</a><br/>
     *
     * @return the width in screen pixels
     */
    public final float getStrokeWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeWidth()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getStrokeWidth();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getTag() Gets the tag for the polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.getTag(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getTag()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getTag()</a><br/>
     *
     * @return the tag if a tag was set with setTag; null if no tag has been set
     */
    public final java.lang.Object getTag() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getTag()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getTag();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.getZIndex() Gets the zIndex of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#getZIndex()</a><br/>
     *
     * @return the zIndex of the polygon
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.Polygon.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#hashCode()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#hashCode()</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.isClickable() Gets the clickability of the polygon. If the polygon is clickable, your app will receive notifications to the GoogleMap.OnPolygonClickListener when the user clicks the polygon. The event listener is registered through setOnPolygonClickListener(GoogleMap.OnPolygonClickListener).<br/>
     * com.huawei.hms.maps.model.Polygon.isClickable(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isClickable()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isClickable()</a><br/>
     *
     * @return true if the polygon is clickable; otherwise, returns false
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isClickable()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.isGeodesic() Gets whether each segment of the line is drawn as a geodesic or not.<br/>
     * com.huawei.hms.maps.model.Polygon.isGeodesic(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isGeodesic()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isGeodesic()</a><br/>
     *
     * @return true if each segment is drawn as a geodesic; false if each segment is drawn as a straight line on the Mercator projection
     */
    public final boolean isGeodesic() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isGeodesic()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isGeodesic();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.isVisible() Gets the visibility of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#isVisible()</a><br/>
     *
     * @return this polygon visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.remove() Removes the polygon from the map. After a polygon has been removed, the behavior of all its methods is undefined.<br/>
     * com.huawei.hms.maps.model.Polygon.remove(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#remove()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#remove()</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).remove()");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setClickable(boolean) Sets the clickability of the polygon. If the polygon is clickable, your app will receive notifications to the GoogleMap.OnPolygonClickListener when the user clicks the polygon. The event listener is registered through setOnPolygonClickListener(GoogleMap.OnPolygonClickListener).<br/>
     * com.huawei.hms.maps.model.Polygon.setClickable(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setClickable(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setClickable(boolean)</a><br/>
     *
     * @param param0 New clickability setting for the polygon
     */
    public final void setClickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setClickable(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setClickable(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setFillColor(int) Sets the fill color of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setFillColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setFillColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setFillColor(int)</a><br/>
     *
     * @param param0 the color in ARGB format
     */
    public final void setFillColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setFillColor(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setFillColor(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setGeodesic(boolean) Sets whether to draw each segment of the line as a geodesic or not.<br/>
     * com.huawei.hms.maps.model.Polygon.setGeodesic(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setGeodesic(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setGeodesic(boolean)</a><br/>
     *
     * @param param0 if true, then each segment is drawn as a geodesic; if false, each segment is drawn as a straight line on the Mercator projection
     */
    public final void setGeodesic(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setGeodesic(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setGeodesic(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setHoles(java.util.List) Sets the holes of this polygon. This method will take a copy of the holes, so further mutations to holes will have no effect on this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setHoles(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setHoles(List%3CList%3CLatLng%3E%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setHoles(List%3CList%3CLatLng%3E%3E)</a><br/>
     *
     * @param param0 the param should be instanceof java util List
     */
    public final void setHoles(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setHoles(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setHoles(org.xms.g.utils.Utils.mapList2GH(param0, true));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setPoints(java.util.List) Sets the points of this polygon. This method will take a copy of the points, so further mutations to points will have no effect on this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setPoints(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setPoints(List%3CLatLng%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setPoints(List%3CLatLng%3E)</a><br/>
     *
     * @param param0 the param should be instanceof java util List
     */
    public final void setPoints(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setPoints(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setPoints(org.xms.g.utils.Utils.mapList2GH(param0, true));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setStrokeColor(int) Sets the stroke color of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setStrokeColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeColor(int)</a><br/>
     *
     * @param param0 the color in ARGB format
     */
    public final void setStrokeColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeColor(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeColor(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setStrokeJointType(int) Sets the joint type for all vertices of the polygon's outline.<br/>
     * com.huawei.hms.maps.model.Polygon.setStrokeJointType(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeJointType(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeJointType(int)</a><br/>
     *
     * @param param0 the stroke joint type
     */
    public final void setStrokeJointType(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeJointType(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeJointType(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setStrokePattern(java.util.List) Sets the stroke pattern of the polygon's outline. The default stroke pattern is solid, represented by null.<br/>
     * com.huawei.hms.maps.model.Polygon.setStrokePattern(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokePattern(List%3CPatternItem%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokePattern(List%3CPatternItem%3E)</a><br/>
     *
     * @param param0 the param should be instanceof java util List
     */
    public final void setStrokePattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true));
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setStrokeWidth(float) Sets the stroke width of this polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setStrokeWidth(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeWidth(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setStrokeWidth(float)</a><br/>
     *
     * @param param0 the width in display pixels
     */
    public final void setStrokeWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeWidth(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setStrokeWidth(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setTag(java.lang.Object) Sets the tag for the polygon.<br/>
     * com.huawei.hms.maps.model.Polygon.setTag(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setTag(Object)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setTag(Object)</a><br/>
     *
     * @param param0 if null, the tag is cleared
     */
    public final void setTag(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setTag(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setTag(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setVisible(boolean) Sets the visibility of this polygon. When not visible, a polygon is not drawn, but it keeps all its other properties.<br/>
     * com.huawei.hms.maps.model.Polygon.setVisible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setVisible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setVisible(boolean)</a><br/>
     *
     * @param param0 if true, then the polygon is visible; if false, it is not
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setVisible(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.setZIndex(float) Sets the zIndex of this polygon. Polygons with higher zIndices are drawn above those with lower indices.<br/>
     * com.huawei.hms.maps.model.Polygon.setZIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setZIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygon#setZIndex(float)</a><br/>
     *
     * @param param0 the zIndex of this polygon
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setZIndex(param0)");
        ((com.huawei.hms.maps.model.Polygon) this.getHInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Polygon.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Polygon object
     */
    public static org.xms.g.maps.model.Polygon dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Polygon) param0);
    }
    
    /**
     * org.xms.g.maps.model.Polygon.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Polygon;
    }
}