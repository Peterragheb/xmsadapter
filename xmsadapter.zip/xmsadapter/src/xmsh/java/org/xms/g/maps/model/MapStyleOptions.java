package org.xms.g.maps.model;

/**
 * xms Defines styling options for a Map.<br/>
 * Wrapper class for com.huawei.hms.maps.model.MapStyleOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.MapStyleOptions: Customizes style attributes for a HuaweiMap object.<br/>
 */
public final class MapStyleOptions extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.huawei.hms.maps.model.MapStyleOptions.CREATOR: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.MapStyleOptions createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.MapStyleOptions hReturn = com.huawei.hms.maps.model.MapStyleOptions.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.MapStyleOptions(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.MapStyleOptions[] newArray(int param0) {
            return new org.xms.g.maps.model.MapStyleOptions[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.MapStyleOptions(org.xms.g.utils.XBox) Defines styling options for a Map.<br/>
     * com.huawei.hms.maps.model.MapStyleOptions.MapStyleOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public MapStyleOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.MapStyleOptions(java.lang.String) Defines styling options for Map.<br/>
     * com.huawei.hms.maps.model.MapStyleOptions.MapStyleOptions(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/mapstyleoptions-0000001050150846-V5</a><br/>
     *
     * @param param0 the param should instanceof java lang String
     */
    public MapStyleOptions(java.lang.String param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.MapStyleOptions(param0));
    }
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.loadRawResourceStyle(android.content.Context,int) Creates a new set of map style options based on the a JSON styling string loaded from a raw resource identifier.<br/>
     * com.huawei.hms.maps.model.MapStyleOptions.loadRawResourceStyle(android.content.Context,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapstyleoptions#loadRawResourceStyle(Context,int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapstyleoptions#loadRawResourceStyle(Context,int)</a><br/>
     *
     * @param param0 Client context for the supplied resourceId
     * @param param1 Id of a raw resource containing the styling JSON
     * @throws android.content.res.Resources.NotFoundException if resourceId is not a valid raw resource id or the resource could not be read
     * @return A reference to this MapStyleOptions to allow call chaining
     */
    public static final org.xms.g.maps.model.MapStyleOptions loadRawResourceStyle(android.content.Context param0, int param1) throws android.content.res.Resources.NotFoundException {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.MapStyleOptions.loadRawResourceStyle(param0, param1)");
        com.huawei.hms.maps.model.MapStyleOptions hReturn = com.huawei.hms.maps.model.MapStyleOptions.loadRawResourceStyle(param0, param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.MapStyleOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.huawei.hms.maps.model.MapStyleOptions.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapstyleoptions">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapstyleoptions</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.MapStyleOptions) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.MapStyleOptions) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.MapStyleOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model MapStyleOptions object
     */
    public static org.xms.g.maps.model.MapStyleOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.MapStyleOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.MapStyleOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.MapStyleOptions;
    }
}