package org.xms.g.maps;

/**
 * xms Settings for the user interface of a Map.<br/>
 * Wrapper class for com.huawei.hms.maps.UiSettings, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.UiSettings: Sets the built-in UI and gesture controls of a map.<br/>
 */
public final class UiSettings extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.UiSettings.UiSettings(org.xms.g.utils.XBox) constructor of UiSettings.<br/>
     *
     * @param param0 this param is utils XBox
     */
    public UiSettings(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.isCompassEnabled() Gets whether the compass is enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isCompassEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isCompassEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isCompassEnabled()</a><br/>
     *
     * @return true if the compass is enabled; false if the compass is disabled
     */
    public final boolean isCompassEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isCompassEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isCompassEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isIndoorLevelPickerEnabled() Gets whether the indoor level picker is enabled/disabled. That is, whether the level picker will appear when a building with indoor maps is focused.<br/>
     * com.huawei.hms.maps.UiSettings.isIndoorLevelPickerEnabled()
     *
     * @return true if the level picker is enabled; false if the level picker is disabled
     */
    public final boolean isIndoorLevelPickerEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isIndoorLevelPickerEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isIndoorLevelPickerEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isMapToolbarEnabled() Gets whether the Map Toolbar is enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isMapToolbarEnabled()
     *
     * @return true if the Map Toolbar is enabled; false otherwise
     */
    public final boolean isMapToolbarEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isMapToolbarEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isMapToolbarEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isMyLocationButtonEnabled() Gets whether the my-location button is enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isMyLocationButtonEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isMyLocationButtonEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isMyLocationButtonEnabled()</a><br/>
     *
     * @return true if the my-location button is enabled; false if the my-location button is disabled
     */
    public final boolean isMyLocationButtonEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isMyLocationButtonEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isMyLocationButtonEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isRotateGesturesEnabled() Gets whether rotate gestures are enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isRotateGesturesEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isRotateGesturesEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isRotateGesturesEnabled()</a><br/>
     *
     * @return true if rotate gestures are enabled; false if rotate gestures are disabled
     */
    public final boolean isRotateGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isRotateGesturesEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isRotateGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isScrollGesturesEnabled() Gets whether scroll gestures are enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isScrollGesturesEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isScrollGesturesEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isScrollGesturesEnabled()</a><br/>
     *
     * @return true if scroll gestures are enabled; false if scroll gestures are disabled
     */
    public final boolean isScrollGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isScrollGesturesEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isScrollGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isScrollGesturesEnabledDuringRotateOrZoom() Gets whether scroll gestures are enabled/disabled during rotation and zoom gestures.<br/>
     * com.huawei.hms.maps.UiSettings.isScrollGesturesEnabledDuringRotateOrZoom(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isScrollGesturesEnabledDuringRotateOrZoom()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isScrollGesturesEnabledDuringRotateOrZoom()</a><br/>
     *
     * @return true if scroll gestures are enabled during rotate or zoom gestures; false if scroll gestures are disabled during rotate or zoom gestures
     */
    public final boolean isScrollGesturesEnabledDuringRotateOrZoom() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isScrollGesturesEnabledDuringRotateOrZoom()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isScrollGesturesEnabledDuringRotateOrZoom();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isTiltGesturesEnabled() Gets whether tilt gestures are enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isTiltGesturesEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isTiltGesturesEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isTiltGesturesEnabled()</a><br/>
     *
     * @return true if tilt gestures are enabled; false if tilt gestures are disabled
     */
    public final boolean isTiltGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isTiltGesturesEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isTiltGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isZoomControlsEnabled() Gets whether the zoom controls are enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isZoomControlsEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isZoomControlsEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isZoomControlsEnabled()</a><br/>
     *
     * @return true if the zoom controls are enabled; false if the zoom controls are disabled;
     */
    public final boolean isZoomControlsEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isZoomControlsEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isZoomControlsEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.isZoomGesturesEnabled() Gets whether zoom gestures are enabled/disabled.<br/>
     * com.huawei.hms.maps.UiSettings.isZoomGesturesEnabled(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isZoomGesturesEnabled()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#isZoomGesturesEnabled()</a><br/>
     *
     * @return true if zoom gestures are enabled; false if zoom gestures are disabled
     */
    public final boolean isZoomGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).isZoomGesturesEnabled()");
        return ((com.huawei.hms.maps.UiSettings) this.getHInstance()).isZoomGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.UiSettings.setAllGesturesEnabled(boolean) Sets the preference for whether all gestures should be enabled or disabled. If enabled, all gestures are available; otherwise, all gestures are disabled. This doesn't restrict users from tapping any on screen buttons to move the camera(e.g., compass or zoom controls), nor does it restrict programmatic movements and animation.<br/>
     * com.huawei.hms.maps.UiSettings.setAllGesturesEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setAllGesturesEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setAllGesturesEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable all gestures; false to disable all gestures
     */
    public final void setAllGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setAllGesturesEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setAllGesturesEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setCompassEnabled(boolean) Enables or disables the compass. The compass is an icon on the map that indicates the direction of north on the map. If enabled, it is only shown when the camera is tilted or rotated away from its default orientation(tilt of 0 and a bearing of 0). When a user clicks the compass, the camera orients itself to its default orientation and fades away shortly after. If disabled, the compass will never be displayed.<br/>
     * com.huawei.hms.maps.UiSettings.setCompassEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setCompassEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setCompassEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable the compass; false to disable the compass
     */
    public final void setCompassEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setCompassEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setCompassEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setIndoorLevelPickerEnabled(boolean) Sets whether the indoor level picker is enabled when indoor mode is enabled.<br/>
     * com.huawei.hms.maps.UiSettings.setIndoorLevelPickerEnabled(boolean)
     *
     * @param param0 true to show; false to hide the level picker
     */
    public final void setIndoorLevelPickerEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setIndoorLevelPickerEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setIndoorLevelPickerEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setMapToolbarEnabled(boolean) Sets the preference for whether the Map Toolbar should be enabled or disabled.<br/>
     * com.huawei.hms.maps.UiSettings.setMapToolbarEnabled(boolean)
     *
     * @param param0 true to enable the Map Toolbar; false to disable the Map Toolbar
     */
    public final void setMapToolbarEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setMapToolbarEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setMapToolbarEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setMyLocationButtonEnabled(boolean) Enables or disables the my-location button. The my-location button causes the camera to move such that the user's location is in the center of the map. If the button is enabled, it is only shown when the my-location layer is enabled.<br/>
     * com.huawei.hms.maps.UiSettings.setMyLocationButtonEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setMyLocationButtonEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setMyLocationButtonEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable the my-location button; false to disable the my-location button
     */
    public final void setMyLocationButtonEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setMyLocationButtonEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setMyLocationButtonEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setRotateGesturesEnabled(boolean) Sets the preference for whether rotate gestures should be enabled or disabled. If enabled, users can use a two-finger rotate gesture to rotate the camera. If disabled, users cannot rotate the camera via gestures. This setting doesn't restrict the user from tapping the compass icon to reset the camera orientation, nor does it restrict programmatic movements and animation of the camera.<br/>
     * com.huawei.hms.maps.UiSettings.setRotateGesturesEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setRotateGesturesEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setRotateGesturesEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable rotate; false to disable rotate gestures
     */
    public final void setRotateGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setRotateGesturesEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setRotateGesturesEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setScrollGesturesEnabled(boolean) Sets the preference for whether scroll gestures should be enabled or disabled. If enabled, users can swipe to pan the camera. If disabled, swiping has no effect. This setting doesn't restrict programmatic movement and animation of the camera.<br/>
     * com.huawei.hms.maps.UiSettings.setScrollGesturesEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setScrollGesturesEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setScrollGesturesEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable scroll gestures; false to disable scroll gestures
     */
    public final void setScrollGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setScrollGesturesEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setScrollGesturesEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setScrollGesturesEnabledDuringRotateOrZoom(boolean) Sets the preference for whether scroll gestures can take place at the same time as a zoom or rotate gesture. If enabled, users can scroll the map while rotating or zooming the map. If disabled, the map cannot be scrolled while the user rotates or zooms the map using gestures. This setting doesn't disable scroll gestures entirely, only during rotation and zoom gestures, nor does it restrict programmatic movements and animation of the camera.<br/>
     * com.huawei.hms.maps.UiSettings.setScrollGesturesEnabledDuringRotateOrZoom(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setScrollGesturesEnabledDuringRotateOrZoom(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setScrollGesturesEnabledDuringRotateOrZoom(boolean)</a><br/>
     *
     * @param param0 true to enable scroll gestures during rotate or zoom gestures; false to disable scroll gestures during rotate or zoom gestures
     */
    public final void setScrollGesturesEnabledDuringRotateOrZoom(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setScrollGesturesEnabledDuringRotateOrZoom(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setScrollGesturesEnabledDuringRotateOrZoom(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setTiltGesturesEnabled(boolean) Sets the preference for whether tilt gestures should be enabled or disabled. If enabled, users can use a two-finger vertical down swipe to tilt the camera. If disabled, users cannot tilt the camera via gestures. This setting doesn't restrict users from tapping the compass icon to reset the camera orientation, nor does it restrict programmatic movement and animation of the camera.<br/>
     * com.huawei.hms.maps.UiSettings.setTiltGesturesEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setTiltGesturesEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setTiltGesturesEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable tilt gestures; false to disable tilt gestures
     */
    public final void setTiltGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setTiltGesturesEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setTiltGesturesEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setZoomControlsEnabled(boolean) Enables or disables the zoom controls. If enabled, the zoom controls are a pair of buttons(one for zooming in, one for zooming out)that appear on the screen. When pressed, they cause the camera to zoom in(or out)by one zoom level. If disabled, the zoom controls are not shown.<br/>
     * com.huawei.hms.maps.UiSettings.setZoomControlsEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setZoomControlsEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setZoomControlsEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable the zoom controls; false to disable the zoom controls
     */
    public final void setZoomControlsEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setZoomControlsEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setZoomControlsEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.setZoomGesturesEnabled(boolean) Sets the preference for whether zoom gestures should be enabled or disabled. If enabled, users can either double tap/two-finger tap or pinch to zoom the camera. If disabled, these gestures have no effect. This setting doesn't affect the zoom buttons, nor does it restrict programmatic movement and animation of the camera.<br/>
     * com.huawei.hms.maps.UiSettings.setZoomGesturesEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setZoomGesturesEnabled(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-uisettings#setZoomGesturesEnabled(boolean)</a><br/>
     *
     * @param param0 true to enable zoom gestures; false to disable zoom gestures
     */
    public final void setZoomGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.UiSettings) this.getHInstance()).setZoomGesturesEnabled(param0)");
        ((com.huawei.hms.maps.UiSettings) this.getHInstance()).setZoomGesturesEnabled(param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.UiSettings.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps UiSettings object
     */
    public static org.xms.g.maps.UiSettings dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.UiSettings) param0);
    }
    
    /**
     * org.xms.g.maps.UiSettings.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.UiSettings;
    }
}