package org.xms.g.maps.model;

/**
 * xms Known Direct Subclasses.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Cap, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Cap: Defines a cap that is applied at the start or end vertex of a polyline.<br/>
 */
public class Cap extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.Cap.Cap(org.xms.g.utils.XBox) Immutable cap that can be applied at the start or end vertex of a Polyline.<br/>
     * com.huawei.hms.maps.model.Cap.Cap(): <a href="https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cap-0000001050150534-V5">https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/cap-0000001050150534-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Cap(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Cap.equals(java.lang.Object) Cap equals some object .<br/>
     * com.huawei.hms.maps.model.Cap.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap</a><br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Cap) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.Cap) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.Cap.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.Cap.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap</a><br/>
     *
     * @return the return object is int
     */
    public int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Cap) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.Cap) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.Cap.toString() to String.<br/>
     * com.huawei.hms.maps.model.Cap.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap</a><br/>
     *
     * @return the return object is java lang String
     */
    public java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Cap) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.Cap) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.Cap.writeToParcel(android.os.Parcel,int) write To Parcel.<br/>
     * com.huawei.hms.maps.model.Cap.writeToParcel(android.os.Parcel,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-cap</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Cap) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.Cap) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.Cap.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Cap.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Cap object
     */
    public static org.xms.g.maps.model.Cap dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Cap) param0);
    }
    
    /**
     * org.xms.g.maps.model.Cap.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Cap;
    }
}