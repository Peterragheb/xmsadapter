package org.xms.g.maps.model;

/**
 * xms A polyline is a list of points, where line segments are drawn between consecutive points.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Polyline, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Polyline: Defines a polyline, which is a list of vertices, where line segments are drawn between consecutive vertices. The following table describes attributes of a polyline.<br/>
 */
public final class Polyline extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.Polyline.Polyline(org.xms.g.utils.XBox) A polyline is a list of points, where line segments are drawn between consecutive points.<br/>
     * com.huawei.hms.maps.model.Polyline.Polyline(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polyline-0000001050151144-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polyline-0000001050151144-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Polyline(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.equals(java.lang.Object) Tests if this Polyline is equal to another.<br/>
     * com.huawei.hms.maps.model.Polyline.equals(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#equals(Object)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#equals(Object)</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getColor() Gets the color of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getColor()</a><br/>
     *
     * @return the color in ARGB format
     */
    public final int getColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getColor()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getColor();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getEndCap() Gets the cap at the end vertex of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getEndCap(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getEndCap()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getEndCap()</a><br/>
     *
     * @return the end cap type
     */
    public final org.xms.g.maps.model.Cap getEndCap() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getEndCap()");
        com.huawei.hms.maps.model.Cap hReturn = ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getEndCap();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.Cap(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getId() Gets this polyline's id. The id will be unique amongst all Polylines on a map.<br/>
     * com.huawei.hms.maps.model.Polyline.getId(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getId()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getId()</a><br/>
     *
     * @return this polyline's id
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getId()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getJointType() Gets the joint type used at all vertices of the polyline except the start and end vertices. See JointType for possible values.<br/>
     * com.huawei.hms.maps.model.Polyline.getJointType(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getJointType()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getJointType()</a><br/>
     *
     * @return the joint type
     */
    public final int getJointType() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getJointType()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getJointType();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getPattern() Gets the stroke pattern of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getPattern(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getPattern()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getPattern()</a><br/>
     *
     * @return the stroke pattern
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getPattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getPattern()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getPattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.huawei.hms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getPoints() Returns a snapshot of the vertices of this polyline at this time.The list returned is a copy of the list of vertices and so changes to the polyline's vertices will not be reflected by this list, nor will changes to this list be reflected by the polyline. To change the vertices of the polyline, call setPoints(List).<br/>
     * com.huawei.hms.maps.model.Polyline.getPoints(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getPoints()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getPoints()</a><br/>
     *
     * @return the return object is java util List<LatLng>
     */
    public final java.util.List<org.xms.g.maps.model.LatLng> getPoints() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getPoints()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getPoints();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
            
            public org.xms.g.maps.model.LatLng apply(com.huawei.hms.maps.model.LatLng param0) {
                return new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getStartCap() Gets the cap at the start vertex of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getStartCap(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getStartCap()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getStartCap()</a><br/>
     *
     * @return the start cap
     */
    public final org.xms.g.maps.model.Cap getStartCap() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getStartCap()");
        com.huawei.hms.maps.model.Cap hReturn = ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getStartCap();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.Cap(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getTag() Gets the tag for the polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getTag(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getTag()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getTag()</a><br/>
     *
     * @return the tag if a tag was set with setTag; null if no tag has been set
     */
    public final java.lang.Object getTag() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getTag()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getTag();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getWidth() Gets the width of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getWidth(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getWidth()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getWidth()</a><br/>
     *
     * @return the width in screen pixels
     */
    public final float getWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getWidth()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getWidth();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.getZIndex() Gets the zIndex of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#getZIndex()</a><br/>
     *
     * @return the zIndex of the polyline
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.Polyline.hashCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#hashCode()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#hashCode()</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.isClickable() Gets the clickability of the polyline. If the polyline is clickable, your app will receive notifications to the GoogleMap.OnPolylineClickListener when the user clicks the polyline. The event listener is registered through setOnPolylineClickListener(GoogleMap.OnPolylineClickListener).<br/>
     * com.huawei.hms.maps.model.Polyline.isClickable(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isClickable()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isClickable()</a><br/>
     *
     * @return true if the polyline is clickable; otherwise, returns false
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isClickable()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.isGeodesic() Gets whether each segment of the line is drawn as a geodesic or not.<br/>
     * com.huawei.hms.maps.model.Polyline.isGeodesic(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isGeodesic()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isGeodesic()</a><br/>
     *
     * @return true if each segment is drawn as a geodesic; false if each segment is drawn as a straight line on the Mercator projection
     */
    public final boolean isGeodesic() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isGeodesic()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isGeodesic();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.isVisible() Gets the visibility of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#isVisible()</a><br/>
     *
     * @return this polyline's visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.remove() Removes this polyline from the map. After a polyline has been removed, the behavior of all its methods is undefined.<br/>
     * com.huawei.hms.maps.model.Polyline.remove(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#remove()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#remove()</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).remove()");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setClickable(boolean) Sets the clickability of the polyline. If the polyline is clickable, your app will receive notifications to the GoogleMap.OnPolylineClickListener when the user clicks the polyline. The event listener is registered through setOnPolylineClickListener(GoogleMap.OnPolylineClickListener).<br/>
     * com.huawei.hms.maps.model.Polyline.setClickable(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setClickable(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setClickable(boolean)</a><br/>
     *
     * @param param0 New clickability setting for the polyline
     */
    public final void setClickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setClickable(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setClickable(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setColor(int) Sets the color of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.setColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setColor(int)</a><br/>
     *
     * @param param0 the color in ARGB format
     */
    public final void setColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setColor(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setColor(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setEndCap(org.xms.g.maps.model.Cap) Sets the cap at the end vertex of this polyline. The default end cap is ButtCap.<br/>
     * com.huawei.hms.maps.model.Polyline.setEndCap(com.huawei.hms.maps.model.Cap): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setEndCap(Cap)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setEndCap(Cap)</a><br/>
     *
     * @param param0 the end cap. Must not be null
     */
    public final void setEndCap(org.xms.g.maps.model.Cap param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setEndCap(((com.huawei.hms.maps.model.Cap) ((param0) == null ? null : (param0.getHInstance()))))");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setEndCap(((com.huawei.hms.maps.model.Cap) ((param0) == null ? null : (param0.getHInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setGeodesic(boolean) Sets whether to draw each segment of the line as a geodesic or not.<br/>
     * com.huawei.hms.maps.model.Polyline.setGeodesic(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setGeodesic(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setGeodesic(boolean)</a><br/>
     *
     * @param param0 if true, then each segment is drawn as a geodesic; if false, each segment is drawn as a straight line on the Mercator projection
     */
    public final void setGeodesic(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setGeodesic(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setGeodesic(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setJointType(int) Sets the joint type for all vertices of the polyline except the start and end vertices.<br/>
     * com.huawei.hms.maps.model.Polyline.setJointType(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setJointType(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setJointType(int)</a><br/>
     *
     * @param param0 the joint type
     */
    public final void setJointType(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setJointType(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setJointType(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setPattern(java.util.List) Sets the stroke pattern of the polyline. The default stroke pattern is solid, represented by null.<br/>
     * com.huawei.hms.maps.model.Polyline.setPattern(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setPattern(List%3CPatternItem%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setPattern(List%3CPatternItem%3E)</a><br/>
     *
     * @param param0 the param should be instanceof java util List
     */
    public final void setPattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setPattern(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setPattern(org.xms.g.utils.Utils.mapList2GH(param0, true));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setPoints(java.util.List) Sets the points of this polyline. This method will take a copy of the points, so further mutations to points will have no effect on this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.setPoints(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setPoints(List%3CLatLng%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setPoints(List%3CLatLng%3E)</a><br/>
     *
     * @param param0 the param should be instanceof java util List
     */
    public final void setPoints(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setPoints(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setPoints(org.xms.g.utils.Utils.mapList2GH(param0, true));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setStartCap(org.xms.g.maps.model.Cap) Sets the cap at the start vertex of this polyline. The default start cap is ButtCap.<br/>
     * com.huawei.hms.maps.model.Polyline.setStartCap(com.huawei.hms.maps.model.Cap): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setStartCap(Cap)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setStartCap(Cap)</a><br/>
     *
     * @param param0 the start cap. Must not be null
     */
    public final void setStartCap(org.xms.g.maps.model.Cap param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setStartCap(((com.huawei.hms.maps.model.Cap) ((param0) == null ? null : (param0.getHInstance()))))");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setStartCap(((com.huawei.hms.maps.model.Cap) ((param0) == null ? null : (param0.getHInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setTag(java.lang.Object) Sets the tag for the polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.setTag(java.lang.Object): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setTag(Object)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setTag(Object)</a><br/>
     *
     * @param param0 if null, the tag is cleared
     */
    public final void setTag(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setTag(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setTag(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setVisible(boolean) Sets the visibility of this polyline. When not visible, a polyline is not drawn, but it keeps all its other properties.<br/>
     * com.huawei.hms.maps.model.Polyline.setVisible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setVisible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setVisible(boolean)</a><br/>
     *
     * @param param0 if true, then the polyline is visible; if false, it is not
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setVisible(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setWidth(float) Sets the width of this polyline.<br/>
     * com.huawei.hms.maps.model.Polyline.setWidth(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setWidth(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setWidth(float)</a><br/>
     *
     * @param param0 the width in screen pixels
     */
    public final void setWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setWidth(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setWidth(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.setZIndex(float) Sets the zIndex of this polyline. Polylines with higher zIndices are drawn above those with lower indices.<br/>
     * com.huawei.hms.maps.model.Polyline.setZIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setZIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polyline#setZIndex(float)</a><br/>
     *
     * @param param0 the zIndex of this polyline
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setZIndex(param0)");
        ((com.huawei.hms.maps.model.Polyline) this.getHInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Polyline.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Polyline object
     */
    public static org.xms.g.maps.model.Polyline dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Polyline) param0);
    }
    
    /**
     * org.xms.g.maps.model.Polyline.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Polyline;
    }
}