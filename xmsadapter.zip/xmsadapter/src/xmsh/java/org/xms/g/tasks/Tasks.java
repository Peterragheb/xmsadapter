package org.xms.g.tasks;




/**
 * Common task utility methods.<br/>
 * Wrapper class for com.huawei.hmf.tasks.Tasks, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.Tasks: A common task method.<br/>
 */
public final class Tasks extends org.xms.g.utils.XObject {
    
    
    
    /**
     * org.xms.g.tasks.Tasks.Tasks(org.xms.g.utils.XBox) constructor of Tasks with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public Tasks(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.tasks.Tasks.await(org.xms.g.tasks.Task<XTResult>,long,java.util.concurrent.TimeUnit) Blocks until the specified Task is complete.<br/>
     * com.huawei.hmf.tasks.Tasks.await(com.huawei.hmf.tasks.Task<TResult>,long,java.util.concurrent.TimeUnit): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section158212814319">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section158212814319</a><br/>
     *
     * @param param0 Task to be completed
     * @param param1 Timeout duration
     * @param param2 Unit of time
     * @throws java.util.concurrent.ExecutionException if the Task fails. getCause will return the original exception
     * @throws java.lang.InterruptedException if an interrupt occurs while waiting for the Task to complete
     * @throws java.util.concurrent.TimeoutException if the specified timeout is reached before the Task completes
     * @return Result of the task
     */
    public static <XTResult> XTResult await(org.xms.g.tasks.Task<XTResult> param0, long param1, java.util.concurrent.TimeUnit param2) throws java.util.concurrent.ExecutionException, java.lang.InterruptedException, java.util.concurrent.TimeoutException {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.await(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))), param1, param2)");
        java.lang.Object hmsObj = com.huawei.hmf.tasks.Tasks.await(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))), param1, param2);
        return ((XTResult) org.xms.g.utils.Utils.getXmsObjectWithHmsObject(hmsObj));
    }
    
    /**
     * org.xms.g.tasks.Tasks.await(org.xms.g.tasks.Task<XTResult>) Blocks until the specified Task is complete.<br/>
     * com.huawei.hmf.tasks.Tasks.await(com.huawei.hmf.tasks.Task<TResult>): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section1257792715383">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section1257792715383</a><br/>
     *
     * @param param0 Task to be completed
     * @throws java.util.concurrent.ExecutionException if the Task fails. getCause will return the original exception
     * @throws java.lang.InterruptedException if an interrupt occurs while waiting for the Task to complete
     * @return Result of the task
     */
    public static <XTResult> XTResult await(org.xms.g.tasks.Task<XTResult> param0) throws java.util.concurrent.ExecutionException, java.lang.InterruptedException {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.await(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))))");
        java.lang.Object hmsObj = com.huawei.hmf.tasks.Tasks.await(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))));
        return ((XTResult) org.xms.g.utils.Utils.getXmsObjectWithHmsObject(hmsObj));
    }
    
    /**
     * org.xms.g.tasks.Tasks.call(java.util.concurrent.Callable<XTResult>) Returns a Task that will be completed with the result of the specified Callable.The Callable will be called on the main application thread.<br/>
     * com.huawei.hmf.tasks.Tasks.call(java.util.concurrent.Callable<XTResult>): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section10478151064312">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/tasks-0000001050123101-V5#EN-US_TOPIC_0000001050123101__section10478151064312</a><br/>
     *
     * @param param0 Operation to be performed
     * @return New task returned
     */
    public static <XTResult> org.xms.g.tasks.Task<XTResult> call(java.util.concurrent.Callable<XTResult> param0) {
        
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.callInBackground(com.huawei.hmf.tasks.TaskExecutors.uiThread(), param0)");
        com.huawei.hmf.tasks.Task hReturn = null;
        hReturn = com.huawei.hmf.tasks.Tasks.callInBackground(com.huawei.hmf.tasks.TaskExecutors.uiThread(), param0);
        if (hReturn == null) {
            return null;
        }
        return new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn));
    }
    
    /**
     * org.xms.g.tasks.Tasks.call(java.util.concurrent.Executor,java.util.concurrent.Callable<XTResult>) Returns a Task that will be completed with the result of the specified Callable.<br/>
     * com.huawei.hmf.tasks.Tasks.callInBackground(java.util.concurrent.Executor,java.util.concurrent.Callable<TResult>)
     *
     * @param param0 the Executor to use to call the Callable
     * @param param1 Operation to be performed
     * @return New task returned
     */
    public static <XTResult> org.xms.g.tasks.Task<XTResult> call(java.util.concurrent.Executor param0, java.util.concurrent.Callable<XTResult> param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.callInBackground(param0, param1)");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.callInBackground(param0, param1);
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.forCanceled() Returns a canceled Task.<br/>
     * com.huawei.hmf.tasks.Tasks.fromCanceled()
     *
     * @return a canceled Task
     */
    public static <XTResult> org.xms.g.tasks.Task<XTResult> forCanceled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.fromCanceled()");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.fromCanceled();
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.forException(java.lang.Exception) Returns a completed Task with the specified exception.<br/>
     * com.huawei.hmf.tasks.Tasks.fromException(java.lang.Exception)
     *
     * @param param0 the specified exception
     * @return a completed Task with the specified exception
     */
    public static <XTResult> org.xms.g.tasks.Task<XTResult> forException(java.lang.Exception param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.fromException(param0)");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.fromException(param0);
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.forResult(XTResult) Returns a completed Task with the specified result.<br/>
     * com.huawei.hmf.tasks.Tasks.fromResult(XTResult)
     *
     * @param param0 the specified result
     * @return a completed Task with the specified result
     */
    public static <XTResult> org.xms.g.tasks.Task<XTResult> forResult(XTResult param0) {
        XTResult hObj0 = ((XTResult) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.fromResult(hObj0)");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.fromResult(hObj0);
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAll(org.xms.g.tasks.Task<?>...) Returns a Task that completes successfully when all of the specified Tasks complete successfully. Does not accept nulls.This Task would fail if any of the provided Tasks fail. This Task would be set to canceled if any of the provided Tasks is canceled and no failure is detected.<br/>
     * com.huawei.hmf.tasks.Tasks.join(com.huawei.hmf.tasks.Task[])
     *
     * @param param0 the specified Tasks
     * @return the return object is Task
     */
    public static org.xms.g.tasks.Task<java.lang.Void> whenAll(org.xms.g.tasks.Task<?>... param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.join(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.join(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAll(java.util.Collection<? extends org.xms.g.tasks.Task<?>>) Returns a Task that completes successfully when all of the specified Tasks complete successfully. Does not accept nulls.The returned Task would fail if any of the provided Tasks fail. The returned Task would be set to canceled if any of the provided Tasks is canceled and no failure is detected.<br/>
     * com.huawei.hmf.tasks.Tasks.join(java.util.Collection<? extends com.huawei.hmf.tasks.Task<?>>)
     *
     * @param param0 the specified Tasks
     * @return the return object is Task
     */
    public static org.xms.g.tasks.Task<java.lang.Void> whenAll(java.util.Collection<? extends org.xms.g.tasks.Task<?>> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.join(org.xms.g.utils.Utils.mapCollection2GH(param0, true))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.join(org.xms.g.utils.Utils.mapCollection2GH(param0, true));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAllComplete(org.xms.g.tasks.Task<?>...) Returns a Task with a list of Tasks that completes successfully when all of the specified Tasks complete. This Task would always succeed even if any of the provided Tasks fail or canceled. Does not accept nulls.<br/>
     * com.huawei.hmf.tasks.Tasks.allOf(jcom.huawei.hmf.tasks.Task[])
     *
     * @param param0 a list of Tasks
     * @return the return object is Task
     */
    public static org.xms.g.tasks.Task<java.util.List<org.xms.g.tasks.Task<?>>> whenAllComplete(org.xms.g.tasks.Task<?>... param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.allOf(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.allOf(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAllComplete(java.util.Collection<? extends org.xms.g.tasks.Task<?>>) Returns a Task with a list of Tasks that completes successfully when all of the specified Tasks complete. This Task would always succeed even if any of the provided Tasks fail or canceled. Does not accept nulls.<br/>
     * com.huawei.hmf.tasks.Tasks.allOf(java.util.Collection<? extends com.huawei.hmf.tasks.Task<?>>)
     *
     * @param param0 a list of Tasks
     * @return the return object is Task
     */
    public static org.xms.g.tasks.Task<java.util.List<org.xms.g.tasks.Task<?>>> whenAllComplete(java.util.Collection<? extends org.xms.g.tasks.Task<?>> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.allOf(org.xms.g.utils.Utils.mapCollection2GH(param0, true))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.allOf(org.xms.g.utils.Utils.mapCollection2GH(param0, true));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAllSuccess(org.xms.g.tasks.Task<?>...) Returns a Task with a list of Task results that completes successfully when all of the specified Tasks complete successfully. This Task would fail if any of the provided Tasks fail. Does not accept nulls.This Task would be set to canceled if any of the provided Tasks is canceled and no failure is detected.<br/>
     * com.huawei.hmf.tasks.Tasks.successOf(com.huawei.hmf.tasks.Task[])
     *
     * @param param0 a list of Task results
     * @return the return object is Task
     */
    public static <XTResult> org.xms.g.tasks.Task<java.util.List<XTResult>> whenAllSuccess(org.xms.g.tasks.Task<?>... param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.successOf(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.successOf(((com.huawei.hmf.tasks.Task[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hmf.tasks.Task.class, x -> (com.huawei.hmf.tasks.Task)x.getHInstance())));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.whenAllSuccess(java.util.Collection) Returns a Task with a list of Task results that completes successfully when all of the specified Tasks complete successfully. This Task would fail if any of the provided Tasks fail. Does not accept nulls.This Task would be set to canceled if any of the provided Tasks is canceled and no failure is detected.<br/>
     * com.huawei.hmf.tasks.Tasks.successOf(java.util.Collection)
     *
     * @param param0 a list of Task results
     * @return the return object is Task
     */
    public static <XTResult> org.xms.g.tasks.Task<java.util.List<XTResult>> whenAllSuccess(java.util.Collection param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.Tasks.successOf(org.xms.g.utils.Utils.mapCollection2GH(param0, true))");
        com.huawei.hmf.tasks.Task hReturn = com.huawei.hmf.tasks.Tasks.successOf(org.xms.g.utils.Utils.mapCollection2GH(param0, true));
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.tasks.Tasks.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.Tasks.<br/>
     *
     * @param param0 the input object
     * @return casted Tasks object
     */
    public static org.xms.g.tasks.Tasks dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.Tasks) param0);
    }
    
    /**
     * org.xms.g.tasks.Tasks.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hmf.tasks.Tasks;
    }
}