package org.xms.g.analytics;

/**
 * A BroadcastReceiver used by Analytics.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public class AnalyticsReceiver extends android.content.BroadcastReceiver implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.AnalyticsReceiver(org.xms.g.utils.XBox) constructor of AnalyticsReceiver with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AnalyticsReceiver(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.AnalyticsReceiver() constructor of AnalyticsReceiver.<br/>
     *
     */
    public AnalyticsReceiver() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onReceive(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.analytics.AnalyticsReceiver.<br/>
     *
     * @param param0 the input object
     * @return casted AnalyticsReceiver object
     */
    public static org.xms.g.analytics.AnalyticsReceiver dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}