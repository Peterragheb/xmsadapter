package org.xms.g.tasks;

/**
 * A function that is called to continue execution then a Task succeeds.<br/>
 * Wrapper class for com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>: Called to continue execution when a task succeeds.<br/>
 */
public interface SuccessContinuation<XTResult, XTContinuationResult> extends org.xms.g.utils.XInterface {
    
    /**
     * org.xms.g.tasks.SuccessContinuation.then(XTResult) Returns the result of applying this SuccessContinuation to Task.The SuccessContinuation only happens then the Task is successful. If the previous Task fails, the onSuccessTask continuation will be skipped and failure listeners will be invoked.<br/>
     * com.huawei.hmf.tasks.SuccessContinuation.then(TResult): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/successcontinuation-0000001050121146#EN-US_TOPIC_0000001050121146__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/successcontinuation-0000001050121146#EN-US_TOPIC_0000001050121146__section32821622269</a><br/>
     *
     * @param param0 the result of completed Task
     * @throws java.lang.Exception if the result couldn't be produced
     * @return the return object is Task
     */
    public org.xms.g.tasks.Task<XTContinuationResult> then(XTResult param0) throws java.lang.Exception;
    
    default java.lang.Object getZInstanceSuccessContinuation() {
        return getHInstanceSuccessContinuation();
    }
    
    default <TResult, TContinuationResult> com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult> getHInstanceSuccessContinuation() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>() {
            
            public com.huawei.hmf.tasks.Task<TContinuationResult> then(TResult param0) throws java.lang.Exception {
                java.lang.Object[] params = new java.lang.Object[1];
                java.lang.Class[] types = new java.lang.Class[1];
                params[0] = param0;
                types[0] = java.lang.Object.class;
                java.lang.Object result = org.xms.g.utils.Utils.invokeMethod(org.xms.g.tasks.SuccessContinuation.this, "then", params, types, true);
                return ((com.huawei.hmf.tasks.Task) org.xms.g.utils.Utils.handleInvokeBridgeReturnValue(result, true));
            }
        };
    }
    
    /**
     * org.xms.g.tasks.SuccessContinuation.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.SuccessContinuation.<br/>
     *
     * @param param0 the input object
     * @return casted SuccessContinuation object
     */
    public static org.xms.g.tasks.SuccessContinuation dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.SuccessContinuation) param0);
    }
    
    /**
     * org.xms.g.tasks.SuccessContinuation.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hmf.tasks.SuccessContinuation;
        }
        return param0 instanceof org.xms.g.tasks.SuccessContinuation;
    }
    
    /**
     * A function that is called to continue execution then a Task succeeds.<br/>
     * Wrapper class for com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>, but only the HMS API are provided.<br/>
     * com.huawei.hmf.tasks.SuccessContinuation<TResult, TContinuationResult>: Called to continue execution when a task succeeds.<br/>
     */
    public static class XImpl<XTResult, XTContinuationResult> extends org.xms.g.utils.XObject implements org.xms.g.tasks.SuccessContinuation<XTResult, XTContinuationResult> {
        
        /**
         * org.xms.g.tasks.SuccessContinuation.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.tasks.SuccessContinuation.XImpl.then(XTResult) Returns the result of applying this SuccessContinuation to Task.The SuccessContinuation only happens then the Task is successful. If the previous Task fails, the onSuccessTask continuation will be skipped and failure listeners will be invoked.<br/>
         * com.huawei.hmf.tasks.SuccessContinuation.then(TResult): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/successcontinuation-0000001050121146#EN-US_TOPIC_0000001050121146__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/successcontinuation-0000001050121146#EN-US_TOPIC_0000001050121146__section32821622269</a><br/>
         *
         * @param param0 the result of completed Task
         * @throws java.lang.Exception if the result couldn't be produced
         * @return the return object is Task
         */
        public org.xms.g.tasks.Task<XTContinuationResult> then(XTResult param0) throws java.lang.Exception {
            java.lang.Object hObj0 = ((java.lang.Object) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hmf.tasks.SuccessContinuation) this.getHInstance()).then(hObj0)");
            com.huawei.hmf.tasks.Task hReturn = ((com.huawei.hmf.tasks.SuccessContinuation) this.getHInstance()).then(hObj0);
            return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
        }
    }
}