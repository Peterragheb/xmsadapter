package org.xms.g.tasks;




/**
 * A main task executor instances for use with Task.<br/>
 * Wrapper class for com.huawei.hmf.tasks.TaskExecutors, but only the HMS API are provided.<br/>
 * com.huawei.hmf.tasks.TaskExecutors: A main task execution instance.<br/>
 */
public final class TaskExecutors extends org.xms.g.utils.XObject {
    
    
    
    /**
     * org.xms.g.tasks.TaskExecutors.TaskExecutors(org.xms.g.utils.XBox) constructor of TaskExecutors with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public TaskExecutors(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.tasks.TaskExecutors.getMAIN_THREAD() return a Executor that uses the main application thread.<br/>
     * com.huawei.hmf.tasks.TaskExecutors.uiThread()
     *
     * @return the return object is MAIN_THREAD
     */
    public static java.util.concurrent.Executor getMAIN_THREAD() {
        
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hmf.tasks.TaskExecutors.uiThread()");
        return com.huawei.hmf.tasks.TaskExecutors.uiThread();
    }
    
    /**
     * org.xms.g.tasks.TaskExecutors.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.TaskExecutors.<br/>
     *
     * @param param0 the input object
     * @return casted TaskExecutors object
     */
    public static org.xms.g.tasks.TaskExecutors dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.TaskExecutors) param0);
    }
    
    /**
     * org.xms.g.tasks.TaskExecutors.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        
        throw new RuntimeException("HMS does not support this API.");
    }
}