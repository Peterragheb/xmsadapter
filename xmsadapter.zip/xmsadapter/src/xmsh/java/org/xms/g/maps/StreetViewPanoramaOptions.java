package org.xms.g.maps;

/**
 * xms Defines configuration PanoramaOptions for a StreetViewPanorama .<br/>
 * Wrapper class for com.huawei.hms.maps.StreetViewPanoramaOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.StreetViewPanoramaOptions: Defines configuration PanoramaOptions for a StreetViewPanorama.<br/>
 */
public final class StreetViewPanoramaOptions extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.StreetViewPanoramaOptions(org.xms.g.utils.XBox) Defines configuration PanoramaOptions for a StreetViewPanorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.StreetViewPanoramaOptions()
     *
     * @param param0 the param should instanceof utils XBox
     */
    public StreetViewPanoramaOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.StreetViewPanoramaOptions() Defines configuration PanoramaOptions for a StreetViewPanorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.StreetViewPanoramaOptions()
     *
     */
    public StreetViewPanoramaOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.StreetViewPanoramaOptions());
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getPanningGesturesEnabled() true if users are initially able to pan via gestures on Street View panoramas.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getPanningGesturesEnabled()
     *
     * @return true if users are initially able to pan via gestures on Street View panoramas
     */
    public final java.lang.Boolean getPanningGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPanningGesturesEnabled()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPanningGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getPanoramaId() The initial panorama ID for the Street View panorama, or null if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getPanoramaId()
     *
     * @return The initial panorama ID for the Street View panorama, or null if unspecified
     */
    public final java.lang.String getPanoramaId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPanoramaId()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPanoramaId();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getPosition() The initial position for the Street View panorama, or null if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getPosition()
     *
     * @return The initial position for the Street View panorama, or null if unspecified
     */
    public final org.xms.g.maps.model.LatLng getPosition() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPosition()");
        com.huawei.hms.maps.model.LatLng hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getPosition();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getRadius() The initial radius used to search for a Street View panorama, or null if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getRadius()
     *
     * @return The initial radius used to search for a Street View panorama, or null if unspecified
     */
    public final java.lang.Integer getRadius() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getRadius()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getRadius();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getSource() The source filter used to search for a Street View panorama, or DEFAULT if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getSource()
     *
     * @return The source filter used to search for a Street View panorama, or DEFAULT if unspecified
     */
    public final org.xms.g.maps.model.StreetViewSource getSource() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getSource()");
        com.huawei.hms.maps.model.StreetViewSource hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getSource();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewSource(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getStreetNamesEnabled() true if users are initially able to see street names on Street View panoramas.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getStreetNamesEnabled()
     *
     * @return true if users are initially able to see street names on Street View panoramas
     */
    public final java.lang.Boolean getStreetNamesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getStreetNamesEnabled()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getStreetNamesEnabled();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getStreetViewPanoramaCamera() The initial camera for the Street View panorama, or null if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getStreetViewPanoramaCamera()
     *
     * @return The initial camera for the Street View panorama, or null if unspecified
     */
    public final org.xms.g.maps.model.StreetViewPanoramaCamera getStreetViewPanoramaCamera() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getStreetViewPanoramaCamera()");
        com.huawei.hms.maps.model.StreetViewPanoramaCamera hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getStreetViewPanoramaCamera();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaCamera(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getUseViewLifecycleInFragment() the useViewLifecycleInFragment option, or null if unspecified.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getUseViewLifecycleInFragment()
     *
     * @return the useViewLifecycleInFragment option, or null if unspecified
     */
    public final java.lang.Boolean getUseViewLifecycleInFragment() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getUseViewLifecycleInFragment()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getUseViewLifecycleInFragment();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getUserNavigationEnabled() true if users are initially able to move to different Street View panoramas.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getUserNavigationEnabled()
     *
     * @return true if users are initially able to move to different Street View panoramas
     */
    public final java.lang.Boolean getUserNavigationEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getUserNavigationEnabled()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getUserNavigationEnabled();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.getZoomGesturesEnabled() true if users are initially able to zoom via gestures on Street View panoramas.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.getZoomGesturesEnabled()
     *
     * @return true if users are initially able to zoom via gestures on Street View panoramas
     */
    public final java.lang.Boolean getZoomGesturesEnabled() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getZoomGesturesEnabled()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).getZoomGesturesEnabled();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.panningGesturesEnabled(boolean) Toggles the ability for users to use pan around on panoramas using gestures. See setPanningGesturesEnabled(boolean)for more details. The default is true.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.panningGesturesEnabled(boolean)
     *
     * @param param0 the param should instanceof boolean
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions panningGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panningGesturesEnabled(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panningGesturesEnabled(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.panoramaCamera(org.xms.g.maps.model.StreetViewPanoramaCamera) Specifies the initial camera for the Street View panorama.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.panoramaCamera(com.huawei.hms.maps.model.StreetViewPanoramaCamera)
     *
     * @param param0 the param should instanceof maps model StreetViewPanoramaCamera
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions panoramaCamera(org.xms.g.maps.model.StreetViewPanoramaCamera param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panoramaCamera(((com.huawei.hms.maps.model.StreetViewPanoramaCamera) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panoramaCamera(((com.huawei.hms.maps.model.StreetViewPanoramaCamera) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.panoramaId(java.lang.String) Specifies the initial position for the Street View panorama based on a panorama id. The position set by the panoramaID takes precedence over a position set by a LatLng.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.panoramaId(java.lang.String)
     *
     * @param param0 the param should instanceof java lang String
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions panoramaId(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panoramaId(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).panoramaId(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.position(org.xms.g.maps.model.LatLng) Specifies the initial position for the Street View panorama based upon location. The position set by the panoramaID, if set, takes precedence over a position set by a LatLng.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.position(com.huawei.hms.maps.model.LatLng)
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions position(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.position(org.xms.g.maps.model.LatLng,java.lang.Integer,org.xms.g.maps.model.StreetViewSource) Specifies the initial position for the Street View panorama based upon location, radius and source. The position set by the panoramaID, if set, takes precedence over a position set by a LatLng.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.position(com.huawei.hms.maps.model.LatLng,java.lang.Integer,com.huawei.hms.maps.model.StreetViewSource)
     *
     * @param param0 the param should instanceof maps model LatLng
     * @param param1 the param should instanceof java lang Integer
     * @param param2 the param should instanceof maps model StreetViewSource
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions position(org.xms.g.maps.model.LatLng param0, java.lang.Integer param1, org.xms.g.maps.model.StreetViewSource param2) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1, ((com.huawei.hms.maps.model.StreetViewSource) ((param2) == null ? null : (param2.getHInstance()))))");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1, ((com.huawei.hms.maps.model.StreetViewSource) ((param2) == null ? null : (param2.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.position(org.xms.g.maps.model.LatLng,java.lang.Integer) Specifies the initial position for the Street View panorama based upon location and radius. The position set by the panoramaID, if set, takes precedence over a position set by a LatLng.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.position(com.huawei.hms.maps.model.LatLng,java.lang.Integer)
     *
     * @param param0 the param should instanceof maps model LatLng
     * @param param1 the param should instanceof java lang Integer
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions position(org.xms.g.maps.model.LatLng param0, java.lang.Integer param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.position(org.xms.g.maps.model.LatLng,org.xms.g.maps.model.StreetViewSource) Specifies the initial position for the Street View panorama based upon location and source. The position set by the panoramaID, if set, takes precedence over a position set by a LatLng.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.position(com.huawei.hms.maps.model.LatLng,com.huawei.hms.maps.model.StreetViewSource)
     *
     * @param param0 the param should instanceof maps model LatLng
     * @param param1 the param should instanceof maps model StreetViewSource
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions position(org.xms.g.maps.model.LatLng param0, org.xms.g.maps.model.StreetViewSource param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), ((com.huawei.hms.maps.model.StreetViewSource) ((param1) == null ? null : (param1.getHInstance()))))");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), ((com.huawei.hms.maps.model.StreetViewSource) ((param1) == null ? null : (param1.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.streetNamesEnabled(boolean) Toggles the ability for users to see street names on panoramas. See setStreetNamesEnabled(boolean)for more details. The default is true.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.streetNamesEnabled(boolean)
     *
     * @param param0 the param should instanceof boolean
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions streetNamesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).streetNamesEnabled(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).streetNamesEnabled(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.toString() to String.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.toString()
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.useViewLifecycleInFragment(boolean) When using a StreetViewPanoramaFragment, this flag specifies whether the lifecycle of the Street View panorama should be tied to the fragment's view or the fragment itself. The default value is false, tying the lifecycle of the Street View panorama to the fragment.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.useViewLifecycleInFragment(boolean)
     *
     * @param param0 the param should instanceof boolean
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions useViewLifecycleInFragment(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).useViewLifecycleInFragment(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).useViewLifecycleInFragment(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.userNavigationEnabled(boolean) Toggles the ability for users to move between panoramas. See setUserNavigationEnabled(boolean)for more details. The default is true.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.userNavigationEnabled(boolean)
     *
     * @param param0 the param should instanceof boolean
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions userNavigationEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).userNavigationEnabled(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).userNavigationEnabled(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.writeToParcel(android.os.Parcel,int) write To Parcel.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.writeToParcel(android.os.Parcel,int)
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.zoomGesturesEnabled(boolean) Toggles the ability for users to zoom on panoramas using gestures. See setZoomGesturesEnabled(boolean)for more details. The default is true.<br/>
     * com.huawei.hms.maps.StreetViewPanoramaOptions.zoomGesturesEnabled(boolean)
     *
     * @param param0 the param should instanceof boolean
     * @return the return object is maps StreetViewPanoramaOptions
     */
    public final org.xms.g.maps.StreetViewPanoramaOptions zoomGesturesEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).zoomGesturesEnabled(param0)");
        com.huawei.hms.maps.StreetViewPanoramaOptions hReturn = ((com.huawei.hms.maps.StreetViewPanoramaOptions) this.getHInstance()).zoomGesturesEnabled(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.StreetViewPanoramaOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.StreetViewPanoramaOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps StreetViewPanoramaOptions object
     */
    public static org.xms.g.maps.StreetViewPanoramaOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.StreetViewPanoramaOptions) param0);
    }
    
    /**
     * org.xms.g.maps.StreetViewPanoramaOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.StreetViewPanoramaOptions;
    }
}