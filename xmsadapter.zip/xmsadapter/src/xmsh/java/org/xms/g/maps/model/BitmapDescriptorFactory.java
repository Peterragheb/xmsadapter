package org.xms.g.maps.model;

/**
 * xms Used to create a definition of a Bitmap image.<br/>
 * Wrapper class for com.huawei.hms.maps.model.BitmapDescriptorFactory, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.BitmapDescriptorFactory: Creates the definition of a bitmap image.<br/>
 */
public final class BitmapDescriptorFactory extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.BitmapDescriptorFactory(org.xms.g.utils.XBox) Used to create a definition of a Bitmap image, used for marker icons and ground overlays.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.BitmapDescriptorFactory(): <a href="https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/bitmapdescriptorfactory-0000001050152411-V5">https://developer.huawei.com/consumer/cn/doc/HMSCore-References-V5/bitmapdescriptorfactory-0000001050152411-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public BitmapDescriptorFactory(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_AZURE() Constant Value: 210.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_AZURE: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_AZURE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_AZURE");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_AZURE;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_BLUE() Constant Value: 240.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_BLUE: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_BLUE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_BLUE");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_BLUE;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_CYAN() Constant Value: 180.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_CYAN: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_CYAN() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_CYAN");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_CYAN;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_GREEN() Constant Value: 120.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_GREEN: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_GREEN() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_GREEN");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_GREEN;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_MAGENTA() Constant Value: 300.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_MAGENTA: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_MAGENTA() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_MAGENTA");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_MAGENTA;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_ORANGE() Constant Value: 30.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ORANGE: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_ORANGE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ORANGE");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ORANGE;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_RED() Constant Value: 0.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_RED: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_RED() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_RED");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_RED;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_ROSE() Constant Value: 330.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ROSE: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_ROSE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ROSE");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_ROSE;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_VIOLET() Constant Value: 270.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_VIOLET: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_VIOLET() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_VIOLET");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_VIOLET;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.getHUE_YELLOW() Constant Value: 60.0.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_YELLOW: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf</a><br/>
     *
     * @return the return object is float
     */
    public static float getHUE_YELLOW() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_YELLOW");
        return com.huawei.hms.maps.model.BitmapDescriptorFactory.HUE_YELLOW;
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.defaultMarker(float) Creates a BitmapDescriptor that refers to a colorization of the default marker image. For convenience, there is a predefined set of hue values. See example HUE_YELLOW.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#defaultMarker(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#defaultMarker(float)</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return the return object is maps model BitmapDescriptor
     */
    public static org.xms.g.maps.model.BitmapDescriptor defaultMarker(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.defaultMarker() Creates a BitmapDescriptor that refers to the default marker image.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#defaultMarker()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#defaultMarker()</a><br/>
     *
     * @return the return object is maps model BitmapDescriptor
     */
    public static org.xms.g.maps.model.BitmapDescriptor defaultMarker() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker()");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.defaultMarker();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.fromAsset(java.lang.String) Creates a BitmapDescriptor using the name of a Bitmap image in the assets directory.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.fromAsset(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromAsset(String)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromAsset(String)</a><br/>
     *
     * @param param0 The name of a Bitmap image in the assets directory
     * @return the BitmapDescriptor that was loaded from the asset or null if failed to load
     */
    public static final org.xms.g.maps.model.BitmapDescriptor fromAsset(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.fromAsset(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.fromAsset(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.fromBitmap(android.graphics.Bitmap) Creates a BitmapDescriptor from a given Bitmap image.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.fromBitmap(android.graphics.Bitmap): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromBitmap(Bitmap)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromBitmap(Bitmap)</a><br/>
     *
     * @param param0 the param should instanceof android graphics Bitmap
     * @return the return object is maps model BitmapDescriptor
     */
    public static final org.xms.g.maps.model.BitmapDescriptor fromBitmap(android.graphics.Bitmap param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.fromBitmap(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.fromBitmap(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.fromFile(java.lang.String) Creates a BitmapDescriptor using the name of a Bitmap image file located in the internal storage. In particular, this calls openFileInput(String).<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.fromFile(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromFile(String)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromFile(String)</a><br/>
     *
     * @param param0 The name of the Bitmap image file
     * @return the BitmapDescriptor that was loaded from the asset or null if failed to load
     */
    public static final org.xms.g.maps.model.BitmapDescriptor fromFile(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.fromFile(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.fromFile(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.fromPath(java.lang.String) Creates a BitmapDescriptor from the absolute file path of a Bitmap image.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.fromPath(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromPath(String)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromPath(String)</a><br/>
     *
     * @param param0 The absolute path of the Bitmap image
     * @return the BitmapDescriptor that was loaded from the absolute path or null if failed to load
     */
    public static final org.xms.g.maps.model.BitmapDescriptor fromPath(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.fromPath(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.fromPath(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.fromResource(int) Creates a BitmapDescriptor using the resource ID of a Bitmap image.<br/>
     * com.huawei.hms.maps.model.BitmapDescriptorFactory.fromResource(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromResource(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-bitmapdescriptorf#fromResource(int)</a><br/>
     *
     * @param param0 The resource ID of a Bitmap image
     * @return the BitmapDescriptor that was loaded from the asset or null if failed to load
     */
    public static org.xms.g.maps.model.BitmapDescriptor fromResource(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.BitmapDescriptorFactory.fromResource(param0)");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = com.huawei.hms.maps.model.BitmapDescriptorFactory.fromResource(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.BitmapDescriptorFactory.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model BitmapDescriptorFactory object
     */
    public static org.xms.g.maps.model.BitmapDescriptorFactory dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.BitmapDescriptorFactory) param0);
    }
    
    /**
     * org.xms.g.maps.model.BitmapDescriptorFactory.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.BitmapDescriptorFactory;
    }
}