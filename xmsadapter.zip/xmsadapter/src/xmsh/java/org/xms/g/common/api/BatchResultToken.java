package org.xms.g.common.api;




/**
 * Result token used to retrieve the result of individual operations from a batch.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public final class BatchResultToken<XR extends org.xms.g.common.api.Result> extends org.xms.g.utils.XObject {
    
    
    
    /**
     * org.xms.g.common.api.BatchResultToken.BatchResultToken(org.xms.g.utils.XBox) constructor of BatchResultToken with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public BatchResultToken(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.api.BatchResultToken.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.BatchResultToken.<br/>
     *
     * @param param0 the input object
     * @return casted BatchResultToken object
     */
    public static org.xms.g.common.api.BatchResultToken dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.BatchResultToken) param0);
    }
    
    /**
     * org.xms.g.common.api.BatchResultToken.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        
        throw new RuntimeException("HMS does not support this API.");
    }
}