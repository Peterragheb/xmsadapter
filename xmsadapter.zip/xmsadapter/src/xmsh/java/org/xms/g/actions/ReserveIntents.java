package org.xms.g.actions;

/**
 * Constants for intents corresponding to Reserve Action.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public class ReserveIntents extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.actions.ReserveIntents.ReserveIntents(org.xms.g.utils.XBox) constructor of with ItemListIntents XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ReserveIntents(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.actions.ReserveIntents.getACTION_RESERVE_TAXI_RESERVATION() Intent action for reserving a taxi.<br/>
     *
     * @return return object is String
     */
    public static java.lang.String getACTION_RESERVE_TAXI_RESERVATION() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.actions.ReserveIntents.dynamicCast(java.lang.Object) dynamic cast the input object to ReserveIntents.<br/>
     *
     * @param param0 the param should instanceof java.lang.Object
     * @return ReserveIntents object
     */
    public static org.xms.g.actions.ReserveIntents dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.actions.ReserveIntents.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}