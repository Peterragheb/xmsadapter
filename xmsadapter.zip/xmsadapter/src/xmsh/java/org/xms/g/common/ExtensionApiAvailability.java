package org.xms.g.common;

/**
 * Helper class for verifying that the services APK is available and up-to-date on this device.<br/>
 * Wrapper class for com.huawei.hms.api.HuaweiApiAvailability, but only the HMS API are provided.<br/>
 * com.huawei.hms.api.HuaweiApiAvailability: Obtains the HMS Core(APK) availability of the current device.<br/>
 */
public class ExtensionApiAvailability extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.ExtensionApiAvailability(org.xms.g.utils.XBox) constructor of ExtensionApiAvailability with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionApiAvailability(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getGOOGLE_PLAY_SERVICES_PACKAGE() return the value of GOOGLE_PLAY_SERVICES_PACKAGE.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.SERVICES_PACKAGE: <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section17814142883619">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section17814142883619</a><br/>
     *
     * @return Package name for services
     */
    public static java.lang.String getGOOGLE_PLAY_SERVICES_PACKAGE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.api.HuaweiApiAvailability.SERVICES_PACKAGE");
        return com.huawei.hms.api.HuaweiApiAvailability.SERVICES_PACKAGE;
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getGOOGLE_PLAY_SERVICES_VERSION_CODE() return the value of GOOGLE_PLAY_SERVICES_VERSION_CODE.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.SERVICES_VERSION_CODE
     *
     * @return services client library version
     */
    public static int getGOOGLE_PLAY_SERVICES_VERSION_CODE() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.api.HuaweiApiAvailability.SERVICES_VERSION_CODE");
        return com.huawei.hms.api.HuaweiApiAvailability.SERVICES_VERSION_CODE;
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public org.xms.g.tasks.Task<java.lang.Void> checkApiAvailability(org.xms.g.common.api.HasApiKey<?> param0, org.xms.g.common.api.HasApiKey<?>... param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public org.xms.g.tasks.Task<java.lang.Void> checkApiAvailability(org.xms.g.common.api.ExtensionApi<?> param0, org.xms.g.common.api.ExtensionApi<?>... param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getErrorDialog(android.app.Activity,int,int) Returns a dialog to address the provided errorCode,The returned dialog displays a localized message about the error and upon user confirmation (by tapping on dialog) will direct them to the Play Store if Google Play services is out of date or missing, or to system settings if Google Play services is disabled on the device.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getErrorDialog(android.app.Activity,int,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1127052113378">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1127052113378</a><br/>
     *
     * @param param0 parent activity for creating the dialog, also used for identifying language to display dialog in
     * @param param1 error code returned by isGooglePlayServicesAvailable(Context) call, If errorCode is SUCCESS then null is returned
     * @param param2 The requestCode given when calling startActivityForResult
     * @return the ErrorDialog
     */
    public android.app.Dialog getErrorDialog(android.app.Activity param0, int param1, int param2) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorDialog(param0, param1, param2)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorDialog(param0, param1, param2);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getErrorDialog(android.app.Activity,int,int,android.content.DialogInterface.OnCancelListener) Returns a dialog to address the provided errorCode. The returned dialog displays a localized message about the error and upon user confirmation(by tapping on dialog) will direct them to the Play Store if Google Play services is out of date or missing, or to system settings if Google Play services is disabled on the device.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getErrorDialog(android.app.Activity,int,int,android.content.DialogInterface.OnCancelListener): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1191865182210">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1191865182210</a><br/>
     *
     * @param param0 parent activity for creating the dialog, also used for identifying language to display dialog in
     * @param param1 error code returned by isGooglePlayServicesAvailable(Context) call. If errorCode is SUCCESS then null is returned
     * @param param2 The requestCode given when calling startActivityForResult
     * @param param3 The DialogInterface.OnCancelListener to invoke if the dialog is canceled
     * @return the ErrorDialog
     */
    public android.app.Dialog getErrorDialog(android.app.Activity param0, int param1, int param2, android.content.DialogInterface.OnCancelListener param3) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorDialog(param0, param1, param2, param3)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorDialog(param0, param1, param2, param3);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getErrorResolutionPendingIntent(android.content.Context,org.xms.g.common.ConnectionResult) Returns a PendingIntent to address the provided connection failure.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getErrPendingIntent(android.content.Context,com.huawei.hms.api.ConnectionResult)
     *
     * @param param0 parent context for creating the PendingIntent
     * @param param1 the connection failure. If successful or the error is not resolvable by the user, null is returned
     * @return the PendingIntent
     */
    public android.app.PendingIntent getErrorResolutionPendingIntent(android.content.Context param0, org.xms.g.common.ConnectionResult param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrPendingIntent(param0, ((com.huawei.hms.api.ConnectionResult) ((param1) == null ? null : (param1.getHInstance()))))");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrPendingIntent(param0, ((com.huawei.hms.api.ConnectionResult) ((param1) == null ? null : (param1.getHInstance()))));
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getErrorResolutionPendingIntent(android.content.Context,int,int) Returns a PendingIntent to address the provided errorCode. It will direct the user to either the Play Store if Google Play services is out of date or missing, or system settings if Google Play services is disabled on the device.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getErrPendingIntent(android.content.Context,int,int)
     *
     * @param param0 parent context for creating the PendingIntent
     * @param param1 error code returned by isGooglePlayServicesAvailable(Context) call. If errorCode is SUCCESS then null is returned
     * @param param2 The requestCode given when calling startActivityForResult
     * @return the PendingIntent
     */
    public android.app.PendingIntent getErrorResolutionPendingIntent(android.content.Context param0, int param1, int param2) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrPendingIntent(param0, param1, param2)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrPendingIntent(param0, param1, param2);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getErrorString(int) Returns a human-readable string of the error code returned from isGooglePlayServicesAvailable(Context).<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getErrorString(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1351393293818">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section1351393293818</a><br/>
     *
     * @param param0 the errorCode
     * @return the ErrorString
     */
    public final java.lang.String getErrorString(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorString(param0)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getErrorString(param0);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.getInstance() Returns the singleton instance of GoogleApiAvailability.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getInstance(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section58256100109">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section58256100109</a><br/>
     *
     * @return the singleton instance of ExtensionApiAvailability
     */
    public static org.xms.g.common.ExtensionApiAvailability getInstance() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.api.HuaweiApiAvailability.getInstance()");
        com.huawei.hms.api.HuaweiApiAvailability hReturn = com.huawei.hms.api.HuaweiApiAvailability.getInstance();
        return ((hReturn) == null ? null : (new org.xms.g.common.ExtensionApiAvailability(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.isGooglePlayServicesAvailable(android.content.Context) Verifies that Google Play services is installed and enabled on this device, and that the version installed on this device is no older than the one required by this client.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.isHuaweiMobileServicesAvailable(android.content.Context): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section9492524178">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section9492524178</a><br/>
     *
     * @param param0 the Context
     * @return status code indicating whether there was an error. Can be one of following in ConnectionResult: SUCCESS, SERVICE_MISSING, SERVICE_UPDATING, SERVICE_VERSION_UPDATE_REQUIRED, SERVICE_DISABLED, SERVICE_INVALID
     */
    public int isGooglePlayServicesAvailable(android.content.Context param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isHuaweiMobileServicesAvailable(param0)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isHuaweiMobileServicesAvailable(param0);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.isGooglePlayServicesAvailable(android.content.Context,int) Verifies that Google Play services is installed and enabled on this device, and that the version installed on this device is no older than the one required by this client or the version is not older than the one specified in minApkVersion.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.isHuaweiMobileServicesAvailable(android.content.Context,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section94164961715">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section94164961715</a><br/>
     *
     * @param param0 the context
     * @param param1 the minApkVersion
     * @return status code indicating whether there was an error. Can be one of following in ConnectionResult: SUCCESS, SERVICE_MISSING, SERVICE_UPDATING, SERVICE_VERSION_UPDATE_REQUIRED, SERVICE_DISABLED, SERVICE_INVALID
     */
    public int isGooglePlayServicesAvailable(android.content.Context param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isHuaweiMobileServicesAvailable(param0, param1)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isHuaweiMobileServicesAvailable(param0, param1);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.isUserResolvableError(int) Determines whether an error can be resolved via user action,If true, proceed by calling getErrorDialog(Activity,int,int) and showing the dialog.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.isUserResolvableError(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section11471456162219">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section11471456162219</a><br/>
     *
     * @param param0 error code returned by isGooglePlayServicesAvailable(Context), or returned to your application via #onConnectionFailed(ConnectionResult)
     * @return boolean true if the error is resolvable with getErrorDialog(Activity,int,int)
     */
    public final boolean isUserResolvableError(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isUserResolvableError(param0)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).isUserResolvableError(param0);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.makeGooglePlayServicesAvailable(android.app.Activity) Attempts to make Google Play services available on this device. If Play Services is already available, the returned Task may complete immediately.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.getHuaweiServicesReady(android.app.Activity)
     *
     * @param param0 the passed Activity that will be used to display UI
     * @return A Task. If this Task completes without throwing an exception, Play Services is available on this device
     */
    public org.xms.g.tasks.Task<java.lang.Void> makeGooglePlayServicesAvailable(android.app.Activity param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getHuaweiServicesReady(param0)");
        com.huawei.hmf.tasks.Task hReturn = ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).getHuaweiServicesReady(param0);
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void setDefaultNotificationChannelId(android.content.Context param0, java.lang.String param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.showErrorDialogFragment(android.app.Activity,int,int) Displays a DialogFragment for an error code returned by isGooglePlayServicesAvailable(Context).<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.showErrorDialogFragment(android.app.Activity,int,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section52231618134417">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section52231618134417</a><br/>
     *
     * @param param0 parent activity for creating the dialog, also used for identifying language to display dialog in
     * @param param1 error code returned by isGooglePlayServicesAvailable(Context) call. If errorCode is SUCCESS then this does nothing
     * @param param2 The requestCode given when calling startActivityForResult
     * @return true if the dialog is shown, false otherwise
     */
    public boolean showErrorDialogFragment(android.app.Activity param0, int param1, int param2) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorDialogFragment(param0, param1, param2)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorDialogFragment(param0, param1, param2);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.showErrorDialogFragment(android.app.Activity,int,int,android.content.DialogInterface.OnCancelListener) Displays a DialogFragment for an error code returned by isGooglePlayServicesAvailable(Context).<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.showErrorDialogFragment(android.app.Activity,int,int,android.content.DialogInterface.OnCancelListener): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section421173818230">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section421173818230</a><br/>
     *
     * @param param0 parent activity for creating the dialog, also used for identifying language to display dialog in
     * @param param1 error code returned by isGooglePlayServicesAvailable(Context) call. If errorCode is SUCCESS then this does nothing
     * @param param2 The requestCode given when calling startActivityForResult
     * @param param3 The DialogInterface.OnCancelListener to invoke if the dialog is canceled
     * @return true if the dialog is shown, false otherwise
     */
    public boolean showErrorDialogFragment(android.app.Activity param0, int param1, int param2, android.content.DialogInterface.OnCancelListener param3) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorDialogFragment(param0, param1, param2, param3)");
        return ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorDialogFragment(param0, param1, param2, param3);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.showErrorNotification(android.content.Context,int) Displays a notification for an error code returned from isGooglePlayServicesAvailable(Context), if it is resolvable by the user.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.showErrorNotification(android.content.Context,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section138621443204620">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/huaweiapiavailability-0000001050121134#EN-US_TOPIC_0000001050121134__section138621443204620</a><br/>
     *
     * @param param0 The calling context for displaying the notification
     * @param param1 Error code returned by isGooglePlayServicesAvailable(Context). For other values, including SUCCESS, no notification is shown
     */
    public void showErrorNotification(android.content.Context param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorNotification(param0, param1)");
        ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).showErrorNotification(param0, param1);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.showErrorNotification(android.content.Context,org.xms.g.common.ConnectionResult) Displays a notification for a connection failure, if it is resolvable by the user.<br/>
     * com.huawei.hms.api.HuaweiApiAvailability.popupErrNotification(android.content.Context,com.huawei.hms.api.ConnectionResult)
     *
     * @param param0 The calling context used to display the notification
     * @param param1 The connection failure. If successful or the error is not resolvable by the user, no notification is shown
     */
    public void showErrorNotification(android.content.Context param0, org.xms.g.common.ConnectionResult param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).popupErrNotification(param0, ((com.huawei.hms.api.ConnectionResult) ((param1) == null ? null : (param1.getHInstance()))))");
        ((com.huawei.hms.api.HuaweiApiAvailability) this.getHInstance()).popupErrNotification(param0, ((com.huawei.hms.api.ConnectionResult) ((param1) == null ? null : (param1.getHInstance()))));
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.ExtensionApiAvailability.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionApiAvailability object
     */
    public static org.xms.g.common.ExtensionApiAvailability dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.ExtensionApiAvailability) param0);
    }
    
    /**
     * org.xms.g.common.ExtensionApiAvailability.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.api.HuaweiApiAvailability;
    }
}