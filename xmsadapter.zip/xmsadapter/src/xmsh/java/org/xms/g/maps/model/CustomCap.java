package org.xms.g.maps.model;

/**
 * xms Bitmap overlay centered at the start or end vertex of a Polyline.<br/>
 * Wrapper class for com.huawei.hms.maps.model.CustomCap, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.CustomCap: Extends the Cap class to customize the cap style for a polyline.<br/>
 */
public final class CustomCap extends org.xms.g.maps.model.Cap {
    
    /**
     * org.xms.g.maps.model.CustomCap.CustomCap(org.xms.g.utils.XBox) Constructs a new CustomCap.<br/>
     * com.huawei.hms.maps.model.CustomCap.CustomCap(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public CustomCap(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.CustomCap(org.xms.g.maps.model.BitmapDescriptor,float) Constructs a new CustomCap.<br/>
     * com.huawei.hms.maps.model.CustomCap.CustomCap(com.huawei.hms.maps.model.BitmapDescriptor,float): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5</a><br/>
     *
     * @param param0 Descriptor of the bitmap to be used
     * @param param1 Stroke width, in pixels, for which the cap bitmap at its native dimension is designed
     */
    public CustomCap(org.xms.g.maps.model.BitmapDescriptor param0, float param1) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.CustomCap(((com.huawei.hms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getHInstance()))), param1));
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.CustomCap(org.xms.g.maps.model.BitmapDescriptor) Constructs a new CustomCap.<br/>
     * com.huawei.hms.maps.model.CustomCap.CustomCap(com.huawei.hms.maps.model.BitmapDescriptor): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/customcap-0000001050150644-V5</a><br/>
     *
     * @param param0 Descriptor of the bitmap to be used. Must not be null
     */
    public CustomCap(org.xms.g.maps.model.BitmapDescriptor param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.CustomCap(((com.huawei.hms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getHInstance())))));
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.getBitmapDescriptor() Descriptor of the bitmap to be overlaid at the start or end vertex.<br/>
     * com.huawei.hms.maps.model.CustomCap.bitmapDescriptor: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap</a><br/>
     *
     * @return the return object is maps model BitmapDescriptor
     */
    public org.xms.g.maps.model.BitmapDescriptor getBitmapDescriptor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).bitmapDescriptor");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = null;
        hReturn = ((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).bitmapDescriptor;
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.getRefWidth() Reference stroke width(in pixels)- the stroke width for which the cap bitmap at its native dimension is designed. The default reference stroke width is 10 pixels.<br/>
     * com.huawei.hms.maps.model.CustomCap.refWidth: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap</a><br/>
     *
     * @return the return object is float
     */
    public float getRefWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).refWidth");
        return ((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).refWidth;
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.toString() to String.<br/>
     * com.huawei.hms.maps.model.CustomCap.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-customcap</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.CustomCap) this.getHInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.CustomCap.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model CustomCap object
     */
    public static org.xms.g.maps.model.CustomCap dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.CustomCap) param0);
    }
    
    /**
     * org.xms.g.maps.model.CustomCap.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.CustomCap;
    }
}