package org.xms.g.maps.model;

/**
 * xms Defines options for a polygon.<br/>
 * Wrapper class for com.huawei.hms.maps.model.PolygonOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.PolygonOptions: Defines attributes for a Polygon.<br/>
 */
public final class PolygonOptions extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.PolygonOptions createFromParcel(android.os.Parcel param0) {
            com.huawei.hms.maps.model.PolygonOptions hReturn = com.huawei.hms.maps.model.PolygonOptions.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn));
        }
        
        public org.xms.g.maps.model.PolygonOptions[] newArray(int param0) {
            return new org.xms.g.maps.model.PolygonOptions[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.PolygonOptions.PolygonOptions(org.xms.g.utils.XBox) Defines options for a polygon.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.PolygonOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygonoptions-0000001050153037-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygonoptions-0000001050153037-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public PolygonOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.PolygonOptions() Defines options for a polygon.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.PolygonOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygonoptions-0000001050153037-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/polygonoptions-0000001050153037-V5</a><br/>
     *
     */
    public PolygonOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.PolygonOptions());
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.add(org.xms.g.maps.model.LatLng) Adds a vertex to the outline of the polygon being built.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.add(com.huawei.hms.maps.model.LatLng): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#add(LatLng)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#add(LatLng)</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return this PolygonOptions object with the given point added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions add(org.xms.g.maps.model.LatLng... param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).add(((com.huawei.hms.maps.model.LatLng[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hms.maps.model.LatLng.class, x -> (com.huawei.hms.maps.model.LatLng)x.getHInstance())))");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).add(((com.huawei.hms.maps.model.LatLng[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.huawei.hms.maps.model.LatLng.class, x -> (com.huawei.hms.maps.model.LatLng)x.getHInstance())));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.add(org.xms.g.maps.model.LatLng) Adds a vertex to the outline of the polygon being built.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.add(com.huawei.hms.maps.model.LatLng): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#add(LatLng)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#add(LatLng)</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return this PolygonOptions object with the given point added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions add(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).add(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).add(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.addAll(java.lang.Iterable<org.xms.g.maps.model.LatLng>) Adds vertices to the outline of the polygon being built.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.addAll(java.lang.Iterable<com.huawei.hms.maps.model.LatLng>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#addAll(Iterable%3CLatLng%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#addAll(Iterable%3CLatLng%3E)</a><br/>
     *
     * @param param0 the param should instanceof java lang Iterable<LatLng>
     * @return this PolygonOptions object with the given points added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions addAll(java.lang.Iterable<org.xms.g.maps.model.LatLng> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).addAll(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, true)))");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).addAll(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, true)));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.addHole(java.lang.Iterable<org.xms.g.maps.model.LatLng>) Adds a hole to the polygon being built.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.addHole(java.lang.Iterable<com.huawei.hms.maps.model.LatLng>): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#addHole(Iterable%3CLatLng%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#addHole(Iterable%3CLatLng%3E)</a><br/>
     *
     * @param param0 the param should instanceof java lang Iterable<LatLng>
     * @return this PolygonOptions object with the given hole added
     */
    public final org.xms.g.maps.model.PolygonOptions addHole(java.lang.Iterable<org.xms.g.maps.model.LatLng> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).addHole(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, true)))");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).addHole(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, true)));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.clickable(boolean) Specifies whether this polygon is clickable. The default setting is false.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.clickable(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#clickable(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#clickable(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new clickability setting
     */
    public final org.xms.g.maps.model.PolygonOptions clickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).clickable(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).clickable(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.fillColor(int) Specifies the polygon's fill color, as 32-bit ARGB. The default color is black( 0xff000000).<br/>
     * com.huawei.hms.maps.model.PolygonOptions.fillColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#fillColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#fillColor(int)</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new fill color set
     */
    public final org.xms.g.maps.model.PolygonOptions fillColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).fillColor(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).fillColor(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.geodesic(boolean) Specifies whether to draw each segment of this polygon as a geodesic. The default setting is false.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.geodesic(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#geodesic(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#geodesic(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new geodesic setting
     */
    public final org.xms.g.maps.model.PolygonOptions geodesic(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).geodesic(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).geodesic(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getFillColor() Gets the fill color set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getFillColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getFillColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getFillColor()</a><br/>
     *
     * @return the fill color of the polygon in screen pixels
     */
    public final int getFillColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getFillColor()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getFillColor();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getHoles() Gets the holes set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getHoles(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getHoles()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getHoles()</a><br/>
     *
     * @return the list of List<LatLng>s specifying the holes of the polygon
     */
    public final java.util.List<java.util.List<org.xms.g.maps.model.LatLng>> getHoles() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getHoles()");
        java.util.List<java.util.List<com.huawei.hms.maps.model.LatLng>> hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getHoles();
        return org.xms.g.utils.Utils.mapList(hReturn, e -> org.xms.g.utils.Utils.mapList2X(e, true));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getPoints() Gets the outline set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getPoints(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getPoints()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getPoints()</a><br/>
     *
     * @return the list of LatLngs specifying the vertices of the outline of the polygon
     */
    public final java.util.List<org.xms.g.maps.model.LatLng> getPoints() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getPoints()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getPoints();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
            
            public org.xms.g.maps.model.LatLng apply(com.huawei.hms.maps.model.LatLng param0) {
                return new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeColor() Gets the stroke color set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getStrokeColor(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeColor()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeColor()</a><br/>
     *
     * @return the stroke color of the polygon in screen pixels
     */
    public final int getStrokeColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeColor()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeColor();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeJointType() Gets the stroke joint type set in this PolygonOptions object for all vertices of the polygon's outline. See JointType for possible values.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getStrokeJointType(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeJointType()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeJointType()</a><br/>
     *
     * @return the stroke joint type of the polygon's outline
     */
    public final int getStrokeJointType() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeJointType()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeJointType();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokePattern() Gets the stroke pattern set in this PolygonOptions object for the polygon's outline.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getStrokePattern(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokePattern()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokePattern()</a><br/>
     *
     * @return the stroke pattern of the polygon's outline
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getStrokePattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokePattern()");
        java.util.List hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokePattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.huawei.hms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeWidth() Gets the stroke width set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getStrokeWidth(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeWidth()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getStrokeWidth()</a><br/>
     *
     * @return the stroke width of the polygon in screen pixels
     */
    public final float getStrokeWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeWidth()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getStrokeWidth();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getZIndex() Gets the zIndex set for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#getZIndex()</a><br/>
     *
     * @return the zIndex of the polygon
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isClickable() Gets the clickability setting for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.isClickable(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isClickable()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isClickable()</a><br/>
     *
     * @return true if the polygon is clickable; false if it is not
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isClickable()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isGeodesic() Gets the geodesic setting for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.isGeodesic(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isGeodesic()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isGeodesic()</a><br/>
     *
     * @return true if the polygon segments should be geodesics; false if they should not be
     */
    public final boolean isGeodesic() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isGeodesic()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isGeodesic();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isVisible() Gets the visibility setting for this PolygonOptions object.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#isVisible()</a><br/>
     *
     * @return true if the polygon is to be visible; false if it is not
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeColor(int) Specifies the polygon's stroke color, as 32-bit ARGB. The default color is black( 0xff000000).<br/>
     * com.huawei.hms.maps.model.PolygonOptions.strokeColor(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeColor(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeColor(int)</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new stroke color set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeColor(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeColor(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeJointType(int) Specifies the joint type for all vertices of the polygon's outline.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.strokeJointType(int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeJointType(int)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeJointType(int)</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new stroke joint type set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeJointType(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeJointType(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeJointType(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokePattern(java.util.List) Specifies a stroke pattern for the polygon's outline. The default stroke pattern is solid, represented by null.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.strokePattern(java.util.List): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokePattern(List%3CPatternItem%3E)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokePattern(List%3CPatternItem%3E)</a><br/>
     *
     * @param param0 the param should instanceof java util List
     * @return the return object is maps model PolygonOptions
     */
    public final org.xms.g.maps.model.PolygonOptions strokePattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true))");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, true));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeWidth(float) Specifies the polygon's stroke width, in display pixels. The default width is 10.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.strokeWidth(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeWidth(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#strokeWidth(float)</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this PolygonOptions object with a new stroke width set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeWidth(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).strokeWidth(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.visible(boolean) Specifies the visibility for the polygon. The default visibility is true.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.visible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#visible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#visible(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new visibility setting
     */
    public final org.xms.g.maps.model.PolygonOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).visible(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).visible(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.zIndex(float) Specifies the polygon's zIndex, i.e., the order in which it will be drawn. See the documentation at the top of this class for more information about zIndex.<br/>
     * com.huawei.hms.maps.model.PolygonOptions.zIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#zIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-polygonoptions#zIndex(float)</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this PolygonOptions object with a new zIndex set
     */
    public final org.xms.g.maps.model.PolygonOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).zIndex(param0)");
        com.huawei.hms.maps.model.PolygonOptions hReturn = ((com.huawei.hms.maps.model.PolygonOptions) this.getHInstance()).zIndex(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.PolygonOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model PolygonOptions object
     */
    public static org.xms.g.maps.model.PolygonOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.PolygonOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.PolygonOptions;
    }
}