package org.xms.g.maps.model;

/**
 * xms An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
 * Wrapper class for com.huawei.hms.maps.model.Gap, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.Gap: Extends PatternItem and represents a gap used in the stroke pattern for a polyline or the outline of a polygon or circle.<br/>
 */
public final class Gap extends org.xms.g.maps.model.PatternItem {
    
    /**
     * org.xms.g.maps.model.Gap.Gap(org.xms.g.utils.XBox) An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.huawei.hms.maps.model.Gap.Gap(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/gap-0000001050152621-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/gap-0000001050152621-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Gap(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Gap.Gap(float) An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.huawei.hms.maps.model.Gap.Gap(float): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/gap-0000001050152621-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/gap-0000001050152621-V5</a><br/>
     *
     * @param param0 Length in pixels. Negative value will be clamped to zero
     */
    public Gap(float param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.Gap(param0));
    }
    
    /**
     * org.xms.g.maps.model.Gap.getLength() Length in pixels. Negative value will be clamped to zero.<br/>
     * com.huawei.hms.maps.model.Gap.length: <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-gap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-gap</a><br/>
     *
     * @return the return object is float
     */
    public float getLength() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Gap) this.getHInstance()).length");
        return ((com.huawei.hms.maps.model.Gap) this.getHInstance()).length;
    }
    
    /**
     * org.xms.g.maps.model.Gap.toString() to String.<br/>
     * com.huawei.hms.maps.model.Gap.toString(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-gap">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-gap</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.Gap) this.getHInstance()).toString()");
        return ((com.huawei.hms.maps.model.Gap) this.getHInstance()).toString();
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.Gap.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Gap.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Gap object
     */
    public static org.xms.g.maps.model.Gap dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Gap) param0);
    }
    
    /**
     * org.xms.g.maps.model.Gap.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.Gap;
    }
}