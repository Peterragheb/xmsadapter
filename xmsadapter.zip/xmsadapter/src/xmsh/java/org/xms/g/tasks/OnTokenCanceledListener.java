package org.xms.g.tasks;

/**
 * Listener called when a CancellationToken is canceled successfully.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public interface OnTokenCanceledListener extends org.xms.g.utils.XInterface {
    
    /**
     * XMS does not provide this api.<br/>
     */
    public void onCanceled();
    
    default java.lang.Object getZInstanceOnTokenCanceledListener() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    default java.lang.Object getHInstanceOnTokenCanceledListener() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.tasks.OnTokenCanceledListener.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.OnTokenCanceledListener.<br/>
     *
     * @param param0 the input object
     * @return casted OnTokenCanceledListener object
     */
    public static org.xms.g.tasks.OnTokenCanceledListener dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.tasks.OnTokenCanceledListener.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * Listener called when a CancellationToken is canceled successfully.<br/>
     * Wrapper class for , but only the HMS API are provided.<br/>
     * : <br/>
     */
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.tasks.OnTokenCanceledListener {
        
        /**
         * org.xms.g.tasks.OnTokenCanceledListener.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * XMS does not provide this api.<br/>
         */
        public void onCanceled() {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}