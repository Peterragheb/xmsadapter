package org.xms.g.common.api;

/**
 * Exception that's thrown when an API call is not supported by services package.<br/>
 * Wrapper class for com.huawei.hms.common.api.UnsupportedApiCallException, but only the HMS API are provided.<br/>
 * com.huawei.hms.common.api.UnsupportedApiCallException: <br/>
 */
public final class UnsupportedApiCallException extends java.lang.UnsupportedOperationException implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.UnsupportedApiCallException(org.xms.g.utils.XBox) constructor of UnsupportedApiCallException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public UnsupportedApiCallException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.getMessage() return the message of UnsupportedApiCallException.<br/>
     * com.huawei.hms.common.api.UnsupportedApiCallException.getMessage()
     *
     * @return the message of UnsupportedApiCallException
     */
    public final java.lang.String getMessage() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.api.UnsupportedApiCallException) this.getHInstance()).getMessage()");
        return ((com.huawei.hms.common.api.UnsupportedApiCallException) this.getHInstance()).getMessage();
    }
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.setHInstance(java.lang.Object) set the hms instance from the corresponding xms instance.<br/>
     *
     * @param param0 Instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return Instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.UnsupportedApiCallException.<br/>
     *
     * @param param0 the input object
     * @return casted UnsupportedApiCallException object
     */
    public static org.xms.g.common.api.UnsupportedApiCallException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.UnsupportedApiCallException) param0);
    }
    
    /**
     * org.xms.g.common.api.UnsupportedApiCallException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.common.api.UnsupportedApiCallException;
    }
}