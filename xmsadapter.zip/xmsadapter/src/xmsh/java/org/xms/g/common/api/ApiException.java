package org.xms.g.common.api;

/**
 * Exception to be returned when a call to HMS or GMS SDK has failed.<br/>
 * Wrapper class for com.huawei.hms.common.ApiException, but only the HMS API are provided.<br/>
 * com.huawei.hms.common.ApiException: Exception returned when the HMS SDK call fails.<br/>
 */
public class ApiException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.api.ApiException.ApiException(org.xms.g.utils.XBox) constructor of ApiException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ApiException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ApiException.ApiException(org.xms.g.common.api.Status) Create an ApiException from a Status.<br/>
     * com.huawei.hms.common.ApiException.ApiException(com.huawei.hms.support.api.client.Status): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section425714488549">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section425714488549</a><br/>
     *
     * @param param0 the Status instance containing a message and code
     */
    public ApiException(org.xms.g.common.api.Status param0) {
        this.setHInstance(new HImpl(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance())))));
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ApiException.getStatusCode() Indicates the status of the operation.<br/>
     * com.huawei.hms.common.ApiException.getStatusCode(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section32821622269</a><br/>
     *
     * @return Status code resulting from the operation
     */
    public int getStatusCode() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.ApiException) this.getHInstance()).getStatusCode()");
            return ((com.huawei.hms.common.ApiException) this.getHInstance()).getStatusCode();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.common.ApiException) this.getHInstance())).getStatusCodeCallSuper()");
            return ((HImpl) ((com.huawei.hms.common.ApiException) this.getHInstance())).getStatusCodeCallSuper();
        }
    }
    
    /**
     * org.xms.g.common.api.ApiException.getStatusMessage() Obtains the status description.<br/>
     * com.huawei.hms.common.ApiException.getStatusMessage(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section0102201410491">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/apiexception-0000001050123087#EN-US_TOPIC_0000001050123087__section0102201410491</a><br/>
     *
     * @return Status description
     */
    public java.lang.String getStatusMessage() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.common.ApiException) this.getHInstance()).getStatusMessage()");
            return ((com.huawei.hms.common.ApiException) this.getHInstance()).getStatusMessage();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.common.ApiException) this.getHInstance())).getStatusMessageCallSuper()");
            return ((HImpl) ((com.huawei.hms.common.ApiException) this.getHInstance())).getStatusMessageCallSuper();
        }
    }
    
    /**
     * org.xms.g.common.api.ApiException.setHInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 Instance of hms api
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.common.api.ApiException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return Instance of hms api
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.common.api.ApiException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ApiException.<br/>
     *
     * @param param0 the input object
     * @return casted ApiException object
     */
    public static org.xms.g.common.api.ApiException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.ApiException) param0);
    }
    
    /**
     * org.xms.g.common.api.ApiException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.common.ApiException;
    }
    
    private class HImpl extends com.huawei.hms.common.ApiException {
        
        public int getStatusCode() {
            return org.xms.g.common.api.ApiException.this.getStatusCode();
        }
        
        public java.lang.String getStatusMessage() {
            return org.xms.g.common.api.ApiException.this.getStatusMessage();
        }
        
        public int getStatusCodeCallSuper() {
            return super.getStatusCode();
        }
        
        public java.lang.String getStatusMessageCallSuper() {
            return super.getStatusMessage();
        }
        
        public HImpl(com.huawei.hms.support.api.client.Status param0) {
            super(param0);
        }
    }
}