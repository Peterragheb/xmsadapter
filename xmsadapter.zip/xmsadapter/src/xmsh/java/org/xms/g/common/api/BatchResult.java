package org.xms.g.common.api;

/**
 * The result of a batch operation.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public final class BatchResult extends org.xms.g.utils.XObject implements org.xms.g.common.api.Result {
    
    /**
     * org.xms.g.common.api.BatchResult.BatchResult(org.xms.g.utils.XBox) constructor of BatchResult with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public BatchResult(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final org.xms.g.common.api.Status getStatus() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final <XR extends org.xms.g.common.api.Result> XR take(org.xms.g.common.api.BatchResultToken<XR> param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.BatchResult.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.BatchResult.<br/>
     *
     * @param param0 the input object
     * @return casted BatchResult object
     */
    public static org.xms.g.common.api.BatchResult dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.BatchResult.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}