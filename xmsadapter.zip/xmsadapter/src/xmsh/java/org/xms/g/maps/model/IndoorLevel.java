package org.xms.g.maps.model;

/**
 * xms Represents a level in a building.<br/>
 * Wrapper class for com.huawei.hms.maps.model.IndoorLevel, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.IndoorLevel: Represents a level in a building.<br/>
 */
public final class IndoorLevel extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.IndoorLevel.IndoorLevel(org.xms.g.utils.XBox) Represents a level in a building.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.IndoorLevel()
     *
     * @param param0 the param should instanceof utils XBox
     */
    public IndoorLevel(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.activate() Sets this level as the visible level in its building.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.activate()
     *
     */
    public final void activate() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).activate()");
        ((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).activate();
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.equals(java.lang.Object) Tests if this IndoorLevel is equal to another.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.equals(java.lang.Object)
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).equals(param0)");
        return ((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.getName() Localized display name for the level, e.g."Ground floor". Returns an empty string if no name is defined.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.getName()
     *
     * @return the return object is java lang String
     */
    public final java.lang.String getName() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).getName()");
        return ((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).getName();
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.getShortName() Localized short display name for the level, e.g."1". Returns an empty string if no shortName is defined.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.getShortName()
     *
     * @return the return object is java lang String
     */
    public final java.lang.String getShortName() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).getShortName()");
        return ((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).getShortName();
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.hashCode() hash Code.<br/>
     * com.huawei.hms.maps.model.IndoorLevel.hashCode()
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).hashCode()");
        return ((com.huawei.hms.maps.model.IndoorLevel) this.getHInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.IndoorLevel.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model IndoorLevel object
     */
    public static org.xms.g.maps.model.IndoorLevel dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.IndoorLevel) param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorLevel.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.IndoorLevel;
    }
}