package org.xms.g.maps;

/**
 * xms A View which displays a map(with data obtained from the Maps service).<br/>
 * Wrapper class for com.huawei.hms.maps.MapView, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.MapView: Extends FrameLayout and represents a view in which a map is displayed. The view data is obtained from HUAWEI Map Kit.<br/>
 */
public class MapView extends android.widget.FrameLayout implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    private boolean wrapper = true;
    
    /**
     * org.xms.g.maps.MapView.MapView(android.content.Context) constructor of MapView.<br/>
     * com.huawei.hms.maps.MapView.MapView(android.content.Context): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview</a><br/>
     *
     * @param param0 the param is android content Context
     */
    public MapView(android.content.Context param0) {
        super(param0);
        this.setHInstance(new HImpl(param0));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.MapView.MapView(android.content.Context,android.util.AttributeSet) constructor of MapView.<br/>
     * com.huawei.hms.maps.MapView.MapView(android.content.Context,android.util.AttributeSet): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview</a><br/>
     *
     * @param param0 the param is android content Context
     * @param param1 the param is android util AttributeSet
     */
    public MapView(android.content.Context param0, android.util.AttributeSet param1) {
        super(param0, param1);
        this.setHInstance(new HImpl(param0, param1));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.MapView.MapView(android.content.Context,android.util.AttributeSet,int) constructor of MapView.<br/>
     * com.huawei.hms.maps.MapView.MapView(android.content.Context,android.util.AttributeSet,int): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview</a><br/>
     *
     * @param param0 the param is android content Context
     * @param param1 the param is android util AttributeSet
     * @param param2 the param is int
     */
    public MapView(android.content.Context param0, android.util.AttributeSet param1, int param2) {
        super(param0, param1, param2);
        this.setHInstance(new HImpl(param0, param1, param2));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.MapView.MapView(android.content.Context,org.xms.g.maps.ExtensionMapOptions) constructor of MapView.<br/>
     * com.huawei.hms.maps.MapView.MapView(android.content.Context,com.huawei.hms.maps.HuaweiMapOptions): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview</a><br/>
     *
     * @param param0 the param is android content Context
     * @param param1 the params is maps ExtensionMapOptions
     */
    public MapView(android.content.Context param0, org.xms.g.maps.ExtensionMapOptions param1) {
        super(param0);
        this.setHInstance(new HImpl(param0, ((com.huawei.hms.maps.HuaweiMapOptions) ((param1) == null ? null : (param1.getHInstance())))));
        wrapper = false;
    }
    
    /**
     * org.xms.g.maps.MapView.getMapAsync(org.xms.g.maps.OnMapReadyCallback) Returns a non-null instance of the GoogleMap, ready to be used.<br/>
     * com.huawei.hms.maps.MapView.getMapAsync(com.huawei.hms.maps.OnMapReadyCallback): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#getMapAsync(OnMapReadyCallback)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#getMapAsync(OnMapReadyCallback)</a><br/>
     *
     * @param param0 The callback object that will be triggered when the map is ready to be used
     */
    public void getMapAsync(org.xms.g.maps.OnMapReadyCallback param0) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).getMapAsync(((param0) == null ? null : (param0.getHInstanceOnMapReadyCallback())))");
            ((com.huawei.hms.maps.MapView) this.getHInstance()).getMapAsync(((param0) == null ? null : (param0.getHInstanceOnMapReadyCallback())));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.maps.MapView) this.getHInstance())).getMapAsyncCallSuper(((param0) == null ? null : (param0.getHInstanceOnMapReadyCallback())))");
            ((HImpl) ((com.huawei.hms.maps.MapView) this.getHInstance())).getMapAsyncCallSuper(((param0) == null ? null : (param0.getHInstanceOnMapReadyCallback())));
        }
    }
    
    /**
     * org.xms.g.maps.MapView.onCreate(android.os.Bundle) Called when a map is created. If this method needs to be reloaded, call it from the parent class.<br/>
     * com.huawei.hms.maps.MapView.onCreate(android.os.Bundle): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onCreate(Bundle)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onCreate(Bundle)</a><br/>
     *
     * @param param0 the param is android os Bundle
     */
    public final void onCreate(android.os.Bundle param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onCreate(param0)");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onCreate(param0);
    }
    
    /**
     * org.xms.g.maps.MapView.onDestroy() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onDestroy(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onDestroy()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onDestroy()</a><br/>
     *
     */
    public final void onDestroy() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onDestroy()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onDestroy();
    }
    
    /**
     * org.xms.g.maps.MapView.onEnterAmbient(android.os.Bundle) You must call this method from the parent WearableActivity's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onEnterAmbient(android.os.Bundle)
     *
     * @param param0 the param is Bundle
     */
    public final void onEnterAmbient(android.os.Bundle param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onEnterAmbient(param0)");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onEnterAmbient(param0);
    }
    
    /**
     * org.xms.g.maps.MapView.onExitAmbient() You must call this method from the parent WearableActivity's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onExitAmbient()
     *
     */
    public final void onExitAmbient() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onExitAmbient()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onExitAmbient();
    }
    
    /**
     * org.xms.g.maps.MapView.onLowMemory() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onLowMemory(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onLowMemory()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onLowMemory()</a><br/>
     *
     */
    public final void onLowMemory() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onLowMemory()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onLowMemory();
    }
    
    /**
     * org.xms.g.maps.MapView.onPause() Called when an activity is paused. If this method needs to be reloaded, call it from the parent class.<br/>
     * com.huawei.hms.maps.MapView.onPause(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onPause()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onPause()</a><br/>
     *
     */
    public final void onPause() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onPause()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onPause();
    }
    
    /**
     * org.xms.g.maps.MapView.onResume() Called when an activity is ready. If this method needs to be reloaded, call it from the parent class.<br/>
     * com.huawei.hms.maps.MapView.onResume(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onResume()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onResume()</a><br/>
     *
     */
    public final void onResume() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onResume()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onResume();
    }
    
    /**
     * org.xms.g.maps.MapView.onSaveInstanceState(android.os.Bundle) Called to save the current status of a MapView object upon unexpected exit. If this method needs to be reloaded, call it from the parent class.<br/>
     * com.huawei.hms.maps.MapView.onSaveInstanceState(android.os.Bundle): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onSaveInstanceState(Bundle)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onSaveInstanceState(Bundle)</a><br/>
     *
     * @param param0 the param is android os Bundle
     */
    public final void onSaveInstanceState(android.os.Bundle param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onSaveInstanceState(param0)");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onSaveInstanceState(param0);
    }
    
    /**
     * org.xms.g.maps.MapView.onStart() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onStart(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onStart()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onStart()</a><br/>
     *
     */
    public final void onStart() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onStart()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onStart();
    }
    
    /**
     * org.xms.g.maps.MapView.onStop() You must call this method from the parent Activity/Fragment's corresponding method.<br/>
     * com.huawei.hms.maps.MapView.onStop(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onStop()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-mapview#onStop()</a><br/>
     *
     */
    public final void onStop() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.MapView) this.getHInstance()).onStop()");
        ((com.huawei.hms.maps.MapView) this.getHInstance()).onStop();
    }
    
    /**
     * org.xms.g.maps.MapView.setHInstance(java.lang.Object) set HInstance.<br/>
     *
     * @param param0 the param should be instanceof java lang Object
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
        this.removeAllViews();
        this.addView(((com.huawei.hms.maps.MapView) hInstance));
        this.setClickable(true);
    }
    
    /**
     * org.xms.g.maps.MapView.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the return object hInstance
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.maps.MapView.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.MapView.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps MapView object
     */
    public static org.xms.g.maps.MapView dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.MapView) param0);
    }
    
    /**
     * org.xms.g.maps.MapView.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.MapView;
    }
    
    /**
     * org.xms.g.maps.MapView.wrapInst(org.xms.g.utils.XBox) wrapInst.<br/>
     *
     * @param param0 the param should instanceof utils XBox
     * @return the return object is maps MapView
     */
    public org.xms.g.maps.MapView wrapInst(org.xms.g.utils.XBox param0) {
        hInstance = param0.getHInstance();
        wrapper = true;
        return this;
    }
    
    private class HImpl extends com.huawei.hms.maps.MapView {
        
        public void getMapAsync(com.huawei.hms.maps.OnMapReadyCallback param0) {
            org.xms.g.maps.MapView.this.getMapAsync(((param0) == null ? null : (new org.xms.g.maps.OnMapReadyCallback.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void getMapAsyncCallSuper(com.huawei.hms.maps.OnMapReadyCallback param0) {
            super.getMapAsync(param0);
        }
        
        public HImpl(android.content.Context param0) {
            super(param0);
        }
        
        public HImpl(android.content.Context param0, android.util.AttributeSet param1) {
            super(param0, param1);
        }
        
        public HImpl(android.content.Context param0, android.util.AttributeSet param1, int param2) {
            super(param0, param1, param2);
        }
        
        public HImpl(android.content.Context param0, com.huawei.hms.maps.HuaweiMapOptions param1) {
            super(param0, param1);
        }
    }
}