package org.xms.g.maps.model;

/**
 * xms Defines options for a ground overlay.<br/>
 * Wrapper class for com.huawei.hms.maps.model.GroundOverlayOptions, but only the HMS API are provided.<br/>
 * com.huawei.hms.maps.model.GroundOverlayOptions: Defines attributes for a ground overlay.<br/>
 */
public final class GroundOverlayOptions extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.GroundOverlayOptions(org.xms.g.utils.XBox) Defines options for a ground overlay.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.GroundOverlayOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/groundoverlayoptions-0000001050152689-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/groundoverlayoptions-0000001050152689-V5</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public GroundOverlayOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.GroundOverlayOptions() Defines options for a ground overlay.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.GroundOverlayOptions(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/groundoverlayoptions-0000001050152689-V5">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/groundoverlayoptions-0000001050152689-V5</a><br/>
     *
     */
    public GroundOverlayOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new com.huawei.hms.maps.model.GroundOverlayOptions());
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getNO_DIMENSION() Flag for when no dimension is specified for the height.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.NO_DIMENSION
     *
     * @return the return object is float
     */
    public static float getNO_DIMENSION() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.maps.model.GroundOverlayOptions.NO_DIMENSION");
        return com.huawei.hms.maps.model.GroundOverlayOptions.NO_DIMENSION;
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.anchor(float,float) Specifies the anchor.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.anchor(float,float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#anchor(float,float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#anchor(float,float)</a><br/>
     *
     * @param param0 u-coordinate of the anchor
     * @param param1 v-coordinate of the anchor
     * @return this GroundOverlayOptions object with a new anchor set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions anchor(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).anchor(param0, param1)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).anchor(param0, param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.bearing(float) Specifies the bearing of the ground overlay in degrees clockwise from north. The rotation is performed about the anchor point. If not specified, the default is 0(i.e., up on the image points north).<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.bearing(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#bearing(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#bearing(float)</a><br/>
     *
     * @param param0 the bearing in degrees clockwise from north. Values outside the range [0, 360) will be normalized
     * @return this GroundOverlayOptions object with a new bearing set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions bearing(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).bearing(param0)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).bearing(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.clickable(boolean) Specifies whether the ground overlay is clickable. The default clickability is false.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.clickable(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#clickable(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#clickable(boolean)</a><br/>
     *
     * @param param0 The new clickability setting
     * @return this GroundOverlayOptions object with a new clickability setting
     */
    public final org.xms.g.maps.model.GroundOverlayOptions clickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).clickable(param0)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).clickable(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getAnchorU() Horizontal relative anchor; 0.0 and 1.0 denote left and right edges respectively. Other anchor values are interpolated accordingly.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getAnchorU(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getAnchorU()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getAnchorU()</a><br/>
     *
     * @return the horizontal edge-relative anchor location
     */
    public final float getAnchorU() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getAnchorU()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getAnchorU();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getAnchorV() Vertical relative anchor; 0.0 and 1.0 denote top and bottom edges respectively. Other anchor values are interpolated accordingly.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getAnchorV(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getAnchorV()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getAnchorV()</a><br/>
     *
     * @return the vertical edge-relative anchor location
     */
    public final float getAnchorV() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getAnchorV()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getAnchorV();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getBearing() Gets the bearing set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getBearing(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getBearing()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getBearing()</a><br/>
     *
     * @return the bearing of the ground overlay
     */
    public final float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getBearing()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getBearing();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getBounds() Gets the bounds set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getBounds(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getBounds()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getBounds()</a><br/>
     *
     * @return the bounds of the ground overlay. This will be null if the position was set using position(LatLng, float) or position(LatLng, float, float)
     */
    public final org.xms.g.maps.model.LatLngBounds getBounds() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getBounds()");
        com.huawei.hms.maps.model.LatLngBounds hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getBounds();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getHeight() Gets the height set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getHeight(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getHeight()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getHeight()</a><br/>
     *
     * @return the height of the ground overlay
     */
    public final float getHeight() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getHeight()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getHeight();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getImage() Gets the image descriptor set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getImage(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getImage()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getImage()</a><br/>
     *
     * @return A BitmapDescriptor representing the image of the ground overlay
     */
    public final org.xms.g.maps.model.BitmapDescriptor getImage() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getImage()");
        com.huawei.hms.maps.model.BitmapDescriptor hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getImage();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getLocation() Gets the location set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getLocation(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getLocation()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getLocation()</a><br/>
     *
     * @return the location to place the anchor of the ground overlay. This will be null if the position was set using positionFromBounds(LatLngBounds)
     */
    public final org.xms.g.maps.model.LatLng getLocation() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getLocation()");
        com.huawei.hms.maps.model.LatLng hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getLocation();
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getTransparency() Gets the transparency set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getTransparency(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getTransparency()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getTransparency()</a><br/>
     *
     * @return the transparency of the ground overlay
     */
    public final float getTransparency() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getTransparency()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getTransparency();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getWidth() Gets the width set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getWidth(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getWidth()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getWidth()</a><br/>
     *
     * @return the width of the ground overlay
     */
    public final float getWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getWidth()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getWidth();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.getZIndex() Gets the zIndex set for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.getZIndex(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getZIndex()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#getZIndex()</a><br/>
     *
     * @return the zIndex of the ground overlay
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getZIndex()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.image(org.xms.g.maps.model.BitmapDescriptor) Specifies the image for this ground overlay.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.image(com.huawei.hms.maps.model.BitmapDescriptor): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#image(BitmapDescriptor)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#image(BitmapDescriptor)</a><br/>
     *
     * @param param0 the BitmapDescriptor to use for this ground overlay
     * @return this GroundOverlayOptions object with a new image set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions image(org.xms.g.maps.model.BitmapDescriptor param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).image(((com.huawei.hms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).image(((com.huawei.hms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.isClickable() Gets the clickability setting for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.isClickable(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#isClickable()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#isClickable()</a><br/>
     *
     * @return true if the ground overlay is clickable; false if it is not
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).isClickable()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.isVisible() Gets the visibility setting for this GroundOverlayOptions object.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.isVisible(): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#isVisible()">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#isVisible()</a><br/>
     *
     * @return true if this ground overlay is visible; false if it is not
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).isVisible()");
        return ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.position(org.xms.g.maps.model.LatLng,float) Specifies the position for this ground overlay using an anchor point(a LatLng)and the width(in meters). The height will be adapted accordingly to preserve aspect ratio.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.position(com.huawei.hms.maps.model.LatLng,float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#position(LatLng,float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#position(LatLng,float)</a><br/>
     *
     * @param param0 the width of the overlay (in meters)
     * @param param1 the location on the map LatLng to which the anchor point in the given image will remain fixed. The anchor will remain fixed to the position on the ground when transformations are applied (e.g., setDimensions, setBearing, etc.)
     * @param param2 the height of the overlay (in meters)
     * @throws java.lang.IllegalArgumentException if anchor is null
     * @throws java.lang.IllegalArgumentException if width is negative
     * @throws java.lang.IllegalStateException if the position was already set using positionFromBounds(LatLngBounds)
     * @return this GroundOverlayOptions object with a new position set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions position(org.xms.g.maps.model.LatLng param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.position(org.xms.g.maps.model.LatLng,float,float) Specifies the position for this ground overlay using an anchor point(a LatLng), width and height(both in meters). When rendered, the image will be scaled to fit the dimensions specified.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.position(com.huawei.hms.maps.model.LatLng,float,float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#position(LatLng,float,float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#position(LatLng,float,float)</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @param param1 the param should instanceof float
     * @param param2 the param should instanceof float
     * @throws java.lang.IllegalArgumentException if anchor is null
     * @throws java.lang.IllegalArgumentException if width is negative
     * @throws java.lang.IllegalStateException if the position was already set using positionFromBounds(LatLngBounds)
     * @return the return object is maps model GroundOverlayOptions
     */
    public final org.xms.g.maps.model.GroundOverlayOptions position(org.xms.g.maps.model.LatLng param0, float param1, float param2) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1, param2)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).position(((com.huawei.hms.maps.model.LatLng) ((param0) == null ? null : (param0.getHInstance()))), param1, param2);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.positionFromBounds(org.xms.g.maps.model.LatLngBounds) Specifies the position for this ground overlay.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.positionFromBounds(com.huawei.hms.maps.model.LatLngBounds): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#positionFromBounds(LatLngBounds)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#positionFromBounds(LatLngBounds)</a><br/>
     *
     * @param param0 a LatLngBounds in which to place the ground overlay
     * @throws java.lang.IllegalStateException if the position was already set using position(LatLng, float) or position(LatLng, float, float)
     * @return this GroundOverlayOptions object with a new position set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions positionFromBounds(org.xms.g.maps.model.LatLngBounds param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).positionFromBounds(((com.huawei.hms.maps.model.LatLngBounds) ((param0) == null ? null : (param0.getHInstance()))))");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).positionFromBounds(((com.huawei.hms.maps.model.LatLngBounds) ((param0) == null ? null : (param0.getHInstance()))));
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.transparency(float) Specifies the transparency of the ground overlay. The default transparency is 0(opaque).<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.transparency(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#transparency(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#transparency(float)</a><br/>
     *
     * @param param0 a float in the range [0..1] where 0 means that the ground overlay is opaque and 1 means that the ground overlay is transparent
     * @throws java.lang.IllegalStateException if the transparency is outside the range[0..1]
     * @return this GroundOverlayOptions object with a new transparency setting
     */
    public final org.xms.g.maps.model.GroundOverlayOptions transparency(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).transparency(param0)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).transparency(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.visible(boolean) Specifies the visibility for the ground overlay. The default visibility is true.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.visible(boolean): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#visible(boolean)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#visible(boolean)</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this GroundOverlayOptions object with a new visibility setting
     */
    public final org.xms.g.maps.model.GroundOverlayOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).visible(param0)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).visible(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.writeToParcel(android.os.Parcel,int) write To Parcel.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.writeToParcel(android.os.Parcel,int)
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).writeToParcel(param0, param1)");
        ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.zIndex(float) Specifies the ground overlay's zIndex, i.e., the order in which it will be drawn. See the documentation at the top of this class for more information about zIndex.<br/>
     * com.huawei.hms.maps.model.GroundOverlayOptions.zIndex(float): <a href="https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#zIndex(float)">https://developer.huawei.com/consumer/en/doc/development/HMS-References/hms-map-groundoverlayo#zIndex(float)</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this GroundOverlayOptions object with a new zIndex set
     */
    public final org.xms.g.maps.model.GroundOverlayOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).zIndex(param0)");
        com.huawei.hms.maps.model.GroundOverlayOptions hReturn = ((com.huawei.hms.maps.model.GroundOverlayOptions) this.getHInstance()).zIndex(param0);
        return ((hReturn) == null ? null : (new org.xms.g.maps.model.GroundOverlayOptions(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.GroundOverlayOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model GroundOverlayOptions object
     */
    public static org.xms.g.maps.model.GroundOverlayOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.GroundOverlayOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlayOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.maps.model.GroundOverlayOptions;
    }
}