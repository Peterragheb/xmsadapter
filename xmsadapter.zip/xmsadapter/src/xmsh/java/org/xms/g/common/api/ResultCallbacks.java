package org.xms.g.common.api;

/**
 * Callbacks for receiving a Result from a PendingResult as an asynchronous callback. Contains separate callbacks for success and failure.<br/>
 * Wrapper class for com.huawei.hms.support.api.client.ResultCallbacks, but only the HMS API are provided.<br/>
 * com.huawei.hms.support.api.client.ResultCallbacks: <br/>
 */
public abstract class ResultCallbacks<XR extends org.xms.g.common.api.Result> extends org.xms.g.utils.XObject implements org.xms.g.common.api.ResultCallback<XR> {
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.api.ResultCallbacks.ResultCallbacks(org.xms.g.utils.XBox) constructor of ResultCallbacks with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ResultCallbacks(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ResultCallbacks.ResultCallbacks() constructor of ResultCallbacks.<br/>
     * com.huawei.hms.support.api.client.ResultCallbacks.ResultCallbacks()
     *
     */
    public ResultCallbacks() {
        super(((org.xms.g.utils.XBox) null));
        this.setHInstance(new HImpl());
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ResultCallbacks.onFailure(org.xms.g.common.api.Status) Called when the Result is ready and a failure occurred.<br/>
     * com.huawei.hms.support.api.client.ResultCallbacks.onFailure(com.huawei.hms.support.api.client.Status)
     *
     * @param param0 Status resulting from the API call. Guaranteed to be non-null and unsuccessful
     */
    public abstract void onFailure(org.xms.g.common.api.Status param0);
    
    /**
     * org.xms.g.common.api.ResultCallbacks.onSuccess(XR) Called when the Result is ready and was successful.<br/>
     * com.huawei.hms.support.api.client.ResultCallbacks.onSuccess(R)
     *
     * @param param0 The result from the API call. Never null
     */
    public abstract void onSuccess(XR param0);
    
    /**
     * org.xms.g.common.api.ResultCallbacks.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ResultCallbacks.<br/>
     *
     * @param param0 the input object
     * @return casted ResultCallbacks object
     */
    public static org.xms.g.common.api.ResultCallbacks dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.common.api.ResultCallbacks) {
            return ((org.xms.g.common.api.ResultCallbacks) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.huawei.hms.support.api.client.ResultCallbacks hReturn = ((com.huawei.hms.support.api.client.ResultCallbacks) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.common.api.ResultCallbacks.XImpl(new org.xms.g.utils.XBox(hReturn));
        }
        return ((org.xms.g.common.api.ResultCallbacks) param0);
    }
    
    /**
     * org.xms.g.common.api.ResultCallbacks.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.support.api.client.ResultCallbacks;
    }
    
    private class HImpl<R extends com.huawei.hms.support.api.client.Result> extends com.huawei.hms.support.api.client.ResultCallbacks<R> {
        
        public void onFailure(com.huawei.hms.support.api.client.Status param0) {
            org.xms.g.common.api.ResultCallbacks.this.onFailure(((param0) == null ? null : (new org.xms.g.common.api.Status(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void onSuccess(R param0) {
            java.lang.Object[] params = new java.lang.Object[1];
            java.lang.Class[] types = new java.lang.Class[1];
            params[0] = param0;
            types[0] = org.xms.g.common.api.Result.class;
            org.xms.g.utils.Utils.invokeMethod(org.xms.g.common.api.ResultCallbacks.this, "onSuccess", params, types, true);
        }
        
        public HImpl() {
            super();
        }
    }
    
    /**
     * Wrapper class of Callbacks for receiving a Result from a PendingResult as an asynchronous callback. Contains separate callbacks for success and failure.<br/>
     * Wrapper class for com.huawei.hms.support.api.client.ResultCallbacks, but only the HMS API are provided.<br/>
     * com.huawei.hms.support.api.client.ResultCallbacks: <br/>
     */
    public static class XImpl<XR extends org.xms.g.common.api.Result> extends org.xms.g.common.api.ResultCallbacks<XR> {
        
        /**
         * org.xms.g.common.api.ResultCallbacks.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.common.api.ResultCallbacks.XImpl.onFailure(org.xms.g.common.api.Status) Called when the Result is ready and a failure occurred.<br/>
         * com.huawei.hms.support.api.client.ResultCallbacks.onFailure(com.huawei.hms.support.api.client.Status)
         *
         * @param param0 Status resulting from the API call. Guaranteed to be non-null and unsuccessful
         */
        public void onFailure(org.xms.g.common.api.Status param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))))");
            ((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onFailure(((com.huawei.hms.support.api.client.Status) ((param0) == null ? null : (param0.getHInstance()))));
        }
        
        /**
         * org.xms.g.common.api.ResultCallbacks.XImpl.onSuccess(XR) Called when the Result is ready and was successful.<br/>
         * com.huawei.hms.support.api.client.ResultCallbacks.onSuccess(R)
         *
         * @param param0 The result from the API call. Never null
         */
        public void onSuccess(XR param0) {
            com.huawei.hms.support.api.client.Result hObj0 = ((com.huawei.hms.support.api.client.Result) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onSuccess(hObj0)");
            ((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onSuccess(hObj0);
        }
        
        /**
         * org.xms.g.common.api.ResultCallbacks.XImpl.onResult(XR) Called when the Result is ready.<br/>
         * com.huawei.hms.support.api.client.ResultCallback.onResult(R): <a href="https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/resultcallback_r-0000001050121136#EN-US_TOPIC_0000001050121136__section32821622269">https://developer.huawei.com/consumer/en/doc/development/HMSCore-References/resultcallback_r-0000001050121136#EN-US_TOPIC_0000001050121136__section32821622269</a><br/>
         *
         * @param param0 The result from the API call. Never null
         */
        public void onResult(XR param0) {
            com.huawei.hms.support.api.client.Result hObj0 = ((com.huawei.hms.support.api.client.Result) org.xms.g.utils.Utils.getInstanceInInterface(param0, true));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onResult(hObj0)");
            ((com.huawei.hms.support.api.client.ResultCallbacks) this.getHInstance()).onResult(hObj0);
        }
    }
}