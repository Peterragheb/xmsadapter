package org.xms.g.tasks;

/**
 * Runtime version of ExecutionException.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public class RuntimeExecutionException extends java.lang.RuntimeException implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.RuntimeExecutionException(org.xms.g.utils.XBox) constructor of RuntimeExecutionException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public RuntimeExecutionException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.RuntimeExecutionException(java.lang.Throwable) constructor of RuntimeExecutionException.<br/>
     *
     * @param param0 the cause
     */
    public RuntimeExecutionException(java.lang.Throwable param0) {
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.setHInstance(java.lang.Object) set the hms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of hms
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return instance of hms
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.RuntimeExecutionException.<br/>
     *
     * @param param0 the input object
     * @return casted RuntimeExecutionException object
     */
    public static org.xms.g.tasks.RuntimeExecutionException dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}