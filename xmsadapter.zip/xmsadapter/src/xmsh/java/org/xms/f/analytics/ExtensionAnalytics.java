package org.xms.f.analytics;




/**
 * The top level Analytics singleton that provides methods for logging events and setting user properties.<br/>
 * Wrapper class for com.huawei.hms.analytics.HiAnalyticsInstance/com.huawei.hms.analytics.HiAnalytics, but only the HMS API are provided.<br/>
 * com.huawei.hms.analytics.HiAnalyticsInstance/com.huawei.hms.analytics.HiAnalytics: Provides public methods to report user behavior data. This class uses the singleton pattern./Obtains an Analytics Kit instance with the given context.<br/>
 */
public final class ExtensionAnalytics extends org.xms.g.utils.XObject {
    
    
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.ExtensionAnalytics(org.xms.g.utils.XBox) constructor of ExtensionAnalytics with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionAnalytics(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.getAppInstanceId() Retrieves the app instance id from the service.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.getAppInstanceId(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section124931637174316">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section124931637174316</a><br/>
     *
     * @return Task with the result of the retrieval
     */
    public org.xms.g.tasks.Task<java.lang.String> getAppInstanceId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).getAAID()");
        com.huawei.hmf.tasks.Task hReturn = ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).getAAID();
        return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.getInstance(android.content.Context) Returns the singleton FirebaseAnalytics interface.<br/>
     * com.huawei.hms.analytics.HiAnalytics.getInstance(android.content.Context): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-0000001050707170-V5#EN-US_TOPIC_0000001050707170__section209812717321">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-0000001050707170-V5#EN-US_TOPIC_0000001050707170__section209812717321</a><br/>
     *
     * @param param0 the context used to initialize Firebase Analytics. Must not be null
     * @return the singleton
     */
    public static org.xms.f.analytics.ExtensionAnalytics getInstance(android.content.Context param0) {
        
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.HiAnalytics.getInstance(param0)");
        com.huawei.hms.analytics.HiAnalyticsInstance hReturn = com.huawei.hms.analytics.HiAnalytics.getInstance(param0);
        return ((hReturn) == null ? null : (new org.xms.f.analytics.ExtensionAnalytics(new org.xms.g.utils.XBox(hReturn))));
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.logEvent(java.lang.String,android.os.Bundle) Logs an app event.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.onEvent(java.lang.String,android.os.Bundle): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section15204518184114">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section15204518184114</a><br/>
     *
     * @param param0 The name of the event. Should contain 1 to 40 alphanumeric characters or underscores
     * @param param1 The map of event parameters. Passing null indicates that the event has no parameters
     */
    public final void logEvent(java.lang.String param0, android.os.Bundle param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).onEvent(param0, param1)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).onEvent(param0, param1);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.resetAnalyticsData() Clears all analytics data for this app from the device and resets the app instance id.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.clearCachedData(): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section7238134312">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section7238134312</a><br/>
     *
     */
    public final void resetAnalyticsData() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).clearCachedData()");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).clearCachedData();
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.setAnalyticsCollectionEnabled(boolean) Sets whether analytics collection is enabled for this app on this device. This setting is persisted across app sessions. By default it is enabled.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.setAnalyticsEnabled(boolean): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section113486277512">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section113486277512</a><br/>
     *
     * @param param0 Whether analytics collection is enabled for this app on this device
     */
    public final void setAnalyticsCollectionEnabled(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setAnalyticsEnabled(param0)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setAnalyticsEnabled(param0);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void setCurrentScreen(android.app.Activity param0, java.lang.String param1, java.lang.String param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.setMinimumSessionDuration(long) Sets the minimum engagement time required before starting a session. The default value is 10000 (10 seconds).<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.setMinActivitySessions(long): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section16504528193313">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section16504528193313</a><br/>
     *
     * @param param0 The minimum engagement time required to start a new session
     */
    public final void setMinimumSessionDuration(long param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setMinActivitySessions(param0)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setMinActivitySessions(param0);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.setSessionTimeoutDuration(long) Sets the duration of inactivity that terminates the current session. The default value is 1800000 (30 minutes).<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.setSessionDuration(long): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section347035614364">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section347035614364</a><br/>
     *
     * @param param0 Session timeout duration in milliseconds
     */
    public final void setSessionTimeoutDuration(long param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setSessionDuration(param0)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setSessionDuration(param0);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.setUserId(java.lang.String) Sets the user ID property.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.setUserId(java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section11961041191220">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section11961041191220</a><br/>
     *
     * @param param0 The user ID to ascribe to the user of this app on this device, which must be non-empty and no more than 256 characters long. Setting the ID to null removes the user ID
     */
    public final void setUserId(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setUserId(param0)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setUserId(param0);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.setUserProperty(java.lang.String,java.lang.String) Sets a user property to a given value.<br/>
     * com.huawei.hms.analytics.HiAnalyticsInstance.setUserProfile(java.lang.String,java.lang.String): <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section096353619188">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-hianalytics-instance-0000001050987219-V5#EN-US_TOPIC_0000001050987219__section096353619188</a><br/>
     *
     * @param param0 The name of the user property to set. Should contain 1 to 24 alphanumeric characters or underscores and must start with an alphabetic character
     * @param param1 The value of the user property. Values can be up to 36 characters long. Setting the value to null removes the user property
     */
    public final void setUserProperty(java.lang.String param0, java.lang.String param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setUserProfile(param0, param1)");
        ((com.huawei.hms.analytics.HiAnalyticsInstance) this.getHInstance()).setUserProfile(param0, param1);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.f.analytics.ExtensionAnalytics.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionAnalytics object
     */
    public static org.xms.f.analytics.ExtensionAnalytics dynamicCast(java.lang.Object param0) {
        return ((org.xms.f.analytics.ExtensionAnalytics) param0);
    }
    
    /**
     * org.xms.f.analytics.ExtensionAnalytics.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.analytics.HiAnalyticsInstance;
    }
    
    /**
     * An Event is an important occurrence in your app that you want to measure.<br/>
     * Wrapper class for com.huawei.hms.analytics.type.HAEventType, but only the HMS API are provided.<br/>
     * com.huawei.hms.analytics.type.HAEventType: Provides the ID constants of all predefined events.<br/>
     */
    public static class Event extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.Event(org.xms.g.utils.XBox) constructor of Event with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public Event(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.Event() constructor of Event.<br/>
         *
         */
        protected Event() {
            super(((org.xms.g.utils.XBox) null));
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getADD_PAYMENT_INFO() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.CREATEPAYMENTINFO: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Add Payment Info event. This event signifies that a user has submitted their payment information
         */
        public static java.lang.String getADD_PAYMENT_INFO() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.CREATEPAYMENTINFO");
            return com.huawei.hms.analytics.type.HAEventType.CREATEPAYMENTINFO;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getADD_TO_CART() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2CART: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Add To Cart event
         */
        public static java.lang.String getADD_TO_CART() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2CART");
            return com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2CART;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getADD_TO_WISHLIST() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2WISHLIST: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Add To Wishlist event
         */
        public static java.lang.String getADD_TO_WISHLIST() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2WISHLIST");
            return com.huawei.hms.analytics.type.HAEventType.ADDPRODUCT2WISHLIST;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getAPP_OPEN() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.STARTAPP: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value App Open event
         */
        public static java.lang.String getAPP_OPEN() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.STARTAPP");
            return com.huawei.hms.analytics.type.HAEventType.STARTAPP;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getBEGIN_CHECKOUT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.STARTCHECKOUT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Begin Checkout event
         */
        public static java.lang.String getBEGIN_CHECKOUT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.STARTCHECKOUT");
            return com.huawei.hms.analytics.type.HAEventType.STARTCHECKOUT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getCAMPAIGN_DETAILS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWCAMPAIGN: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Log this event to supply the referral details of a re-engagement campaign
         */
        public static java.lang.String getCAMPAIGN_DETAILS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWCAMPAIGN");
            return com.huawei.hms.analytics.type.HAEventType.VIEWCAMPAIGN;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getCHECKOUT_PROGRESS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWCHECKOUTSTEP: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value
         */
        public static java.lang.String getCHECKOUT_PROGRESS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWCHECKOUTSTEP");
            return com.huawei.hms.analytics.type.HAEventType.VIEWCHECKOUTSTEP;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getEARN_VIRTUAL_CURRENCY() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.WINVIRTUALCOIN: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Earn Virtual Currency event
         */
        public static java.lang.String getEARN_VIRTUAL_CURRENCY() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.WINVIRTUALCOIN");
            return com.huawei.hms.analytics.type.HAEventType.WINVIRTUALCOIN;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getECOMMERCE_PURCHASE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.COMPLETEPURCHASE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Purchase event
         */
        public static java.lang.String getECOMMERCE_PURCHASE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.COMPLETEPURCHASE");
            return com.huawei.hms.analytics.type.HAEventType.COMPLETEPURCHASE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getGENERATE_LEAD() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.OBTAINLEADS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Generate Lead event
         */
        public static java.lang.String getGENERATE_LEAD() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.OBTAINLEADS");
            return com.huawei.hms.analytics.type.HAEventType.OBTAINLEADS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getJOIN_GROUP() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.JOINUSERGROUP: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Join Group event
         */
        public static java.lang.String getJOIN_GROUP() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.JOINUSERGROUP");
            return com.huawei.hms.analytics.type.HAEventType.JOINUSERGROUP;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getLEVEL_END() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.COMPLETELEVEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Level End event
         */
        public static java.lang.String getLEVEL_END() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.COMPLETELEVEL");
            return com.huawei.hms.analytics.type.HAEventType.COMPLETELEVEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getLEVEL_START() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.STARTLEVEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Level Start event
         */
        public static java.lang.String getLEVEL_START() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.STARTLEVEL");
            return com.huawei.hms.analytics.type.HAEventType.STARTLEVEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getLEVEL_UP() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.UPGRADELEVEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Level Up event
         */
        public static java.lang.String getLEVEL_UP() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.UPGRADELEVEL");
            return com.huawei.hms.analytics.type.HAEventType.UPGRADELEVEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getLOGIN() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.SIGNIN: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Login event
         */
        public static java.lang.String getLOGIN() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.SIGNIN");
            return com.huawei.hms.analytics.type.HAEventType.SIGNIN;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getPOST_SCORE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.SUBMITSCORE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Post Score event
         */
        public static java.lang.String getPOST_SCORE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.SUBMITSCORE");
            return com.huawei.hms.analytics.type.HAEventType.SUBMITSCORE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getPRESENT_OFFER() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.CREATEORDER: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Present Offer event
         */
        public static java.lang.String getPRESENT_OFFER() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.CREATEORDER");
            return com.huawei.hms.analytics.type.HAEventType.CREATEORDER;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getPURCHASE_REFUND() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.REFUNDORDER: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Purchase Refund event
         */
        public static java.lang.String getPURCHASE_REFUND() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.REFUNDORDER");
            return com.huawei.hms.analytics.type.HAEventType.REFUNDORDER;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getREMOVE_FROM_CART() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.DELPRODUCTFROMCART: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.E-Commerce Remove from Cart event
         */
        public static java.lang.String getREMOVE_FROM_CART() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.DELPRODUCTFROMCART");
            return com.huawei.hms.analytics.type.HAEventType.DELPRODUCTFROMCART;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSEARCH() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.SEARCH: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Search event
         */
        public static java.lang.String getSEARCH() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.SEARCH");
            return com.huawei.hms.analytics.type.HAEventType.SEARCH;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSELECT_CONTENT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWCONTENT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Select Content event
         */
        public static java.lang.String getSELECT_CONTENT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWCONTENT");
            return com.huawei.hms.analytics.type.HAEventType.VIEWCONTENT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSET_CHECKOUT_OPTION() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.UPDATECHECKOUTOPTION: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Set checkout option
         */
        public static java.lang.String getSET_CHECKOUT_OPTION() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.UPDATECHECKOUTOPTION");
            return com.huawei.hms.analytics.type.HAEventType.UPDATECHECKOUTOPTION;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSHARE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.SHARECONTENT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Share event
         */
        public static java.lang.String getSHARE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.SHARECONTENT");
            return com.huawei.hms.analytics.type.HAEventType.SHARECONTENT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSIGN_UP() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.REGISTERACCOUNT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Sign Up event
         */
        public static java.lang.String getSIGN_UP() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.REGISTERACCOUNT");
            return com.huawei.hms.analytics.type.HAEventType.REGISTERACCOUNT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSPEND_VIRTUAL_CURRENCY() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.CONSUMEVIRTUALCOIN: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Spend Virtual Currency event
         */
        public static java.lang.String getSPEND_VIRTUAL_CURRENCY() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.CONSUMEVIRTUALCOIN");
            return com.huawei.hms.analytics.type.HAEventType.CONSUMEVIRTUALCOIN;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getTUTORIAL_BEGIN() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.STARTTUTORIAL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Tutorial Begin event
         */
        public static java.lang.String getTUTORIAL_BEGIN() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.STARTTUTORIAL");
            return com.huawei.hms.analytics.type.HAEventType.STARTTUTORIAL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getTUTORIAL_COMPLETE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.COMPLETETUTORIAL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Tutorial End event
         */
        public static java.lang.String getTUTORIAL_COMPLETE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.COMPLETETUTORIAL");
            return com.huawei.hms.analytics.type.HAEventType.COMPLETETUTORIAL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getUNLOCK_ACHIEVEMENT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.OBTAINACHIEVEMENT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.Unlock Achievement event
         */
        public static java.lang.String getUNLOCK_ACHIEVEMENT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.OBTAINACHIEVEMENT");
            return com.huawei.hms.analytics.type.HAEventType.OBTAINACHIEVEMENT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getVIEW_ITEM() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.View Item event
         */
        public static java.lang.String getVIEW_ITEM() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCT");
            return com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getVIEW_ITEM_LIST() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCTLIST: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.View Item List event
         */
        public static java.lang.String getVIEW_ITEM_LIST() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCTLIST");
            return com.huawei.hms.analytics.type.HAEventType.VIEWPRODUCTLIST;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getVIEW_SEARCH_RESULTS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAEventType.VIEWSEARCHRESULT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section471591317439</a><br/>
         *
         * @return Constant Value.View Search Results event
         */
        public static java.lang.String getVIEW_SEARCH_RESULTS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAEventType.VIEWSEARCHRESULT");
            return com.huawei.hms.analytics.type.HAEventType.VIEWSEARCHRESULT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getADD_SHIPPING_INFO() Add Shipping Info event. This event signifies that a user has submitted their shipping information.<br/>
         *
         * @return Constant Value: "add_shipping_info"
         */
        public static java.lang.String getADD_SHIPPING_INFO() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getPURCHASE() E-Commerce Purchase event. This event signifies that an item(s) was purchased by a user.<br/>
         *
         * @return Constant Value: "purchase"
         */
        public static java.lang.String getPURCHASE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getREFUND() E-Commerce Refund event. This event signifies that a refund was issued.<br/>
         *
         * @return Constant Value: "refund"
         */
        public static java.lang.String getREFUND() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSELECT_ITEM() Select Item event. This event signifies that an item was selected by a user from a list.<br/>
         *
         * @return Constant Value: "select_item"
         */
        public static java.lang.String getSELECT_ITEM() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getSELECT_PROMOTION() Select promotion event. This event signifies that a user has selected a promotion offer.<br/>
         *
         * @return Constant Value: "select_promotion"
         */
        public static java.lang.String getSELECT_PROMOTION() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getVIEW_CART() E-commerce View Cart event. This event signifies that a user has viewed their cart.<br/>
         *
         * @return Constant Value: "view_cart"
         */
        public static java.lang.String getVIEW_CART() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.getVIEW_PROMOTION() View Promotion event. This event signifies that a promotion was shown to a user.<br/>
         *
         * @return Constant Value: "view_promotion"
         */
        public static java.lang.String getVIEW_PROMOTION() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.f.analytics.ExtensionAnalytics.Event.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionAnalytics.Event object
         */
        public static org.xms.f.analytics.ExtensionAnalytics.Event dynamicCast(java.lang.Object param0) {
            return ((org.xms.f.analytics.ExtensionAnalytics.Event) param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Event.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.analytics.type.HAEventType;
        }
    }
    
    /**
     * Params supply information that contextualize Events.<br/>
     * Wrapper class for com.huawei.hms.analytics.type.HAParamType, but only the HMS API are provided.<br/>
     * com.huawei.hms.analytics.type.HAParamType: Provides the IDs of all predefined parameters, including the ID constants of predefined parameters and user attributes.<br/>
     */
    public static class Param extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.Param(org.xms.g.utils.XBox) constructor of Param with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public Param(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.Param() constructor of Param.<br/>
         *
         */
        protected Param() {
            super(((org.xms.g.utils.XBox) null));
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getACHIEVEMENT_ID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.ACHIEVEMENTID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Game achievement ID (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getACHIEVEMENT_ID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.ACHIEVEMENTID");
            return com.huawei.hms.analytics.type.HAParamType.ACHIEVEMENTID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getACLID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CLICKID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS click ID
         */
        public static java.lang.String getACLID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CLICKID");
            return com.huawei.hms.analytics.type.HAParamType.CLICKID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getAFFILIATION() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.STORENAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.A product affiliation to designate a supplying company or brick and mortar store location (String). The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getAFFILIATION() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.STORENAME");
            return com.huawei.hms.analytics.type.HAParamType.STORENAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCAMPAIGN() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PROMOTIONNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS name; used for keyword analysis to identify a specific product promotion or strategic campaign
         */
        public static java.lang.String getCAMPAIGN() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PROMOTIONNAME");
            return com.huawei.hms.analytics.type.HAParamType.PROMOTIONNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCHARACTER() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.ROLENAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Character used in game (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCHARACTER() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.ROLENAME");
            return com.huawei.hms.analytics.type.HAParamType.ROLENAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCHECKOUT_OPTION() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.OPTION: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Some option on a step in an ecommerce flow
         */
        public static java.lang.String getCHECKOUT_OPTION() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.OPTION");
            return com.huawei.hms.analytics.type.HAParamType.OPTION;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCHECKOUT_STEP() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.STEP: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The checkout step (1..N)
         */
        public static java.lang.String getCHECKOUT_STEP() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.STEP");
            return com.huawei.hms.analytics.type.HAParamType.STEP;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCONTENT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CONTENT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS content; used for A/B testing and content-targeted ads to differentiate ads or links that point to the same URL
         */
        public static java.lang.String getCONTENT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CONTENT");
            return com.huawei.hms.analytics.type.HAParamType.CONTENT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCONTENT_TYPE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CONTENTTYPE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Type of content selected (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCONTENT_TYPE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CONTENTTYPE");
            return com.huawei.hms.analytics.type.HAParamType.CONTENTTYPE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCOUPON() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.VOUCHER: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Coupon code used for a purchase (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCOUPON() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.VOUCHER");
            return com.huawei.hms.analytics.type.HAParamType.VOUCHER;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCP1() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.EXTENDPARAM: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS custom parameter
         */
        public static java.lang.String getCP1() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.EXTENDPARAM");
            return com.huawei.hms.analytics.type.HAParamType.EXTENDPARAM;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCREATIVE_NAME() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.MATERIALNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The name of a creative used in a promotional spot (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCREATIVE_NAME() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.MATERIALNAME");
            return com.huawei.hms.analytics.type.HAParamType.MATERIALNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCREATIVE_SLOT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.MATERIALSLOT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The name of a creative slot (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCREATIVE_SLOT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.MATERIALSLOT");
            return com.huawei.hms.analytics.type.HAParamType.MATERIALSLOT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getCURRENCY() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CURRNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Currency of the purchase or items associated with the event, in 3-letter ISO_4217 format (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getCURRENCY() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CURRNAME");
            return com.huawei.hms.analytics.type.HAParamType.CURRNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getDESTINATION() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.DESTINATION: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Flight or Travel destination (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getDESTINATION() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.DESTINATION");
            return com.huawei.hms.analytics.type.HAParamType.DESTINATION;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getEND_DATE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.ENDDATE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The arrival date, check-out date, or rental end date for the item (String).The parameter expects a date formatted as YYYY-MM-DD and set with putString(String, String)
         */
        public static java.lang.String getEND_DATE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.ENDDATE");
            return com.huawei.hms.analytics.type.HAParamType.ENDDATE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getEXTEND_SESSION() return the constant value.<br/>
         *
         * @return Constant Value.Indicates that the associated event should either extend the current session or start a new session if no session was active when the event was logged. Specify 1 to extend the current session or to start a new session; any other long value will not extend or start a session
         */
        public static java.lang.String getEXTEND_SESSION() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getFLIGHT_NUMBER() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.FLIGHTNO: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Flight number for travel events (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getFLIGHT_NUMBER() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.FLIGHTNO");
            return com.huawei.hms.analytics.type.HAParamType.FLIGHTNO;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getGROUP_ID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.USERGROUPID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Group/clan/guild id (String).The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getGROUP_ID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.USERGROUPID");
            return com.huawei.hms.analytics.type.HAParamType.USERGROUPID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getINDEX() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.POSITIONID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The index of the item in a list.The parameter expects a long value set with putLong(String, long)
         */
        public static java.lang.String getINDEX() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.POSITIONID");
            return com.huawei.hms.analytics.type.HAParamType.POSITIONID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_BRAND() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.BRAND: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Item brand. The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_BRAND() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.BRAND");
            return com.huawei.hms.analytics.type.HAParamType.BRAND;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_CATEGORY() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CATEGORY: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Item category (context-specific) (String). The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_CATEGORY() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CATEGORY");
            return com.huawei.hms.analytics.type.HAParamType.CATEGORY;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_ID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PRODUCTID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Item ID (context-specific) (String). The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_ID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PRODUCTID");
            return com.huawei.hms.analytics.type.HAParamType.PRODUCTID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_LIST() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PRODUCTLIST: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The list in which the item was presented to the user
         */
        public static java.lang.String getITEM_LIST() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PRODUCTLIST");
            return com.huawei.hms.analytics.type.HAParamType.PRODUCTLIST;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_LOCATION_ID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PLACEID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The Google Place ID that corresponds to the associated item (String). Alternatively, you can supply your own custom Location ID. The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_LOCATION_ID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PLACEID");
            return com.huawei.hms.analytics.type.HAParamType.PLACEID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_NAME() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PRODUCTNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Item Name (context-specific) (String). The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_NAME() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PRODUCTNAME");
            return com.huawei.hms.analytics.type.HAParamType.PRODUCTNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_VARIANT() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PRODUCTFEATURE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Item variant. The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getITEM_VARIANT() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PRODUCTFEATURE");
            return com.huawei.hms.analytics.type.HAParamType.PRODUCTFEATURE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getLEVEL() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.LEVELID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Level in game (long). The parameter expects a long value set with putLong(String, long)
         */
        public static java.lang.String getLEVEL() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.LEVELID");
            return com.huawei.hms.analytics.type.HAParamType.LEVELID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getLEVEL_NAME() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.LEVELNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The name of a level in a game (String). The parameter expects a String value set with putString(String, String)
         */
        public static java.lang.String getLEVEL_NAME() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.LEVELNAME");
            return com.huawei.hms.analytics.type.HAParamType.LEVELNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getLOCATION() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.MEDIUM: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Location (String). The Google Place ID that corresponds to the associated event. Alternatively, you can supply your own custom Location ID. The parameter expects a string value set with putString(String, String).public static java.lang.String getLOCATION() { if (org.xms.g.utils.GlobalEnvSetting.isHms()) { org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PLACEID"); return com.huawei.hms.analytics.type.HAParamType.PLACEID; } else { org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.firebase.analytics.FirebaseAnalytics.Param.LOCATION"); return com.google.firebase.analytics.FirebaseAnalytics.Param.LOCATION; } } / org.xms.f.analytics.ExtensionAnalytics.Param.getMEDIUM() return the constant value.<br/> Support running environments including both HMS and GMS which are chosen by users.<br/> Below are the references of HMS apis and GMS apis respectively:<br/> com.huawei.hms.analytics.type.HAParamType.MEDIUM : <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/> com.google.firebase.analytics.FirebaseAnalytics.Param.MEDIUM : <a href="https://developers.google.com/android/reference/com/google/firebase/analytics/FirebaseAnalytics.Param#public-static-final-string-medium">https://developers.google.com/android/reference/com/google/firebase/analytics/FirebaseAnalytics.Param#public-static-final-string-medium</a><br/>
         */
        public static java.lang.String getLOCATION() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PLACEID");
            return com.huawei.hms.analytics.type.HAParamType.PLACEID;
        }
        
        public static java.lang.String getMEDIUM() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.MEDIUM");
            return com.huawei.hms.analytics.type.HAParamType.MEDIUM;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getMETHOD() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CHANNEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.A particular approach used in an operation; for example, "facebook" or "email" in the context of a sign_up or login event. The parameter expects a string value set with putString(String, String)
         */
        public static java.lang.String getMETHOD() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CHANNEL");
            return com.huawei.hms.analytics.type.HAParamType.CHANNEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getNUMBER_OF_NIGHTS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.BOOKINGDAYS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Number of nights staying at hotel (long)
         */
        public static java.lang.String getNUMBER_OF_NIGHTS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.BOOKINGDAYS");
            return com.huawei.hms.analytics.type.HAParamType.BOOKINGDAYS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getNUMBER_OF_PASSENGERS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PASSENGERSNUMBER: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Number of passengers traveling (long)
         */
        public static java.lang.String getNUMBER_OF_PASSENGERS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PASSENGERSNUMBER");
            return com.huawei.hms.analytics.type.HAParamType.PASSENGERSNUMBER;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getNUMBER_OF_ROOMS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.BOOKINGROOMS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Number of rooms for travel events (long)
         */
        public static java.lang.String getNUMBER_OF_ROOMS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.BOOKINGROOMS");
            return com.huawei.hms.analytics.type.HAParamType.BOOKINGROOMS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getORIGIN() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.ORIGINATINGPLACE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Flight or Travel origin (String)
         */
        public static java.lang.String getORIGIN() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.ORIGINATINGPLACE");
            return com.huawei.hms.analytics.type.HAParamType.ORIGINATINGPLACE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getPRICE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.PRICE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Purchase price (double). Expecting a double value set with putDouble(String, double)
         */
        public static java.lang.String getPRICE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.PRICE");
            return com.huawei.hms.analytics.type.HAParamType.PRICE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getQUANTITY() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.QUANTITY: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Purchase quantity (long)
         */
        public static java.lang.String getQUANTITY() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.QUANTITY");
            return com.huawei.hms.analytics.type.HAParamType.QUANTITY;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSCORE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.SCORE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Score in game (long)
         */
        public static java.lang.String getSCORE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.SCORE");
            return com.huawei.hms.analytics.type.HAParamType.SCORE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSEARCH_TERM() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.KEYWORDS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The search string/keywords used (String)
         */
        public static java.lang.String getSEARCH_TERM() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.KEYWORDS");
            return com.huawei.hms.analytics.type.HAParamType.KEYWORDS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSHIPPING() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.SHIPPING: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Shipping cost associated with a transaction (double). Expecting a double value set with putDouble(String, double)
         */
        public static java.lang.String getSHIPPING() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.SHIPPING");
            return com.huawei.hms.analytics.type.HAParamType.SHIPPING;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSIGN_UP_METHOD() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CHANNEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Signup method (String)
         */
        public static java.lang.String getSIGN_UP_METHOD() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CHANNEL");
            return com.huawei.hms.analytics.type.HAParamType.CHANNEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSOURCE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.SOURCE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS source; used to identify a search engine, newsletter, or other source
         */
        public static java.lang.String getSOURCE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.SOURCE");
            return com.huawei.hms.analytics.type.HAParamType.SOURCE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSTART_DATE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.BEGINDATE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The departure date, check-in date, or rental start date for the item (String)
         */
        public static java.lang.String getSTART_DATE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.BEGINDATE");
            return com.huawei.hms.analytics.type.HAParamType.BEGINDATE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSUCCESS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.RESULT: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The result of an operation (long). Specify 1 to indicate success and 0 to indicate failure
         */
        public static java.lang.String getSUCCESS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.RESULT");
            return com.huawei.hms.analytics.type.HAParamType.RESULT;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getTAX() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.TAXFEE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Tax cost associated with a transaction (double). Expecting a double value set with putDouble(String, double)
         */
        public static java.lang.String getTAX() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.TAXFEE");
            return com.huawei.hms.analytics.type.HAParamType.TAXFEE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getTERM() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.KEYWORDS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.CAMPAIGN_DETAILS term; used with paid search to supply the keywords for ads
         */
        public static java.lang.String getTERM() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.KEYWORDS");
            return com.huawei.hms.analytics.type.HAParamType.KEYWORDS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getTRANSACTION_ID() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.TRANSACTIONID: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The unique identifier of a transaction (String)
         */
        public static java.lang.String getTRANSACTION_ID() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.TRANSACTIONID");
            return com.huawei.hms.analytics.type.HAParamType.TRANSACTIONID;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getTRAVEL_CLASS() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CLASS: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Travel class (String)
         */
        public static java.lang.String getTRAVEL_CLASS() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CLASS");
            return com.huawei.hms.analytics.type.HAParamType.CLASS;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getVALUE() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.REVENUE: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.A context-specific numeric value which is accumulated automatically for each event type
         */
        public static java.lang.String getVALUE() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.REVENUE");
            return com.huawei.hms.analytics.type.HAParamType.REVENUE;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getVIRTUAL_CURRENCY_NAME() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.VIRTUALCURRNAME: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.Name of virtual currency type (String)
         */
        public static java.lang.String getVIRTUAL_CURRENCY_NAME() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.VIRTUALCURRNAME");
            return com.huawei.hms.analytics.type.HAParamType.VIRTUALCURRNAME;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getDISCOUNT() Monetary value of discount associated with a purchase(double).<br/>
         *
         * @return Constant Value: "discount"
         */
        public static java.lang.String getDISCOUNT() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_CATEGORY2() Item category (context-specific) (String).<br/>
         *
         * @return Constant Value: "item_category2"
         */
        public static java.lang.String getITEM_CATEGORY2() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_CATEGORY3() Item category (context-specific) (String).<br/>
         *
         * @return Constant Value: "item_category3"
         */
        public static java.lang.String getITEM_CATEGORY3() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_CATEGORY4() Item category (context-specific) (String).<br/>
         *
         * @return Constant Value: "item_category4"
         */
        public static java.lang.String getITEM_CATEGORY4() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_CATEGORY5() Item category (context-specific) (String).<br/>
         *
         * @return Constant Value: "item_category5"
         */
        public static java.lang.String getITEM_CATEGORY5() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_LIST_ID() The ID of the list in which the item was presented to the user (String).<br/>
         *
         * @return Constant Value: "item_list_id"
         */
        public static java.lang.String getITEM_LIST_ID() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEM_LIST_NAME() The name of the list in which the item was presented to the user (String).<br/>
         *
         * @return Constant Value: "item_list_name"
         */
        public static java.lang.String getITEM_LIST_NAME() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getITEMS() The list of items involved in the transaction.<br/>
         *
         * @return Constant Value: "items"
         */
        public static java.lang.String getITEMS() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getLOCATION_ID() The location associated with the event.<br/>
         *
         * @return Constant Value: "location_id"
         */
        public static java.lang.String getLOCATION_ID() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getPAYMENT_TYPE() The chosen method of payment (String).<br/>
         *
         * @return Constant Value: "payment_type"
         */
        public static java.lang.String getPAYMENT_TYPE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getPROMOTION_ID() The ID of a product promotion (String).<br/>
         *
         * @return Constant Value: "promotion_id"
         */
        public static java.lang.String getPROMOTION_ID() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getPROMOTION_NAME() The name of a product promotion (String).<br/>
         *
         * @return Constant Value: "promotion_name"
         */
        public static java.lang.String getPROMOTION_NAME() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.getSHIPPING_TIER() The shipping tier (e.g. Ground, Air, Next-day) selected for delivery of the purchased item (String).<br/>
         *
         * @return Constant Value: "shipping_tier"
         */
        public static java.lang.String getSHIPPING_TIER() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.f.analytics.ExtensionAnalytics.Param.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionAnalytics.Param object
         */
        public static org.xms.f.analytics.ExtensionAnalytics.Param dynamicCast(java.lang.Object param0) {
            return ((org.xms.f.analytics.ExtensionAnalytics.Param) param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.Param.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.analytics.type.HAParamType;
        }
    }
    
    /**
     * A UserProperty is an attribute that describes the app-user.<br/>
     * Wrapper class for com.huawei.hms.analytics.type.HAParamType, but only the HMS API are provided.<br/>
     * com.huawei.hms.analytics.type.HAParamType: Provides the IDs of all predefined parameters, including the ID constants of predefined parameters and user attributes.<br/>
     */
    public static class UserProperty extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.UserProperty(org.xms.g.utils.XBox) constructor of UserProperty with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public UserProperty(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.UserProperty() constructor of UserProperty.<br/>
         *
         */
        protected UserProperty() {
            super(((org.xms.g.utils.XBox) null));
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.getALLOW_AD_PERSONALIZATION_SIGNALS() return the constant value.<br/>
         *
         * @return Constant Value.Indicates whether events logged by Google Analytics can be used to personalize ads for the user
         */
        public static java.lang.String getALLOW_AD_PERSONALIZATION_SIGNALS() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.getSIGN_UP_METHOD() return the constant value.<br/>
         * com.huawei.hms.analytics.type.HAParamType.CHANNEL: <a href="https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455">https://developer.huawei.com/consumer/en/doc/HMSCore-References-V5/android-api-constant-values-0000001050987221-V5#EN-US_TOPIC_0000001050987221__section111591243455</a><br/>
         *
         * @return Constant Value.The method used to sign in. For example, "google", "facebook" or "twitter"
         */
        public static java.lang.String getSIGN_UP_METHOD() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.analytics.type.HAParamType.CHANNEL");
            return com.huawei.hms.analytics.type.HAParamType.CHANNEL;
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.f.analytics.ExtensionAnalytics.UserProperty.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionAnalytics.UserProperty object
         */
        public static org.xms.f.analytics.ExtensionAnalytics.UserProperty dynamicCast(java.lang.Object param0) {
            return ((org.xms.f.analytics.ExtensionAnalytics.UserProperty) param0);
        }
        
        /**
         * org.xms.f.analytics.ExtensionAnalytics.UserProperty.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.analytics.type.HAParamType;
        }
    }
}