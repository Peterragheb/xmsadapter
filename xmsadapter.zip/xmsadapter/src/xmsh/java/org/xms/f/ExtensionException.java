package org.xms.f;

/**
 * Base class for all Firebase exceptions.<br/>
 * Wrapper class for , but only the HMS API are provided.<br/>
 * : <br/>
 */
public class ExtensionException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object hInstance;
    
    /**
     * org.xms.f.ExtensionException.ExtensionException(org.xms.g.utils.XBox) constructor of org.xms.f.ExtensionException.ExtensionException with org.xms.g.utils.XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setHInstance(param0.getHInstance());
    }
    
    /**
     * org.xms.f.ExtensionException.ExtensionException(java.lang.String) Construct a ExtensionException from code.<br/>
     *
     * @param param0 This is detail message
     */
    public ExtensionException(java.lang.String param0) {
    }
    
    /**
     * org.xms.f.ExtensionException.ExtensionException(java.lang.String,java.lang.Throwable) Construct a ExtensionException from code.<br/>
     *
     * @param param0 This is detail message
     * @param param1 This is Throwable
     */
    public ExtensionException(java.lang.String param0, java.lang.Throwable param1) {
    }
    
    /**
     * org.xms.f.ExtensionException.ExtensionException() Construct a ExtensionException from code.<br/>
     *
     */
    public ExtensionException() {
    }
    
    /**
     * org.xms.f.ExtensionException.setHInstance(java.lang.Object) set the hms instance from the corresponding xms instance.<br/>
     *
     * @param param0 hms instance
     */
    public void setHInstance(java.lang.Object param0) {
        this.hInstance = param0;
    }
    
    /**
     * org.xms.f.ExtensionException.getHInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return this is hInstance
     */
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    /**
     * org.xms.f.ExtensionException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.f.ExtensionException.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionException object
     */
    public static org.xms.f.ExtensionException dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.f.ExtensionException.isInstance(java.lang.Object) judge whether the java.lang.Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}