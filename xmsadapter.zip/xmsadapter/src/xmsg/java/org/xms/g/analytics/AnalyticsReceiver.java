package org.xms.g.analytics;

/**
 * A BroadcastReceiver used by Analytics.<br/>
 * Wrapper class for com.google.android.gms.analytics.AnalyticsReceiver, but only the GMS API are provided.<br/>
 * com.google.android.gms.analytics.AnalyticsReceiver: A BroadcastReceiver used by Google Analytics. It will only be used when the receiver is correctly declared in AndroidManifest.xml and enabled.<br/>
 */
public class AnalyticsReceiver extends android.content.BroadcastReceiver implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.AnalyticsReceiver(org.xms.g.utils.XBox) constructor of AnalyticsReceiver with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AnalyticsReceiver(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.AnalyticsReceiver() constructor of AnalyticsReceiver.<br/>
     * com.google.android.gms.analytics.AnalyticsReceiver.AnalyticsReceiver(): <a href="https://developers.google.com/android/reference/com/google/android/gms/analytics/AnalyticsReceiver#public-analyticsreceiver">https://developers.google.com/android/reference/com/google/android/gms/analytics/AnalyticsReceiver#public-analyticsreceiver</a><br/>
     *
     */
    public AnalyticsReceiver() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onReceive(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.analytics.AnalyticsReceiver.<br/>
     *
     * @param param0 the input object
     * @return casted AnalyticsReceiver object
     */
    public static org.xms.g.analytics.AnalyticsReceiver dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.AnalyticsReceiver.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}