package org.xms.g.measurement;

/**
 * An Service used by Analytics.<br/>
 * Wrapper class for com.google.android.gms.measurement.AppMeasurementService, but only the GMS API are provided.<br/>
 * com.google.android.gms.measurement.AppMeasurementService: An Service used by FirebaseAnalytics. It will only be used when the service is correctly declared in AndroidManifest.xml.<br/>
 */
public final class AppMeasurementService extends android.app.Service implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.measurement.AppMeasurementService.AppMeasurementService(org.xms.g.utils.XBox) constructor of AppMeasurementService with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AppMeasurementService(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.AppMeasurementService() constructor of AppMeasurementService.<br/>
     * com.google.android.gms.measurement.AppMeasurementService.AppMeasurementService(): <a href="https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementService#public-appmeasurementservice">https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementService#public-appmeasurementservice</a><br/>
     *
     */
    public AppMeasurementService() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final android.os.IBinder onBind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onCreate() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onDestroy() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onRebind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final int onStartCommand(android.content.Intent param0, int param1, int param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final boolean onUnbind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.measurement.AppMeasurementService.<br/>
     *
     * @param param0 the input object
     * @return casted AppMeasurementService object
     */
    public static org.xms.g.measurement.AppMeasurementService dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementService.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}