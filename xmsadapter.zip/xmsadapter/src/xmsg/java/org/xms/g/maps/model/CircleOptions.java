package org.xms.g.maps.model;

/**
 * xms Defines options for a Circle.<br/>
 * Wrapper class for com.google.android.gms.maps.model.CircleOptions, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.CircleOptions: Defines options for a Circle.<br/>
 */
public final class CircleOptions extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.CircleOptions.CircleOptions(org.xms.g.utils.XBox) Defines options for a Circle.<br/>
     * com.google.android.gms.maps.model.CircleOptions.CircleOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#CircleOptions()">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#CircleOptions()</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public CircleOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.CircleOptions() Defines options for a Circle.<br/>
     * com.google.android.gms.maps.model.CircleOptions.CircleOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#CircleOptions()">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#CircleOptions()</a><br/>
     *
     */
    public CircleOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.CircleOptions());
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.center(org.xms.g.maps.model.LatLng) Sets the center using a LatLng.<br/>
     * com.google.android.gms.maps.model.CircleOptions.center(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-center-latlng-center">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-center-latlng-center</a><br/>
     *
     * @param param0 The geographic center as a LatLng
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions center(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).center(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).center(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.clickable(boolean) Specifies whether this circle is clickable. The default setting is false.<br/>
     * com.google.android.gms.maps.model.CircleOptions.clickable(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-clickable-boolean-clickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-clickable-boolean-clickable</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this CircleOptions object with a new clickability setting
     */
    public final org.xms.g.maps.model.CircleOptions clickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).clickable(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).clickable(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.fillColor(int) Sets the fill color.<br/>
     * com.google.android.gms.maps.model.CircleOptions.fillColor(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-fillcolor-int-color">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-fillcolor-int-color</a><br/>
     *
     * @param param0 color in the Color format
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions fillColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).fillColor(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).fillColor(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getCenter() Returns the center as a LatLng.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getCenter(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-latlng-getcenter">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-latlng-getcenter</a><br/>
     *
     * @return The geographic center as a LatLng
     */
    public final org.xms.g.maps.model.LatLng getCenter() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getCenter()");
        com.google.android.gms.maps.model.LatLng gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getCenter();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getFillColor() Returns the fill color.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getFillColor(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-int-getfillcolor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-int-getfillcolor</a><br/>
     *
     * @return The color in the Color format
     */
    public final int getFillColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getFillColor()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getFillColor();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getRadius() Returns the circle's radius, in meters.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getRadius(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-double-getradius">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-double-getradius</a><br/>
     *
     * @return The radius in meters
     */
    public final double getRadius() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getRadius()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getRadius();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokeColor() Returns the stroke color.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getStrokeColor(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-int-getstrokecolor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-int-getstrokecolor</a><br/>
     *
     * @return The color in the Color format
     */
    public final int getStrokeColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokeColor()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokeColor();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokePattern() Returns the stroke pattern set in this CircleOptions object for the circle's outline.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getStrokePattern(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-listpatternitem-getstrokepattern">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-listpatternitem-getstrokepattern</a><br/>
     *
     * @return the stroke pattern of the circle's outline
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getStrokePattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokePattern()");
        java.util.List gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokePattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.google.android.gms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getStrokeWidth() Returns the stroke width.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getStrokeWidth(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-float-getstrokewidth">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-float-getstrokewidth</a><br/>
     *
     * @return The width in screen pixels
     */
    public final float getStrokeWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokeWidth()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getStrokeWidth();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.getZIndex() Returns the zIndex.<br/>
     * com.google.android.gms.maps.model.CircleOptions.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-float-getzindex</a><br/>
     *
     * @return The zIndex value
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isClickable() Gets the clickability setting for the circle.<br/>
     * com.google.android.gms.maps.model.CircleOptions.isClickable(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-boolean-isclickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-boolean-isclickable</a><br/>
     *
     * @return true if the circle is clickable; false if it is not
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).isClickable()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isVisible() Checks whether the circle is visible.<br/>
     * com.google.android.gms.maps.model.CircleOptions.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-boolean-isvisible</a><br/>
     *
     * @return true if the circle is visible; false if it is invisible
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.radius(double) Sets the radius in meters.<br/>
     * com.google.android.gms.maps.model.CircleOptions.radius(double): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-radius-double-radius">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-radius-double-radius</a><br/>
     *
     * @param param0 radius in meters
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions radius(double param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).radius(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).radius(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokeColor(int) Sets the stroke color.<br/>
     * com.google.android.gms.maps.model.CircleOptions.strokeColor(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokecolor-int-color">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokecolor-int-color</a><br/>
     *
     * @param param0 color in the Color format
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions strokeColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokeColor(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokeColor(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokePattern(java.util.List) Sets a stroke pattern for the circle's outline. The default stroke pattern is solid, represented by null.<br/>
     * com.google.android.gms.maps.model.CircleOptions.strokePattern(java.util.List): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokepattern-listpatternitem-pattern">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokepattern-listpatternitem-pattern</a><br/>
     *
     * @param param0 the param should instanceof java util List
     * @return the return object is maps model CircleOptions
     */
    public final org.xms.g.maps.model.CircleOptions strokePattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, false))");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, false));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.strokeWidth(float) Sets the stroke width.<br/>
     * com.google.android.gms.maps.model.CircleOptions.strokeWidth(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokewidth-float-width">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-strokewidth-float-width</a><br/>
     *
     * @param param0 width in screen pixels
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions strokeWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokeWidth(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).strokeWidth(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.visible(boolean) Sets the visibility.<br/>
     * com.google.android.gms.maps.model.CircleOptions.visible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-visible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-visible-boolean-visible</a><br/>
     *
     * @param param0 false to make this circle invisible
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).visible(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).visible(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.zIndex(float) Sets the zIndex.<br/>
     * com.google.android.gms.maps.model.CircleOptions.zIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-zindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/CircleOptions#public-circleoptions-zindex-float-zindex</a><br/>
     *
     * @param param0 zIndex value
     * @return this CircleOptions object
     */
    public final org.xms.g.maps.model.CircleOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).zIndex(param0)");
        com.google.android.gms.maps.model.CircleOptions gReturn = ((com.google.android.gms.maps.model.CircleOptions) this.getGInstance()).zIndex(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.CircleOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.CircleOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model CircleOptions object
     */
    public static org.xms.g.maps.model.CircleOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.CircleOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.CircleOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.CircleOptions;
    }
}