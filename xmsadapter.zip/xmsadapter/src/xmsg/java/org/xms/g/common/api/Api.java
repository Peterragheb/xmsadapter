package org.xms.g.common.api;

/**
 * public final class Api extends Object and Describes a section of GMS API or HMS API that should be made available.<br/>
 * Wrapper class for com.google.android.gms.common.api.Api, but only the GMS API are provided.<br/>
 * com.google.android.gms.common.api.Api: public final class Api extends Object and Describes a section of the Google Play Services API that should be made available.<br/>
 */
public final class Api<XO extends org.xms.g.common.api.Api.ApiOptions> extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.common.api.Api.Api(org.xms.g.utils.XBox) constructor of Api with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public Api(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.common.api.Api.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.<br/>
     *
     * @param param0 the input object
     * @return casted Api object
     */
    public static org.xms.g.common.api.Api dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.Api) param0);
    }
    
    /**
     * org.xms.g.common.api.Api.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api;
    }
    
    /**
     * Base interface for API options.<br/>
     * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions, but only the GMS API are provided.<br/>
     * com.google.android.gms.common.api.Api.ApiOptions: Base interface for API options.<br/>
     */
    public static interface ApiOptions extends org.xms.g.utils.XInterface {
        
        default java.lang.Object getZInstanceApiOptions() {
            return getGInstanceApiOptions();
        }
        
        default com.google.android.gms.common.api.Api.ApiOptions getGInstanceApiOptions() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.common.api.Api.ApiOptions) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.common.api.Api.ApiOptions() {
            };
        }
        
        /**
         * org.xms.g.common.api.Api.ApiOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.ApiOptions.<br/>
         *
         * @param param0 the input object
         * @return casted Api.ApiOptions object
         */
        public static org.xms.g.common.api.Api.ApiOptions dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.common.api.Api.ApiOptions) param0);
        }
        
        /**
         * org.xms.g.common.api.Api.ApiOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api.ApiOptions;
            }
            return param0 instanceof org.xms.g.common.api.Api.ApiOptions;
        }
        
        /**
         * Wrapper class of ApiOptions which extends Object and Describes a section of GMS API or HMS API that should be made available.<br/>
         * Wrapper class for com.google.android.gms.common.api.Api, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.Api: public final class Api extends Object and Describes a section of the Google Play Services API that should be made available.<br/>
         */
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions {
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
             *
             * @param param0 the wrapper of xms instance
             */
            public XImpl(org.xms.g.utils.XBox param0) {
                super(param0);
            }
        }
        
        /**
         * Base interface for Api.ApiOptions in Apis that have options.<br/>
         * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.HasOptions, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.Api.ApiOptions.HasOptions: Base interface for Api.ApiOptions in Apis that have options.<br/>
         */
        public static interface HasOptions extends org.xms.g.utils.XInterface, org.xms.g.common.api.Api.ApiOptions {
            
            default java.lang.Object getZInstanceHasOptions() {
                return getGInstanceHasOptions();
            }
            
            default com.google.android.gms.common.api.Api.ApiOptions.HasOptions getGInstanceHasOptions() {
                if (this instanceof org.xms.g.utils.XGettable) {
                    return ((com.google.android.gms.common.api.Api.ApiOptions.HasOptions) ((org.xms.g.utils.XGettable) this).getGInstance());
                }
                return new com.google.android.gms.common.api.Api.ApiOptions.HasOptions() {
                };
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.HasOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.ApiOptions.HasOptions.<br/>
             *
             * @param param0 the input object
             * @return casted Api.ApiOptions.HasOptions object
             */
            public static org.xms.g.common.api.Api.ApiOptions.HasOptions dynamicCast(java.lang.Object param0) {
                if (param0 instanceof org.xms.g.common.api.Api.ApiOptions.HasOptions) {
                    return ((org.xms.g.common.api.Api.ApiOptions.HasOptions) param0);
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    com.google.android.gms.common.api.Api.ApiOptions.HasOptions gReturn = ((com.google.android.gms.common.api.Api.ApiOptions.HasOptions) ((org.xms.g.utils.XGettable) param0).getGInstance());
                    return new org.xms.g.common.api.Api.ApiOptions.HasOptions.XImpl(new org.xms.g.utils.XBox(gReturn));
                }
                return ((org.xms.g.common.api.Api.ApiOptions.HasOptions) param0);
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.HasOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
             *
             * @param param0 the input object
             * @return true if the Object is XMS instance, otherwise false
             */
            public static boolean isInstance(java.lang.Object param0) {
                if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                    return false;
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api.ApiOptions.HasOptions;
                }
                return param0 instanceof org.xms.g.common.api.Api.ApiOptions.HasOptions;
            }
            
            /**
             * Wrapper class of ApiOptions.HasOptions which is base interface for Api.ApiOptions in Apis that have options.<br/>
             * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.HasOptions, but only the GMS API are provided.<br/>
             * com.google.android.gms.common.api.Api.ApiOptions.HasOptions: Base interface for Api.ApiOptions in Apis that have options.<br/>
             */
            public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.HasOptions {
                
                /**
                 * org.xms.g.common.api.Api.ApiOptions.HasOptions.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
                 *
                 * @param param0 the wrapper of xms instance
                 */
                public XImpl(org.xms.g.utils.XBox param0) {
                    super(param0);
                }
            }
        }
        
        /**
         * Api.ApiOptions implementation for Apis that do not take any options.<br/>
         * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.NoOptions, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.Api.ApiOptions.NoOptions: Api.ApiOptions implementation for Apis that do not take any options.<br/>
         */
        public static final class NoOptions extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions {
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.NoOptions.NoOptions(org.xms.g.utils.XBox) constructor of NoOptions with XBox.<br/>
             *
             * @param param0 the wrapper of xms instance
             */
            public NoOptions(org.xms.g.utils.XBox param0) {
                super(param0);
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.NoOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.ApiOptions.NoOptions.<br/>
             *
             * @param param0 the input object
             * @return casted Api.ApiOptions.NoOptions object
             */
            public static org.xms.g.common.api.Api.ApiOptions.NoOptions dynamicCast(java.lang.Object param0) {
                if (param0 instanceof org.xms.g.common.api.Api.ApiOptions.NoOptions) {
                    return ((org.xms.g.common.api.Api.ApiOptions.NoOptions) param0);
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    com.google.android.gms.common.api.Api.ApiOptions.NoOptions gReturn = ((com.google.android.gms.common.api.Api.ApiOptions.NoOptions) ((org.xms.g.utils.XGettable) param0).getGInstance());
                    return new org.xms.g.common.api.Api.ApiOptions.NoOptions(new org.xms.g.utils.XBox(gReturn));
                }
                return ((org.xms.g.common.api.Api.ApiOptions.NoOptions) param0);
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.NoOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
             *
             * @param param0 the input object
             * @return true if the Object is XMS instance, otherwise false
             */
            public static boolean isInstance(java.lang.Object param0) {
                if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                    return false;
                }
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
            }
        }
        
        /**
         * Base interface for Api.ApiOptions that are not required, don't exist.<br/>
         * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions: Base interface for Api.ApiOptions that are not required, don't exist.<br/>
         */
        public static interface NotRequiredOptions extends org.xms.g.utils.XInterface, org.xms.g.common.api.Api.ApiOptions {
            
            default java.lang.Object getZInstanceNotRequiredOptions() {
                return getGInstanceNotRequiredOptions();
            }
            
            default com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions getGInstanceNotRequiredOptions() {
                if (this instanceof org.xms.g.utils.XGettable) {
                    return ((com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions) ((org.xms.g.utils.XGettable) this).getGInstance());
                }
                return new com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions() {
                };
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions.<br/>
             *
             * @param param0 the input object
             * @return casted Api.ApiOptions.NotRequiredOptions object
             */
            public static org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions dynamicCast(java.lang.Object param0) {
                if (param0 instanceof org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions) {
                    return ((org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions) param0);
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions gReturn = ((com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions) ((org.xms.g.utils.XGettable) param0).getGInstance());
                    return new org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions.XImpl(new org.xms.g.utils.XBox(gReturn));
                }
                return ((org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions) param0);
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
             *
             * @param param0 the input object
             * @return true if the Object is XMS instance, otherwise false
             */
            public static boolean isInstance(java.lang.Object param0) {
                if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                    return false;
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions;
                }
                return param0 instanceof org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions;
            }
            
            /**
             * Wrapper class of ApiOptions.NotRequiredOptions which is base interface for Api.ApiOptions that are not required, don't exist.<br/>
             * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions, but only the GMS API are provided.<br/>
             * com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions: Base interface for Api.ApiOptions that are not required, don't exist.<br/>
             */
            public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions {
                
                /**
                 * org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
                 *
                 * @param param0 the wrapper of xms instance
                 */
                public XImpl(org.xms.g.utils.XBox param0) {
                    super(param0);
                }
            }
        }
        
        /**
         * Base interface for Api.ApiOptions that are optional.<br/>
         * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.Optional, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.Api.ApiOptions.Optional: Base interface for Api.ApiOptions that are optional.<br/>
         */
        public static interface Optional extends org.xms.g.utils.XInterface, org.xms.g.common.api.Api.ApiOptions.HasOptions, org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions {
            
            default java.lang.Object getZInstanceOptional() {
                return getGInstanceOptional();
            }
            
            default com.google.android.gms.common.api.Api.ApiOptions.Optional getGInstanceOptional() {
                if (this instanceof org.xms.g.utils.XGettable) {
                    return ((com.google.android.gms.common.api.Api.ApiOptions.Optional) ((org.xms.g.utils.XGettable) this).getGInstance());
                }
                return new com.google.android.gms.common.api.Api.ApiOptions.Optional() {
                };
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.Optional.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.Api.ApiOptions.Optional.<br/>
             *
             * @param param0 the input object
             * @return casted Api.ApiOptions.Optional object
             */
            public static org.xms.g.common.api.Api.ApiOptions.Optional dynamicCast(java.lang.Object param0) {
                if (param0 instanceof org.xms.g.common.api.Api.ApiOptions.Optional) {
                    return ((org.xms.g.common.api.Api.ApiOptions.Optional) param0);
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    com.google.android.gms.common.api.Api.ApiOptions.Optional gReturn = ((com.google.android.gms.common.api.Api.ApiOptions.Optional) ((org.xms.g.utils.XGettable) param0).getGInstance());
                    return new org.xms.g.common.api.Api.ApiOptions.Optional.XImpl(new org.xms.g.utils.XBox(gReturn));
                }
                return ((org.xms.g.common.api.Api.ApiOptions.Optional) param0);
            }
            
            /**
             * org.xms.g.common.api.Api.ApiOptions.Optional.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
             *
             * @param param0 the input object
             * @return true if the Object is XMS instance, otherwise false
             */
            public static boolean isInstance(java.lang.Object param0) {
                if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                    return false;
                }
                if (param0 instanceof org.xms.g.utils.XGettable) {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.Api.ApiOptions.Optional;
                }
                return param0 instanceof org.xms.g.common.api.Api.ApiOptions.Optional;
            }
            
            /**
             * Wrapper class of ApiOptions.Optional which is base interface for Api.ApiOptions that are optional.<br/>
             * Wrapper class for com.google.android.gms.common.api.Api.ApiOptions.Optional, but only the GMS API are provided.<br/>
             * com.google.android.gms.common.api.Api.ApiOptions.Optional: Base interface for Api.ApiOptions that are optional.<br/>
             */
            public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.Optional {
                
                /**
                 * org.xms.g.common.api.Api.ApiOptions.Optional.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
                 *
                 * @param param0 the wrapper of xms instance
                 */
                public XImpl(org.xms.g.utils.XBox param0) {
                    super(param0);
                }
            }
        }
    }
}