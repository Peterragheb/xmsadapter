package org.xms.g.common.api;

/**
 * Exception to be returned by a Task when a call to services has failed with a possible resolution that you need to rectify.<br/>
 * Wrapper class for com.google.android.gms.common.api.ResolvableApiException, but only the GMS API are provided.<br/>
 * com.google.android.gms.common.api.ResolvableApiException: Exception to be returned by a Task when a call to Google Play services has failed with a possible resolution.<br/>
 */
public class ResolvableApiException extends org.xms.g.common.api.ApiException {
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.api.ResolvableApiException.ResolvableApiException(org.xms.g.utils.XBox) constructor of ResolvableApiException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ResolvableApiException(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ResolvableApiException.ResolvableApiException(org.xms.g.common.api.Status) constructor of ResolvableApiException.<br/>
     * com.google.android.gms.common.api.ResolvableApiException.ResolvableApiException(com.google.android.gms.common.api.Status): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-resolvableapiexception-status-status">https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-resolvableapiexception-status-status</a><br/>
     *
     * @param param0 Status instance
     */
    public ResolvableApiException(org.xms.g.common.api.Status param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new GImpl(((com.google.android.gms.common.api.Status) ((param0) == null ? null : (param0.getGInstance())))));
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ResolvableApiException.getResolution() A pending intent to resolve the failure.<br/>
     * com.google.android.gms.common.api.ResolvableApiException.getResolution(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-pendingintent-getresolution">https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-pendingintent-getresolution</a><br/>
     *
     * @return The pending intent to resolve the failure
     */
    public android.app.PendingIntent getResolution() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance()).getResolution()");
            return ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance()).getResolution();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance())).getResolutionCallSuper()");
            return ((GImpl) ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance())).getResolutionCallSuper();
        }
    }
    
    /**
     * org.xms.g.common.api.ResolvableApiException.startResolutionForResult(android.app.Activity,int) Resolves an error by starting any intents requiring user interaction.<br/>
     * com.google.android.gms.common.api.ResolvableApiException.startResolutionForResult(android.app.Activity,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-void-startresolutionforresult-activity-activity,-int-requestcode">https://developers.google.com/android/reference/com/google/android/gms/common/api/ResolvableApiException#public-void-startresolutionforresult-activity-activity,-int-requestcode</a><br/>
     *
     * @param param0 An Activity context to use to resolve the issue
     * @param param1 The request code to pass to onActivityResult
     * @throws android.content.IntentSender.SendIntentException If the resolution intent has been canceled or is no longer able to execute the request
     */
    public void startResolutionForResult(android.app.Activity param0, int param1) throws android.content.IntentSender.SendIntentException {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance()).startResolutionForResult(param0, param1)");
            ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance()).startResolutionForResult(param0, param1);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance())).startResolutionForResultCallSuper(param0, param1)");
            ((GImpl) ((com.google.android.gms.common.api.ResolvableApiException) this.getGInstance())).startResolutionForResultCallSuper(param0, param1);
        }
    }
    
    /**
     * org.xms.g.common.api.ResolvableApiException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ResolvableApiException.<br/>
     *
     * @param param0 the input object
     * @return casted ResolvableApiException object
     */
    public static org.xms.g.common.api.ResolvableApiException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.ResolvableApiException) param0);
    }
    
    /**
     * org.xms.g.common.api.ResolvableApiException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.ResolvableApiException;
    }
    
    private class GImpl extends com.google.android.gms.common.api.ResolvableApiException {
        
        public android.app.PendingIntent getResolution() {
            return org.xms.g.common.api.ResolvableApiException.this.getResolution();
        }
        
        public void startResolutionForResult(android.app.Activity param0, int param1) throws android.content.IntentSender.SendIntentException {
            org.xms.g.common.api.ResolvableApiException.this.startResolutionForResult(param0, param1);
        }
        
        public android.app.PendingIntent getResolutionCallSuper() {
            return super.getResolution();
        }
        
        public void startResolutionForResultCallSuper(android.app.Activity param0, int param1) throws android.content.IntentSender.SendIntentException {
            super.startResolutionForResult(param0, param1);
        }
        
        public GImpl(com.google.android.gms.common.api.Status param0) {
            super(param0);
        }
    }
}