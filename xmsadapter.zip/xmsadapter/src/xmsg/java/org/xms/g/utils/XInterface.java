package org.xms.g.utils;

/**
 * Interface for XInterface
 */
public interface XInterface {
}
