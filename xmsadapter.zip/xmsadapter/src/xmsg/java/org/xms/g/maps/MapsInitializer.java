package org.xms.g.maps;

/**
 * xms Use this class to initialize the Maps SDK for Android if features need to be used before obtaining a map.<br/>
 * Wrapper class for com.google.android.gms.maps.MapsInitializer, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.MapsInitializer: Use this class to initialize the Google Maps SDK for Android if features need to be used before obtaining a map. It must be called because some classes such as BitmapDescriptorFactory and CameraUpdateFactory need to be initialized.<br/>
 */
public final class MapsInitializer extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.MapsInitializer.MapsInitializer(org.xms.g.utils.XBox) A final class that extends Object.<br/>
     * com.google.android.gms.maps.MapsInitializer.MapsInitializer(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/MapsInitializer">https://developers.google.com/android/reference/com/google/android/gms/maps/MapsInitializer</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public MapsInitializer(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.MapsInitializer.initialize(android.content.Context) Initializes the Google Maps SDK for Android so that its classes are ready for use.<br/>
     * com.google.android.gms.maps.MapsInitializer.initialize(android.content.Context): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/MapsInitializer#public-static-synchronized-int-initialize-context-context">https://developers.google.com/android/reference/com/google/android/gms/maps/MapsInitializer#public-static-synchronized-int-initialize-context-context</a><br/>
     *
     * @param param0 Required to fetch the necessary SDK resources and code. Must not be null
     * @return A ConnectionResult error code
     */
    public static final int initialize(android.content.Context param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.maps.MapsInitializer.initialize(param0)");
        return com.google.android.gms.maps.MapsInitializer.initialize(param0);
    }
    
    /**
     * org.xms.g.maps.MapsInitializer.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.MapsInitializer.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps MapsInitializer object
     */
    public static org.xms.g.maps.MapsInitializer dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.MapsInitializer) param0);
    }
    
    /**
     * org.xms.g.maps.MapsInitializer.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.MapsInitializer;
    }
}