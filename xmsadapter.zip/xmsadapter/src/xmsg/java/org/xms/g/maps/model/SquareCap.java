package org.xms.g.maps.model;

/**
 * xms Cap that is squared off after extending half the stroke width beyond the start or end vertex of a Polyline with solid stroke pattern.<br/>
 * Wrapper class for com.google.android.gms.maps.model.SquareCap, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.SquareCap: Cap that is squared off after extending half the stroke width beyond the start or end vertex of a Polyline with solid stroke pattern.<br/>
 */
public final class SquareCap extends org.xms.g.maps.model.Cap {
    
    /**
     * org.xms.g.maps.model.SquareCap.SquareCap(org.xms.g.utils.XBox) Cap that is squared off after extending half the stroke width beyond the start or end vertex of a Polyline with solid stroke pattern.<br/>
     * com.google.android.gms.maps.model.SquareCap.SquareCap(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap">https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public SquareCap(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.SquareCap.SquareCap() Cap that is squared off after extending half the stroke width beyond the start or end vertex of a Polyline with solid stroke pattern.<br/>
     * com.google.android.gms.maps.model.SquareCap.SquareCap(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap">https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap</a><br/>
     *
     */
    public SquareCap() {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.SquareCap());
    }
    
    /**
     * org.xms.g.maps.model.SquareCap.toString() to String.<br/>
     * com.google.android.gms.maps.model.SquareCap.toString(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap#public-string-tostring">https://developers.google.com/android/reference/com/google/android/gms/maps/model/SquareCap#public-string-tostring</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.SquareCap) this.getGInstance()).toString()");
        return ((com.google.android.gms.maps.model.SquareCap) this.getGInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.SquareCap.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.SquareCap.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model SquareCap object
     */
    public static org.xms.g.maps.model.SquareCap dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.SquareCap) param0);
    }
    
    /**
     * org.xms.g.maps.model.SquareCap.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.SquareCap;
    }
}