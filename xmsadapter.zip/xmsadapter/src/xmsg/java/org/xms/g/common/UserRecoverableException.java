package org.xms.g.common;

/**
 * UserRecoverableExceptions signal errors that can be recovered with user action, such as a user login.<br/>
 * Wrapper class for com.google.android.gms.common.UserRecoverableException, but only the GMS API are provided.<br/>
 * com.google.android.gms.common.UserRecoverableException: UserRecoverableExceptions signal errors that can be recovered with user action, such as a user login.<br/>
 */
public class UserRecoverableException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.UserRecoverableException.UserRecoverableException(org.xms.g.utils.XBox) constructor of UserRecoverableException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public UserRecoverableException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.UserRecoverableException(java.lang.String,android.content.Intent) constructor of UserRecoverableExceptionbr./> Support running environments including both HMS and GMS which are chosen by users.<br/>
     * com.google.android.gms.common.UserRecoverableException.UserRecoverableException(java.lang.String,android.content.Intent): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/UserRecoverableException#public-userrecoverableexception-string-msg,-intent-intent">https://developers.google.com/android/reference/com/google/android/gms/common/UserRecoverableException#public-userrecoverableexception-string-msg,-intent-intent</a><br/>
     *
     * @param param0 the msg
     * @param param1 the intent
     */
    public UserRecoverableException(java.lang.String param0, android.content.Intent param1) {
        this.setGInstance(new GImpl(param0, param1));
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.getIntent() Getter for an Intent that when supplied to startActivityForResult(Intent, int), will allow user intervention.<br/>
     * com.google.android.gms.common.UserRecoverableException.getIntent(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/UserRecoverableException#public-intent-getintent">https://developers.google.com/android/reference/com/google/android/gms/common/UserRecoverableException#public-intent-getintent</a><br/>
     *
     * @return Intent representing the ameliorating user action
     */
    public android.content.Intent getIntent() {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.UserRecoverableException) this.getGInstance()).getIntent()");
            return ((com.google.android.gms.common.UserRecoverableException) this.getGInstance()).getIntent();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.common.UserRecoverableException) this.getGInstance())).getIntentCallSuper()");
            return ((GImpl) ((com.google.android.gms.common.UserRecoverableException) this.getGInstance())).getIntentCallSuper();
        }
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.UserRecoverableException.<br/>
     *
     * @param param0 the input object
     * @return casted UserRecoverableException object
     */
    public static org.xms.g.common.UserRecoverableException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.UserRecoverableException) param0);
    }
    
    /**
     * org.xms.g.common.UserRecoverableException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.UserRecoverableException;
    }
    
    private class GImpl extends com.google.android.gms.common.UserRecoverableException {
        
        public android.content.Intent getIntent() {
            return org.xms.g.common.UserRecoverableException.this.getIntent();
        }
        
        public android.content.Intent getIntentCallSuper() {
            return super.getIntent();
        }
        
        public GImpl(java.lang.String param0, android.content.Intent param1) {
            super(param0, param1);
        }
    }
}