package org.xms.g.measurement;

/**
 * A BroadcastReceiver for Analytics.<br/>
 * Wrapper class for com.google.android.gms.measurement.AppMeasurementReceiver, but only the GMS API are provided.<br/>
 * com.google.android.gms.measurement.AppMeasurementReceiver: A BroadcastReceiver for Firebase Analytics. Firebase Analytics requires this receiver to be correctly declared in AndroidManifest.xml and enabled.<br/>
 */
public final class AppMeasurementReceiver extends androidx.legacy.content.WakefulBroadcastReceiver implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.AppMeasurementReceiver(org.xms.g.utils.XBox) constructor of AppMeasurementReceiver with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AppMeasurementReceiver(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.AppMeasurementReceiver() constructor of AppMeasurementReceiver.<br/>
     * com.google.android.gms.measurement.AppMeasurementReceiver.AppMeasurementReceiver(): <a href="https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementReceiver#public-appmeasurementreceiver">https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementReceiver#public-appmeasurementreceiver</a><br/>
     *
     */
    public AppMeasurementReceiver() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final android.content.BroadcastReceiver.PendingResult doGoAsync() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void doStartService(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onReceive(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.measurement.AppMeasurementReceiver.<br/>
     *
     * @param param0 the input object
     * @return casted AppMeasurementReceiver object
     */
    public static org.xms.g.measurement.AppMeasurementReceiver dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementReceiver.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}