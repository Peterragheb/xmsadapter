package org.xms.g.maps.model;

/**
 * xms A RuntimeException wrapper for RemoteException.<br/>
 * Wrapper class for com.google.android.gms.maps.model.RuntimeRemoteException, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.RuntimeRemoteException: A RuntimeException wrapper for RemoteException. Thrown when normally there is something seriously wrong and there is no way to recover.<br/>
 */
public final class RuntimeRemoteException extends java.lang.RuntimeException implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.RuntimeRemoteException(org.xms.g.utils.XBox) A RuntimeException wrapper for RemoteException.<br/>
     * com.google.android.gms.maps.model.RuntimeRemoteException.RuntimeRemoteException(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/RuntimeRemoteException#public-runtimeremoteexception-remoteexception-e">https://developers.google.com/android/reference/com/google/android/gms/maps/model/RuntimeRemoteException#public-runtimeremoteexception-remoteexception-e</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public RuntimeRemoteException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.RuntimeRemoteException(android.os.RemoteException) A RuntimeException wrapper for RemoteException.<br/>
     * com.google.android.gms.maps.model.RuntimeRemoteException.RuntimeRemoteException(android.os.RemoteException): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/RuntimeRemoteException#public-runtimeremoteexception-remoteexception-e">https://developers.google.com/android/reference/com/google/android/gms/maps/model/RuntimeRemoteException#public-runtimeremoteexception-remoteexception-e</a><br/>
     *
     * @param param0 the param should instanceof android os RemoteException
     */
    public RuntimeRemoteException(android.os.RemoteException param0) {
        this.setGInstance(new com.google.android.gms.maps.model.RuntimeRemoteException(param0));
    }
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.setGInstance(java.lang.Object) setGInstance.<br/>
     *
     * @param param0 the param should be instanceof java lang Object
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.getGInstance() get the hms instance from the corresponding xms instance.<br/>
     *
     * @return the return object is gInstance
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.RuntimeRemoteException.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model RuntimeRemoteException object
     */
    public static org.xms.g.maps.model.RuntimeRemoteException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.RuntimeRemoteException) param0);
    }
    
    /**
     * org.xms.g.maps.model.RuntimeRemoteException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.RuntimeRemoteException;
    }
}