package org.xms.g.tasks;

/**
 * Creates a new CancellationToken or cancels one that has already created.<br/>
 * Wrapper class for com.google.android.gms.tasks.CancellationTokenSource, but only the GMS API are provided.<br/>
 * com.google.android.gms.tasks.CancellationTokenSource: Creates a new CancellationToken or cancels one that has already created. There is a 1:1 CancellationTokenSource to CancellationToken relationship.To create a CancellationToken, create a CancellationTokenSource first and then call getToken() to get the CancellationToken for this CancellationTokenSource.<br/>
 */
public class CancellationTokenSource extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.tasks.CancellationTokenSource.CancellationTokenSource(org.xms.g.utils.XBox) constructor of CancellationTokenSource with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public CancellationTokenSource(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.tasks.CancellationTokenSource.cancel() Cancels the CancellationToken if cancellation has not been requested yet.<br/>
     * com.google.android.gms.tasks.CancellationTokenSource.cancel(): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/CancellationTokenSource#public-void-cancel">https://developers.google.com/android/reference/com/google/android/gms/tasks/CancellationTokenSource#public-void-cancel</a><br/>
     *
     */
    public void cancel() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.CancellationTokenSource) this.getGInstance()).cancel()");
        ((com.google.android.gms.tasks.CancellationTokenSource) this.getGInstance()).cancel();
    }
    
    /**
     * org.xms.g.tasks.CancellationTokenSource.getToken() Gets the CancellationToken for this CancellationTokenSource.<br/>
     * com.google.android.gms.tasks.CancellationToken.getToken(): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/CancellationTokenSource#public-cancellationtoken-gettoken">https://developers.google.com/android/reference/com/google/android/gms/tasks/CancellationTokenSource#public-cancellationtoken-gettoken</a><br/>
     *
     * @return the CancellationToken that can be passed to asynchronous Task to cancel the Task
     */
    public org.xms.g.tasks.CancellationToken getToken() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.CancellationTokenSource) this.getGInstance()).getToken()");
        com.google.android.gms.tasks.CancellationToken gReturn = ((com.google.android.gms.tasks.CancellationTokenSource) this.getGInstance()).getToken();
        return ((gReturn) == null ? null : (new org.xms.g.tasks.CancellationToken.XImpl(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.tasks.CancellationTokenSource.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.CancellationTokenSource.<br/>
     *
     * @param param0 the input object
     * @return casted CancellationTokenSource object
     */
    public static org.xms.g.tasks.CancellationTokenSource dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.CancellationTokenSource) param0);
    }
    
    /**
     * org.xms.g.tasks.CancellationTokenSource.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.tasks.CancellationTokenSource;
    }
}