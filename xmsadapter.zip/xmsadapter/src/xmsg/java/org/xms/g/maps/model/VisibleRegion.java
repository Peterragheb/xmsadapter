package org.xms.g.maps.model;

/**
 * xms Contains the four points defining the four-sided polygon that is visible in a map's camera.<br/>
 * Wrapper class for com.google.android.gms.maps.model.VisibleRegion, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.VisibleRegion: Contains the four points defining the four-sided polygon that is visible in a map's camera. This polygon can be a trapezoid instead of a rectangle, because a camera can have tilt. If the camera is directly over the center of the camera, the shape is rectangular, but if the camera is tilted, the shape will appear to be a trapezoid whose smallest side is closest to the point of view.<br/>
 */
public final class VisibleRegion extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.google.android.gms.maps.model.VisibleRegion.CREATOR: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.VisibleRegion createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.maps.model.VisibleRegion gReturn = com.google.android.gms.maps.model.VisibleRegion.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.VisibleRegion(new org.xms.g.utils.XBox(gReturn));
        }
        
        public org.xms.g.maps.model.VisibleRegion[] newArray(int param0) {
            return new org.xms.g.maps.model.VisibleRegion[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.VisibleRegion.VisibleRegion(org.xms.g.utils.XBox) Contains the four points defining the four-sided polygon that is visible in a map's camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.VisibleRegion(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public VisibleRegion(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.VisibleRegion(org.xms.g.maps.model.LatLng,org.xms.g.maps.model.LatLng,org.xms.g.maps.model.LatLng,org.xms.g.maps.model.LatLng,org.xms.g.maps.model.LatLngBounds) Contains the four points defining the four-sided polygon that is visible in a map's camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.VisibleRegion(com.google.android.gms.maps.model.LatLng,com.google.android.gms.maps.model.LatLng,com.google.android.gms.maps.model.LatLng,com.google.android.gms.maps.model.LatLng,com.google.android.gms.maps.model.LatLngBounds): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion</a><br/>
     *
     * @param param0 a LatLng object containing the latitude and longitude of the far left corner of the region
     * @param param1 a LatLng object containing the latitude and longitude of the far right corner of the region
     * @param param2 a LatLng object containing the latitude and longitude of the near left corner of the region
     * @param param3 a LatLng object containing the latitude and longitude of the near right corner of the region
     * @param param4 the smallest bounding box that includes the visible region defined in this class. If this box crosses the 180?? meridian (the vertical line from north to south), the longitude in farRight will be negative and the longitude in farLeft will be positive. Same applies to nearRight and nearLeft
     */
    public VisibleRegion(org.xms.g.maps.model.LatLng param0, org.xms.g.maps.model.LatLng param1, org.xms.g.maps.model.LatLng param2, org.xms.g.maps.model.LatLng param3, org.xms.g.maps.model.LatLngBounds param4) {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.VisibleRegion(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.maps.model.LatLng) ((param1) == null ? null : (param1.getGInstance()))), ((com.google.android.gms.maps.model.LatLng) ((param2) == null ? null : (param2.getGInstance()))), ((com.google.android.gms.maps.model.LatLng) ((param3) == null ? null : (param3.getGInstance()))), ((com.google.android.gms.maps.model.LatLngBounds) ((param4) == null ? null : (param4.getGInstance())))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.getFarLeft() LatLng object that defines the far left corner of the camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.farLeft: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-farleft">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-farleft</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getFarLeft() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).farLeft");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).farLeft;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.getFarRight() LatLng object that defines the far right corner of the camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.farRight: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-farright">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-farright</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getFarRight() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).farRight");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).farRight;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.getLatLngBounds() The smallest bounding box that includes the visible region defined in this class.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.latLngBounds: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlngbounds-latlngbounds">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlngbounds-latlngbounds</a><br/>
     *
     * @return the return object is maps model LatLngBounds
     */
    public org.xms.g.maps.model.LatLngBounds getLatLngBounds() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).latLngBounds");
        com.google.android.gms.maps.model.LatLngBounds gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).latLngBounds;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.getNearLeft() LatLng object that defines the bottom left corner of the camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.nearLeft: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-nearleft">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-nearleft</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getNearLeft() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).nearLeft");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).nearLeft;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.getNearRight() LatLng object that defines the bottom right corner of the camera.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.nearRight: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-nearright">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-final-latlng-nearright</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getNearRight() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).nearRight");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).nearRight;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.equals(java.lang.Object) Compares this VisibleRegion to another object. If the other object is actually a pointer to this object, or if all four corners and the bounds of the two objects are the same, this method returns true. Otherwise, this method returns false.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-boolean-equals-object-o">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-boolean-equals-object-o</a><br/>
     *
     * @param param0 an Object. Return true if both objects are the same object, or if all four corners and the bounds of the two objects are the same. Return false otherwise
     * @return the return object is boolean
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.hashCode() hash Code .<br/>
     * com.google.android.gms.maps.model.VisibleRegion.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.toString() to String.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.toString(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-string-tostring">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-string-tostring</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).toString()");
        return ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.google.android.gms.maps.model.VisibleRegion.writeToParcel(android.os.Parcel,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-void-writetoparcel-parcel-out,-int-flags">https://developers.google.com/android/reference/com/google/android/gms/maps/model/VisibleRegion#public-void-writetoparcel-parcel-out,-int-flags</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).writeToParcel(param0, param1)");
        ((com.google.android.gms.maps.model.VisibleRegion) this.getGInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.VisibleRegion.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model VisibleRegion object
     */
    public static org.xms.g.maps.model.VisibleRegion dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.VisibleRegion) param0);
    }
    
    /**
     * org.xms.g.maps.model.VisibleRegion.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.VisibleRegion;
    }
}