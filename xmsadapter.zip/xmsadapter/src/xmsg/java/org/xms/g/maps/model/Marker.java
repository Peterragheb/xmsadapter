package org.xms.g.maps.model;

/**
 * xms An icon placed at a particular point on the map's surface.<br/>
 * Wrapper class for com.google.android.gms.maps.model.Marker, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.Marker: An icon placed at a particular point on the map's surface. A marker icon is drawn oriented against the device's screen rather than the map's surface; i.e., it will not necessarily change orientation due to map rotations, tilting, or zooming.<br/>
 */
public final class Marker extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.Marker.Marker(org.xms.g.utils.XBox) An icon placed at a particular point on the map's surface.<br/>
     * com.google.android.gms.maps.model.Marker.Marker(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Marker(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.equals(java.lang.Object) Tests if this Marker is equal to another.<br/>
     * com.google.android.gms.maps.model.Marker.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-equals-object-other">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-equals-object-other</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.getAlpha() Gets the alpha of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getAlpha(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getalpha">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getalpha</a><br/>
     *
     * @return the alpha of the marker in the range [0, 1]
     */
    public final float getAlpha() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getAlpha()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getAlpha();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getId() Gets this marker's id. The id will be unique amongst all Markers on a map.<br/>
     * com.google.android.gms.maps.model.Marker.getId(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-getid">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-getid</a><br/>
     *
     * @return this marker's id
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getId()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getPosition() Returns the position of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getPosition(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-latlng-getposition">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-latlng-getposition</a><br/>
     *
     * @return A LatLng object specifying the marker's current position
     */
    public final org.xms.g.maps.model.LatLng getPosition() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getPosition()");
        com.google.android.gms.maps.model.LatLng gReturn = ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getPosition();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.Marker.getRotation() Gets the rotation of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getRotation(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getrotation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getrotation</a><br/>
     *
     * @return the rotation of the marker in degrees clockwise from the default position
     */
    public final float getRotation() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getRotation()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getRotation();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getSnippet() Gets the snippet of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getSnippet(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-getsnippet">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-getsnippet</a><br/>
     *
     * @return A string containing the marker's snippet
     */
    public final java.lang.String getSnippet() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getSnippet()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getSnippet();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getTag() Gets the tag for the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getTag(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-object-gettag">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-object-gettag</a><br/>
     *
     * @return the tag if a tag was set with setTag; null if no tag has been set
     */
    public final java.lang.Object getTag() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getTag()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getTag();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getTitle() Gets the title of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getTitle(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-gettitle">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-string-gettitle</a><br/>
     *
     * @return A string containing the marker's title
     */
    public final java.lang.String getTitle() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getTitle()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getTitle();
    }
    
    /**
     * org.xms.g.maps.model.Marker.getZIndex() Returns the zIndex of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-float-getzindex</a><br/>
     *
     * @return this marker's zIndex
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.Marker.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.Marker.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.Marker.hideInfoWindow() Hides the info window if it is shown from this marker.<br/>
     * com.google.android.gms.maps.model.Marker.hideInfoWindow(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-hideinfowindow">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-hideinfowindow</a><br/>
     *
     */
    public final void hideInfoWindow() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).hideInfoWindow()");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).hideInfoWindow();
    }
    
    /**
     * org.xms.g.maps.model.Marker.isDraggable() Gets the draggability of the marker. When a marker is draggable, it can be moved by the user by long pressing on the marker.<br/>
     * com.google.android.gms.maps.model.Marker.isDraggable(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isdraggable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isdraggable</a><br/>
     *
     * @return true if the marker is draggable; otherwise, returns false
     */
    public final boolean isDraggable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).isDraggable()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).isDraggable();
    }
    
    /**
     * org.xms.g.maps.model.Marker.isFlat() Gets the flat setting of the Marker.<br/>
     * com.google.android.gms.maps.model.Marker.isFlat(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isflat">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isflat</a><br/>
     *
     * @return true if the marker is flat against the map; false if the marker should face the camera
     */
    public final boolean isFlat() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).isFlat()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).isFlat();
    }
    
    /**
     * org.xms.g.maps.model.Marker.isInfoWindowShown() Returns whether the info window is currently shown above this marker. This does not consider whether or not the info window is actually visible on screen.<br/>
     * com.google.android.gms.maps.model.Marker.isInfoWindowShown(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isinfowindowshown">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isinfowindowshown</a><br/>
     *
     * @return the return object is boolean
     */
    public final boolean isInfoWindowShown() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).isInfoWindowShown()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).isInfoWindowShown();
    }
    
    /**
     * org.xms.g.maps.model.Marker.isVisible() Gets the visibility setting of this marker. Note that this does not indicate whether the marker is within the screen's viewport. It indicates whether the marker will be drawn if it is contained in the screen's viewport.<br/>
     * com.google.android.gms.maps.model.Marker.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-boolean-isvisible</a><br/>
     *
     * @return this marker's visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.Marker) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.Marker.remove() Removes this marker from the map. After a marker has been removed, the behavior of all its methods is undefined.<br/>
     * com.google.android.gms.maps.model.Marker.remove(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-remove">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-remove</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).remove()");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.Marker.setAlpha(float) Removes this marker from the map. After a marker has been removed, the behavior of all its methods is undefined.<br/>
     * com.google.android.gms.maps.model.Marker.setAlpha(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setalpha-float-alpha">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setalpha-float-alpha</a><br/>
     *
     * @param param0 the param should be instanceof float
     */
    public final void setAlpha(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setAlpha(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setAlpha(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setAnchor(float,float) Sets the anchor point for the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setAnchor(float,float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setanchor-float-anchoru,-float-anchorv">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setanchor-float-anchoru,-float-anchorv</a><br/>
     *
     * @param param0 v-coordinate of the anchor, as a ratio of the image height (in the range [0, 1])
     * @param param1 u-coordinate of the anchor, as a ratio of the image width (in the range [0, 1])
     */
    public final void setAnchor(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setAnchor(param0, param1)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setAnchor(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setDraggable(boolean) Sets the draggability of the marker. When a marker is draggable, it can be moved by the user by long pressing on the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setDraggable(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setdraggable-boolean-draggable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setdraggable-boolean-draggable</a><br/>
     *
     * @param param0 the param should be instanceof boolean
     */
    public final void setDraggable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setDraggable(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setDraggable(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setFlat(boolean) Sets whether this marker should be flat against the map true or a billboard facing the camera false.<br/>
     * com.google.android.gms.maps.model.Marker.setFlat(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setflat-boolean-flat">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setflat-boolean-flat</a><br/>
     *
     * @param param0 the param should be instanceof boolean
     */
    public final void setFlat(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setFlat(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setFlat(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setIcon(org.xms.g.maps.model.BitmapDescriptor) Sets the icon for the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setIcon(com.google.android.gms.maps.model.BitmapDescriptor): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-seticon-bitmapdescriptor-icondescriptor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-seticon-bitmapdescriptor-icondescriptor</a><br/>
     *
     * @param param0 if null, the default marker is used
     */
    public final void setIcon(org.xms.g.maps.model.BitmapDescriptor param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setIcon(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))))");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setIcon(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.Marker.setInfoWindowAnchor(float,float) Specifies the point in the marker image at which to anchor the info window when it is displayed. This is specified in the same coordinate system as the anchor. See setAnchor(float, float)for more details. The default is the top middle of the image.<br/>
     * com.google.android.gms.maps.model.Marker.setInfoWindowAnchor(float,float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setinfowindowanchor-float-anchoru,-float-anchorv">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setinfowindowanchor-float-anchoru,-float-anchorv</a><br/>
     *
     * @param param0 v-coordinate of the info window anchor, as a ratio of the image height (in the range [0, 1])
     * @param param1 u-coordinate of the info window anchor, as a ratio of the image width (in the range [0, 1])
     */
    public final void setInfoWindowAnchor(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setInfoWindowAnchor(param0, param1)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setInfoWindowAnchor(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setPosition(org.xms.g.maps.model.LatLng) Sets the location of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setPosition(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setposition-latlng-latlng">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setposition-latlng-latlng</a><br/>
     *
     * @param param0 the param should be instanceof maps model LatLng
     */
    public final void setPosition(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setPosition(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setPosition(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.Marker.setRotation(float) Sets the rotation of the marker in degrees clockwise about the marker's anchor point. The axis of rotation is perpendicular to the marker. A rotation of 0 corresponds to the default position of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setRotation(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setrotation-float-rotation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setrotation-float-rotation</a><br/>
     *
     * @param param0 the param should be instanceof float
     */
    public final void setRotation(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setRotation(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setRotation(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setSnippet(java.lang.String) Sets the snippet of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setSnippet(java.lang.String): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setsnippet-string-snippet">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setsnippet-string-snippet</a><br/>
     *
     * @param param0 if null, the snippet is cleared
     */
    public final void setSnippet(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setSnippet(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setSnippet(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setTag(java.lang.Object) Sets the tag for the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setTag(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-settag-object-tag">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-settag-object-tag</a><br/>
     *
     * @param param0 if null, the tag is cleared
     */
    public final void setTag(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setTag(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setTag(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setTitle(java.lang.String) Sets the title of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setTitle(java.lang.String): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-settitle-string-title">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-settitle-string-title</a><br/>
     *
     * @param param0 if null, the title is cleared
     */
    public final void setTitle(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setTitle(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setTitle(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setVisible(boolean) Sets the visibility of this marker. If set to false and an info window is currently showing for this marker, this will hide the info window.<br/>
     * com.google.android.gms.maps.model.Marker.setVisible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setvisible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setvisible-boolean-visible</a><br/>
     *
     * @param param0 the param should be instanceof boolean
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setVisible(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.setZIndex(float) Sets the zIndex of the marker.<br/>
     * com.google.android.gms.maps.model.Marker.setZIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setzindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-setzindex-float-zindex</a><br/>
     *
     * @param param0 the param should be instanceof float
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).setZIndex(param0)");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.showInfoWindow() Shows the info window of this marker on the map, if this marker isVisible().<br/>
     * com.google.android.gms.maps.model.Marker.showInfoWindow(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-showinfowindow">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker#public-void-showinfowindow</a><br/>
     *
     * @throws java.lang.IllegalArgumentException if marker is not on this map
     */
    public final void showInfoWindow() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Marker) this.getGInstance()).showInfoWindow()");
        ((com.google.android.gms.maps.model.Marker) this.getGInstance()).showInfoWindow();
    }
    
    /**
     * org.xms.g.maps.model.Marker.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Marker.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Marker object
     */
    public static org.xms.g.maps.model.Marker dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Marker) param0);
    }
    
    /**
     * org.xms.g.maps.model.Marker.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.Marker;
    }
}