package org.xms.g.maps.model;

/**
 * xms Defines options for a polygon.<br/>
 * Wrapper class for com.google.android.gms.maps.model.PolygonOptions, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.PolygonOptions: Defines options for a polygon.<br/>
 */
public final class PolygonOptions extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.google.android.gms.maps.model.PolygonOptions.CREATOR: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng...-points">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng...-points</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.PolygonOptions createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.maps.model.PolygonOptions gReturn = com.google.android.gms.maps.model.PolygonOptions.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn));
        }
        
        public org.xms.g.maps.model.PolygonOptions[] newArray(int param0) {
            return new org.xms.g.maps.model.PolygonOptions[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.PolygonOptions.PolygonOptions(org.xms.g.utils.XBox) Defines options for a polygon.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.PolygonOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public PolygonOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.PolygonOptions() Defines options for a polygon.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.PolygonOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions</a><br/>
     *
     */
    public PolygonOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.PolygonOptions());
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.add(org.xms.g.maps.model.LatLng) Adds a vertex to the outline of the polygon being built.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.add(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng-point">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng-point</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return this PolygonOptions object with the given point added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions add(org.xms.g.maps.model.LatLng... param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).add(((com.google.android.gms.maps.model.LatLng[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.google.android.gms.maps.model.LatLng.class, x -> (com.google.android.gms.maps.model.LatLng)x.getGInstance())))");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).add(((com.google.android.gms.maps.model.LatLng[]) org.xms.g.utils.Utils.genericArrayCopy(param0, com.google.android.gms.maps.model.LatLng.class, x -> (com.google.android.gms.maps.model.LatLng)x.getGInstance())));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.add(org.xms.g.maps.model.LatLng) Adds a vertex to the outline of the polygon being built.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.add(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng-point">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-add-latlng-point</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return this PolygonOptions object with the given point added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions add(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).add(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).add(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.addAll(java.lang.Iterable<org.xms.g.maps.model.LatLng>) Adds vertices to the outline of the polygon being built.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.addAll(java.lang.Iterable<com.google.android.gms.maps.model.LatLng>): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-addall-iterablelatlng-points">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-addall-iterablelatlng-points</a><br/>
     *
     * @param param0 the param should instanceof java lang Iterable<LatLng>
     * @return this PolygonOptions object with the given points added to the outline
     */
    public final org.xms.g.maps.model.PolygonOptions addAll(java.lang.Iterable<org.xms.g.maps.model.LatLng> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).addAll(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, false)))");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).addAll(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, false)));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.addHole(java.lang.Iterable<org.xms.g.maps.model.LatLng>) Adds a hole to the polygon being built.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.addHole(java.lang.Iterable<com.google.android.gms.maps.model.LatLng>): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-addhole-iterablelatlng-points">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-addhole-iterablelatlng-points</a><br/>
     *
     * @param param0 the param should instanceof java lang Iterable<LatLng>
     * @return this PolygonOptions object with the given hole added
     */
    public final org.xms.g.maps.model.PolygonOptions addHole(java.lang.Iterable<org.xms.g.maps.model.LatLng> param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).addHole(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, false)))");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).addHole(org.xms.g.utils.Utils.transformIterable(param0, e -> org.xms.g.utils.Utils.getInstanceInInterface(e, false)));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.clickable(boolean) Specifies whether this polygon is clickable. The default setting is false.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.clickable(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-clickable-boolean-clickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-clickable-boolean-clickable</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new clickability setting
     */
    public final org.xms.g.maps.model.PolygonOptions clickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).clickable(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).clickable(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.fillColor(int) Specifies the polygon's fill color, as 32-bit ARGB. The default color is black( 0xff000000).<br/>
     * com.google.android.gms.maps.model.PolygonOptions.fillColor(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-fillcolor-int-color">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-fillcolor-int-color</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new fill color set
     */
    public final org.xms.g.maps.model.PolygonOptions fillColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).fillColor(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).fillColor(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.geodesic(boolean) Specifies whether to draw each segment of this polygon as a geodesic. The default setting is false.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.geodesic(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-geodesic-boolean-geodesic">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-geodesic-boolean-geodesic</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new geodesic setting
     */
    public final org.xms.g.maps.model.PolygonOptions geodesic(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).geodesic(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).geodesic(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getFillColor() Gets the fill color set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getFillColor(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getfillcolor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getfillcolor</a><br/>
     *
     * @return the fill color of the polygon in screen pixels
     */
    public final int getFillColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getFillColor()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getFillColor();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getHoles() Gets the holes set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getHoles(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listlistlatlng-getholes">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listlistlatlng-getholes</a><br/>
     *
     * @return the list of List<LatLng>s specifying the holes of the polygon
     */
    public final java.util.List<java.util.List<org.xms.g.maps.model.LatLng>> getHoles() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getHoles()");
        java.util.List<java.util.List<com.google.android.gms.maps.model.LatLng>> gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getHoles();
        return org.xms.g.utils.Utils.mapList(gReturn, e -> org.xms.g.utils.Utils.mapList2X(e, false));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getPoints() Gets the outline set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getPoints(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listlatlng-getpoints">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listlatlng-getpoints</a><br/>
     *
     * @return the list of LatLngs specifying the vertices of the outline of the polygon
     */
    public final java.util.List<org.xms.g.maps.model.LatLng> getPoints() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getPoints()");
        java.util.List gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getPoints();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
            
            public org.xms.g.maps.model.LatLng apply(com.google.android.gms.maps.model.LatLng param0) {
                return new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeColor() Gets the stroke color set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getStrokeColor(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getstrokecolor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getstrokecolor</a><br/>
     *
     * @return the stroke color of the polygon in screen pixels
     */
    public final int getStrokeColor() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeColor()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeColor();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeJointType() Gets the stroke joint type set in this PolygonOptions object for all vertices of the polygon's outline. See JointType for possible values.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getStrokeJointType(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getstrokejointtype">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-int-getstrokejointtype</a><br/>
     *
     * @return the stroke joint type of the polygon's outline
     */
    public final int getStrokeJointType() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeJointType()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeJointType();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokePattern() Gets the stroke pattern set in this PolygonOptions object for the polygon's outline.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getStrokePattern(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listpatternitem-getstrokepattern">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-listpatternitem-getstrokepattern</a><br/>
     *
     * @return the stroke pattern of the polygon's outline
     */
    public final java.util.List<org.xms.g.maps.model.PatternItem> getStrokePattern() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokePattern()");
        java.util.List gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokePattern();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.PatternItem, org.xms.g.maps.model.PatternItem>() {
            
            public org.xms.g.maps.model.PatternItem apply(com.google.android.gms.maps.model.PatternItem param0) {
                return new org.xms.g.maps.model.PatternItem(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getStrokeWidth() Gets the stroke width set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getStrokeWidth(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-float-getstrokewidth">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-float-getstrokewidth</a><br/>
     *
     * @return the stroke width of the polygon in screen pixels
     */
    public final float getStrokeWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeWidth()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getStrokeWidth();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.getZIndex() Gets the zIndex set for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-float-getzindex</a><br/>
     *
     * @return the zIndex of the polygon
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isClickable() Gets the clickability setting for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.isClickable(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isclickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isclickable</a><br/>
     *
     * @return true if the polygon is clickable; false if it is not
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isClickable()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isGeodesic() Gets the geodesic setting for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.isGeodesic(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isgeodesic">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isgeodesic</a><br/>
     *
     * @return true if the polygon segments should be geodesics; false if they should not be
     */
    public final boolean isGeodesic() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isGeodesic()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isGeodesic();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isVisible() Gets the visibility setting for this PolygonOptions object.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-boolean-isvisible</a><br/>
     *
     * @return true if the polygon is to be visible; false if it is not
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeColor(int) Specifies the polygon's stroke color, as 32-bit ARGB. The default color is black( 0xff000000).<br/>
     * com.google.android.gms.maps.model.PolygonOptions.strokeColor(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokecolor-int-color">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokecolor-int-color</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new stroke color set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeColor(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeColor(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeColor(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeJointType(int) Specifies the joint type for all vertices of the polygon's outline.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.strokeJointType(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokejointtype-int-jointtype">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokejointtype-int-jointtype</a><br/>
     *
     * @param param0 the param should instanceof int
     * @return this PolygonOptions object with a new stroke joint type set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeJointType(int param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeJointType(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeJointType(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokePattern(java.util.List) Specifies a stroke pattern for the polygon's outline. The default stroke pattern is solid, represented by null.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.strokePattern(java.util.List): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokepattern-listpatternitem-pattern">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokepattern-listpatternitem-pattern</a><br/>
     *
     * @param param0 the param should instanceof java util List
     * @return the return object is maps model PolygonOptions
     */
    public final org.xms.g.maps.model.PolygonOptions strokePattern(java.util.List param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, false))");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokePattern(org.xms.g.utils.Utils.mapList2GH(param0, false));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.strokeWidth(float) Specifies the polygon's stroke width, in display pixels. The default width is 10.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.strokeWidth(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokewidth-float-width">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-strokewidth-float-width</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this PolygonOptions object with a new stroke width set
     */
    public final org.xms.g.maps.model.PolygonOptions strokeWidth(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeWidth(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).strokeWidth(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.visible(boolean) Specifies the visibility for the polygon. The default visibility is true.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.visible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-visible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-visible-boolean-visible</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return this PolygonOptions object with a new visibility setting
     */
    public final org.xms.g.maps.model.PolygonOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).visible(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).visible(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.writeToParcel(android.os.Parcel,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-void-writetoparcel-parcel-out,-int-flags">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-void-writetoparcel-parcel-out,-int-flags</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).writeToParcel(param0, param1)");
        ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.zIndex(float) Specifies the polygon's zIndex, i.e., the order in which it will be drawn. See the documentation at the top of this class for more information about zIndex.<br/>
     * com.google.android.gms.maps.model.PolygonOptions.zIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-zindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/PolygonOptions#public-polygonoptions-zindex-float-zindex</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return this PolygonOptions object with a new zIndex set
     */
    public final org.xms.g.maps.model.PolygonOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).zIndex(param0)");
        com.google.android.gms.maps.model.PolygonOptions gReturn = ((com.google.android.gms.maps.model.PolygonOptions) this.getGInstance()).zIndex(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.PolygonOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.PolygonOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model PolygonOptions object
     */
    public static org.xms.g.maps.model.PolygonOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.PolygonOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.PolygonOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.PolygonOptions;
    }
}