package org.xms.g.maps.model;

/**
 * xms A ground overlay is an image that is fixed to a map. A ground overlay has the following properties.<br/>
 * Wrapper class for com.google.android.gms.maps.model.GroundOverlay, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.GroundOverlay: A ground overlay is an image that is fixed to a map.<br/>
 */
public final class GroundOverlay extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.GroundOverlay.GroundOverlay(org.xms.g.utils.XBox) A ground overlay is an image that is fixed to a map.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.GroundOverlay(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public GroundOverlay(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.equals(java.lang.Object) Tests if this GroundOverlay is equal to another.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-equals-object-other">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-equals-object-other</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getBearing() Gets the bearing of the ground overlay in degrees clockwise from north.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getBearing(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getbearing">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getbearing</a><br/>
     *
     * @return the bearing of the ground overlay
     */
    public final float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getBearing()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getBearing();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getBounds() Gets the bounds for the ground overlay. This ignores the rotation of the ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getBounds(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-latlngbounds-getbounds">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-latlngbounds-getbounds</a><br/>
     *
     * @return a LatLngBounds that contains the ground overlay, ignoring rotation
     */
    public final org.xms.g.maps.model.LatLngBounds getBounds() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getBounds()");
        com.google.android.gms.maps.model.LatLngBounds gReturn = ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getBounds();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getHeight() Gets the height of the ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getHeight(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getheight">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getheight</a><br/>
     *
     * @return the height of the ground overlay in meters
     */
    public final float getHeight() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getHeight()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getHeight();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getId() Gets this ground overlay's id. The id will be unique amongst all GroundOverlays on a map.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getId(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-string-getid">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-string-getid</a><br/>
     *
     * @return this ground overlay's id
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getId()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getPosition() Gets the location of the anchor point.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getPosition(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-latlng-getposition">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-latlng-getposition</a><br/>
     *
     * @return the position on the map (a LatLng)
     */
    public final org.xms.g.maps.model.LatLng getPosition() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getPosition()");
        com.google.android.gms.maps.model.LatLng gReturn = ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getPosition();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getTag() Gets the tag for the circle.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getTag(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-object-gettag">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-object-gettag</a><br/>
     *
     * @return the tag if a tag was set with setTag; null if no tag has been set
     */
    public final java.lang.Object getTag() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getTag()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getTag();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getTransparency() Gets the transparency of this ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getTransparency(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-gettransparency">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-gettransparency</a><br/>
     *
     * @return the transparency of this ground overlay
     */
    public final float getTransparency() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getTransparency()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getTransparency();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getWidth() Gets the width of the ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getWidth(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getwidth">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getwidth</a><br/>
     *
     * @return the width of the ground overlay in meters
     */
    public final float getWidth() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getWidth()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getWidth();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.getZIndex() Gets the zIndex of this ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-float-getzindex</a><br/>
     *
     * @return the zIndex of the ground overlay
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.isClickable() Gets the clickability of the ground overlay. If the ground overlay is clickable, your app will receive notifications to the GoogleMap.OnGroundOverlayClickListener when the user clicks the ground overlay. The event listener is registered through setOnGroundOverlayClickListener(GoogleMap.OnGroundOverlayClickListener).<br/>
     * com.google.android.gms.maps.model.GroundOverlay.isClickable(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-isclickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-isclickable</a><br/>
     *
     * @return true if the ground overlay is clickable; otherwise, returns false
     */
    public final boolean isClickable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).isClickable()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).isClickable();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.isVisible() Gets the visibility of this ground overlay. Note that this does not return whether the ground overlay is actually on screen, but whether it will be drawn if it is contained in the camera's viewport.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-boolean-isvisible</a><br/>
     *
     * @return this ground overlay's visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.remove() Removes this ground overlay from the map. After a ground overlay has been removed, the behavior of all its methods is undefined.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.remove(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-remove">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-remove</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).remove()");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setBearing(float) Sets the bearing of the ground overlay(the direction that the vertical axis of the ground overlay points)in degrees clockwise from north. The rotation is performed about the anchor point.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setBearing(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setbearing-float-bearing">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setbearing-float-bearing</a><br/>
     *
     * @param param0 bearing in degrees clockwise from north
     */
    public final void setBearing(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setBearing(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setBearing(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setClickable(boolean) Sets the clickability of the ground overlay. If the ground overlay is clickable, your app will receive notifications to the GoogleMap.OnGroundOverlayClickListener when the user clicks the ground overlay. The event listener is registered through setOnGroundOverlayClickListener(GoogleMap.OnGroundOverlayClickListener).<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setClickable(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setclickable-boolean-clickable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setclickable-boolean-clickable</a><br/>
     *
     * @param param0 New clickability setting for the ground overlay
     */
    public final void setClickable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setClickable(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setClickable(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setDimensions(float,float) Sets the width of the ground overlay. The height of the ground overlay will be adapted accordingly to preserve aspect ratio.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setDimensions(float,float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setdimensions-float-width">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setdimensions-float-width</a><br/>
     *
     * @param param0 the param should be instanceof float
     * @param param1 the param should be instanceof float
     */
    public final void setDimensions(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setDimensions(param0, param1)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setDimensions(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setDimensions(float) Sets the width of the ground overlay. The height of the ground overlay will be adapted accordingly to preserve aspect ratio.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setDimensions(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setdimensions-float-width">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setdimensions-float-width</a><br/>
     *
     * @param param0 width in meters
     */
    public final void setDimensions(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setDimensions(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setDimensions(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setImage(org.xms.g.maps.model.BitmapDescriptor) Sets the image for the Ground Overlay. The new image will occupy the same bounds as the old image.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setImage(com.google.android.gms.maps.model.BitmapDescriptor): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setimage-bitmapdescriptor-imagedescriptor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setimage-bitmapdescriptor-imagedescriptor</a><br/>
     *
     * @param param0 the BitmapDescriptor to use for this ground overlay
     */
    public final void setImage(org.xms.g.maps.model.BitmapDescriptor param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setImage(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))))");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setImage(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setPosition(org.xms.g.maps.model.LatLng) Sets the position of the ground overlay by changing the location of the anchor point. Preserves all other properties of the image.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setPosition(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setposition-latlng-latlng">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setposition-latlng-latlng</a><br/>
     *
     * @param param0 a LatLng that is the new location to place the anchor point
     */
    public final void setPosition(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setPosition(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setPosition(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setPositionFromBounds(org.xms.g.maps.model.LatLngBounds) Sets the position of the ground overlay by fitting it to the given LatLngBounds. This method will ignore the rotation(bearing)of the ground overlay when positioning it, but the bearing will still be used when drawing it.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setPositionFromBounds(com.google.android.gms.maps.model.LatLngBounds): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setpositionfrombounds-latlngbounds-bounds">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setpositionfrombounds-latlngbounds-bounds</a><br/>
     *
     * @param param0 a LatLngBounds in which to place the ground overlay
     */
    public final void setPositionFromBounds(org.xms.g.maps.model.LatLngBounds param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setPositionFromBounds(((com.google.android.gms.maps.model.LatLngBounds) ((param0) == null ? null : (param0.getGInstance()))))");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setPositionFromBounds(((com.google.android.gms.maps.model.LatLngBounds) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setTag(java.lang.Object) Sets the tag for the ground overlay.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setTag(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-settag-object-tag">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-settag-object-tag</a><br/>
     *
     * @param param0 if null, the tag is cleared
     */
    public final void setTag(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setTag(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setTag(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setTransparency(float) Sets the transparency of this ground overlay. See the documentation at the top of this class for more information.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setTransparency(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-settransparency-float-transparency">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-settransparency-float-transparency</a><br/>
     *
     * @param param0 a float in the range [0..1] where 0 means that the ground overlay is opaque and 1 means that the ground overlay is transparent
     */
    public final void setTransparency(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setTransparency(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setTransparency(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setVisible(boolean) Sets the visibility of this ground overlay. When not visible, a ground overlay is not drawn, but it keeps all of its other properties.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setVisible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setvisible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setvisible-boolean-visible</a><br/>
     *
     * @param param0 if true, then the ground overlay is visible; if false, it is not
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setVisible(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.setZIndex(float) Sets the zIndex of this ground overlay. See the documentation at the top of this class for more information.<br/>
     * com.google.android.gms.maps.model.GroundOverlay.setZIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setzindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/GroundOverlay#public-void-setzindex-float-zindex</a><br/>
     *
     * @param param0 the zIndex of this ground overlay
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setZIndex(param0)");
        ((com.google.android.gms.maps.model.GroundOverlay) this.getGInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.GroundOverlay.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model GroundOverlay object
     */
    public static org.xms.g.maps.model.GroundOverlay dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.GroundOverlay) param0);
    }
    
    /**
     * org.xms.g.maps.model.GroundOverlay.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.GroundOverlay;
    }
}