package org.xms.g.maps.model;

/**
 * xms An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
 * Wrapper class for com.google.android.gms.maps.model.Gap, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.Gap: An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
 */
public final class Gap extends org.xms.g.maps.model.PatternItem {
    
    /**
     * org.xms.g.maps.model.Gap.Gap(org.xms.g.utils.XBox) An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.google.android.gms.maps.model.Gap.Gap(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public Gap(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.Gap.Gap(float) An immutable class representing a gap used in the stroke pattern for a Polyline or the outline of a Polygon or Circle.<br/>
     * com.google.android.gms.maps.model.Gap.Gap(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap</a><br/>
     *
     * @param param0 Length in pixels. Negative value will be clamped to zero
     */
    public Gap(float param0) {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.Gap(param0));
    }
    
    /**
     * org.xms.g.maps.model.Gap.getLength() Length in pixels. Negative value will be clamped to zero.<br/>
     * com.google.android.gms.maps.model.Gap.length: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap#public-final-float-length">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap#public-final-float-length</a><br/>
     *
     * @return the return object is float
     */
    public float getLength() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Gap) this.getGInstance()).length");
        return ((com.google.android.gms.maps.model.Gap) this.getGInstance()).length;
    }
    
    /**
     * org.xms.g.maps.model.Gap.toString() to String.<br/>
     * com.google.android.gms.maps.model.Gap.toString(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap#public-string-tostring">https://developers.google.com/android/reference/com/google/android/gms/maps/model/Gap#public-string-tostring</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.Gap) this.getGInstance()).toString()");
        return ((com.google.android.gms.maps.model.Gap) this.getGInstance()).toString();
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.Gap.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.Gap.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model Gap object
     */
    public static org.xms.g.maps.model.Gap dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.Gap) param0);
    }
    
    /**
     * org.xms.g.maps.model.Gap.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.Gap;
    }
}