package org.xms.g.measurement;

/**
 * This class is deprecated. This receiver is no longer used for Install Referrers.<br/>
 * Wrapper class for com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver, but only the GMS API are provided.<br/>
 * com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver: This class is deprecated. This receiver is no longer used for Install Referrers.<br/>
 */
public final class AppMeasurementInstallReferrerReceiver extends android.content.BroadcastReceiver implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.AppMeasurementInstallReferrerReceiver(org.xms.g.utils.XBox) constructor of AppMeasurementInstallReferrerReceiver with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public AppMeasurementInstallReferrerReceiver(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.AppMeasurementInstallReferrerReceiver() constructor of AppMeasurementInstallReferrerReceiver.<br/>
     * com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver.AppMeasurementInstallReferrerReceiver(): <a href="https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementInstallReferrerReceiver#public-appmeasurementinstallreferrerreceiver">https://developers.google.com/android/reference/com/google/android/gms/measurement/AppMeasurementInstallReferrerReceiver#public-appmeasurementinstallreferrerreceiver</a><br/>
     *
     */
    public AppMeasurementInstallReferrerReceiver() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final android.content.BroadcastReceiver.PendingResult doGoAsync() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void doStartService(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public final void onReceive(android.content.Context param0, android.content.Intent param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.<br/>
     *
     * @param param0 the input object
     * @return casted AppMeasurementInstallReferrerReceiver object
     */
    public static org.xms.g.measurement.AppMeasurementInstallReferrerReceiver dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.measurement.AppMeasurementInstallReferrerReceiver.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}