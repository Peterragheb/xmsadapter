package org.xms.g.maps.model;

/**
 * xms Represents a building.<br/>
 * Wrapper class for com.google.android.gms.maps.model.IndoorBuilding, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.IndoorBuilding: Represents a building.<br/>
 */
public final class IndoorBuilding extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.IndoorBuilding(org.xms.g.utils.XBox) Represents a building.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.IndoorBuilding(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public IndoorBuilding(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.equals(java.lang.Object) Tests if this IndoorBuilding is equal to another.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-boolean-equals-object-other">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-boolean-equals-object-other</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.getActiveLevelIndex() Gets the index in the list returned by getLevels()of the level that is currently active in this building(default if no active level was previously set).<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.getActiveLevelIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-getactivelevelindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-getactivelevelindex</a><br/>
     *
     * @return the return object is int
     */
    public final int getActiveLevelIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getActiveLevelIndex()");
        return ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getActiveLevelIndex();
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.getDefaultLevelIndex() Gets the index in the list returned by getLevels()of the default level for this building.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.getDefaultLevelIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-getdefaultlevelindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-getdefaultlevelindex</a><br/>
     *
     * @return the return object is int
     */
    public final int getDefaultLevelIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getDefaultLevelIndex()");
        return ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getDefaultLevelIndex();
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.getLevels() Gets the levels in the building.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.getLevels(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-listindoorlevel-getlevels">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-listindoorlevel-getlevels</a><br/>
     *
     * @return the return object is java util List<IndoorLevel>
     */
    public final java.util.List<org.xms.g.maps.model.IndoorLevel> getLevels() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getLevels()");
        java.util.List gReturn = ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).getLevels();
        return ((java.util.List) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.IndoorLevel, org.xms.g.maps.model.IndoorLevel>() {
            
            public org.xms.g.maps.model.IndoorLevel apply(com.google.android.gms.maps.model.IndoorLevel param0) {
                return new org.xms.g.maps.model.IndoorLevel(new org.xms.g.utils.XBox(param0));
            }
        }));
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.isUnderground() Returns true if the building is entirely underground.<br/>
     * com.google.android.gms.maps.model.IndoorBuilding.isUnderground(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-boolean-isunderground">https://developers.google.com/android/reference/com/google/android/gms/maps/model/IndoorBuilding#public-boolean-isunderground</a><br/>
     *
     * @return the return object is boolean
     */
    public final boolean isUnderground() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).isUnderground()");
        return ((com.google.android.gms.maps.model.IndoorBuilding) this.getGInstance()).isUnderground();
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.IndoorBuilding.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model IndoorBuilding object
     */
    public static org.xms.g.maps.model.IndoorBuilding dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.IndoorBuilding) param0);
    }
    
    /**
     * org.xms.g.maps.model.IndoorBuilding.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.IndoorBuilding;
    }
}