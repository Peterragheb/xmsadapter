package org.xms.g.tasks;

/**
 * Runtime version of ExecutionException.<br/>
 * Wrapper class for com.google.android.gms.tasks.RuntimeExecutionException, but only the GMS API are provided.<br/>
 * com.google.android.gms.tasks.RuntimeExecutionException: Runtime version of ExecutionException.<br/>
 */
public class RuntimeExecutionException extends java.lang.RuntimeException implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.RuntimeExecutionException(org.xms.g.utils.XBox) constructor of RuntimeExecutionException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public RuntimeExecutionException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.RuntimeExecutionException(java.lang.Throwable) constructor of RuntimeExecutionException.<br/>
     * com.google.android.gms.tasks.RuntimeExecutionException.RuntimeExecutionException(java.lang.Throwable): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/RuntimeExecutionException#public-runtimeexecutionexception-throwable-cause">https://developers.google.com/android/reference/com/google/android/gms/tasks/RuntimeExecutionException#public-runtimeexecutionexception-throwable-cause</a><br/>
     *
     * @param param0 the cause
     */
    public RuntimeExecutionException(java.lang.Throwable param0) {
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.RuntimeExecutionException.<br/>
     *
     * @param param0 the input object
     * @return casted RuntimeExecutionException object
     */
    public static org.xms.g.tasks.RuntimeExecutionException dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.tasks.RuntimeExecutionException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}