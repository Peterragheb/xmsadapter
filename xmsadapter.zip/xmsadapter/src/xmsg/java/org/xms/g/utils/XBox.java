package org.xms.g.utils;

public class XBox {
    java.lang.Object gInst;

    public XBox(java.lang.Object gInst) {
        this.gInst = gInst;
    }

    public XBox(java.lang.Object gInst, java.lang.Object hInst) {
        this.gInst = gInst;
    }

    public Object getGInstance() {
        return gInst;
    }
}
