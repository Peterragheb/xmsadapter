package org.xms.g.maps.model;

/**
 * xms A Tile Overlay is a set of images which are displayed on top of the base map tiles.<br/>
 * Wrapper class for com.google.android.gms.maps.model.TileOverlay, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.TileOverlay: A Tile Overlay is a set of images which are displayed on top of the base map tiles. These tiles may be transparent, allowing you to add features to existing maps. A tile overlay has the following properties:.<br/>
 */
public final class TileOverlay extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.maps.model.TileOverlay.TileOverlay(org.xms.g.utils.XBox) A Tile Overlay is a set of images which are displayed on top of the base map tiles.<br/>
     * com.google.android.gms.maps.model.TileOverlay.TileOverlay(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public TileOverlay(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.clearTileCache() Clears the tile cache so that all tiles will be requested again from the TileProvider. The current tiles from this tile overlay will also be cleared from the map after calling this method. The API maintains a small in-memory cache of tiles. If you want to cache tiles for longer, you should implement an on-disk cache.<br/>
     * com.google.android.gms.maps.model.TileOverlay.clearTileCache(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-cleartilecache">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-cleartilecache</a><br/>
     *
     */
    public final void clearTileCache() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).clearTileCache()");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).clearTileCache();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.equals(java.lang.Object) Tests if this TileOverlay is equal to another.<br/>
     * com.google.android.gms.maps.model.TileOverlay.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-equals-object-other">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-equals-object-other</a><br/>
     *
     * @param param0 an Object
     * @return true if both objects are the same object, that is, this == other
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getFadeIn() Gets whether the overlay tiles should fade in.<br/>
     * com.google.android.gms.maps.model.TileOverlay.getFadeIn(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-getfadein">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-getfadein</a><br/>
     *
     * @return true if the tiles are to fade in; false if they are not
     */
    public final boolean getFadeIn() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getFadeIn()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getFadeIn();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getId() Gets this tile overlay's id.<br/>
     * com.google.android.gms.maps.model.TileOverlay.getId(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-string-getid">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-string-getid</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String getId() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getId()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getId();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getTransparency() Gets the transparency of this tile overlay.<br/>
     * com.google.android.gms.maps.model.TileOverlay.getTransparency(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-float-gettransparency">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-float-gettransparency</a><br/>
     *
     * @return the transparency of this tile overlay
     */
    public final float getTransparency() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getTransparency()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getTransparency();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.getZIndex() Gets the zIndex of this tile overlay.<br/>
     * com.google.android.gms.maps.model.TileOverlay.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-float-getzindex</a><br/>
     *
     * @return the zIndex of the tile overlay
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.TileOverlay.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.isVisible() Gets the visibility of this tile overlay. Note that this does not return whether the tile overlay is actually within the screen's viewport, but whether it will be drawn if it is contained in the screen's viewport.<br/>
     * com.google.android.gms.maps.model.TileOverlay.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-boolean-isvisible</a><br/>
     *
     * @return this tile overlay's visibility
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.remove() Removes this tile overlay from the map.<br/>
     * com.google.android.gms.maps.model.TileOverlay.remove(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-remove">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-remove</a><br/>
     *
     */
    public final void remove() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).remove()");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).remove();
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setFadeIn(boolean) Sets whether the overlay tiles should fade in.<br/>
     * com.google.android.gms.maps.model.TileOverlay.setFadeIn(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setfadein-boolean-fadein">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setfadein-boolean-fadein</a><br/>
     *
     * @param param0 true to make the tiles fade in; false to render them instantly
     */
    public final void setFadeIn(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setFadeIn(param0)");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setFadeIn(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setTransparency(float) Sets the transparency of this tile overlay. See the documentation at the top of this class for more information.<br/>
     * com.google.android.gms.maps.model.TileOverlay.setTransparency(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-settransparency-float-transparency">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-settransparency-float-transparency</a><br/>
     *
     * @param param0 a float in the range [0..1] where 0 means that the tile overlay is opaque and 1 means that the tile overlay is transparent
     */
    public final void setTransparency(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setTransparency(param0)");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setTransparency(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setVisible(boolean) Sets the visibility of this tile overlay. When not visible, a tile overlay is not drawn, but it keeps all its other properties. Tile overlays are visible by default.<br/>
     * com.google.android.gms.maps.model.TileOverlay.setVisible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setvisible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setvisible-boolean-visible</a><br/>
     *
     * @param param0 true to make this overlay visible; false to make it invisible
     */
    public final void setVisible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setVisible(param0)");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setVisible(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.setZIndex(float) Sets the zIndex of this tile overlay. See the documentation at the top of this class for more information.<br/>
     * com.google.android.gms.maps.model.TileOverlay.setZIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setzindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/TileOverlay#public-void-setzindex-float-zindex</a><br/>
     *
     * @param param0 the zIndex of this tile overlay
     */
    public final void setZIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setZIndex(param0)");
        ((com.google.android.gms.maps.model.TileOverlay) this.getGInstance()).setZIndex(param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.TileOverlay.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model TileOverlay object
     */
    public static org.xms.g.maps.model.TileOverlay dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.TileOverlay) param0);
    }
    
    /**
     * org.xms.g.maps.model.TileOverlay.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.TileOverlay;
    }
}