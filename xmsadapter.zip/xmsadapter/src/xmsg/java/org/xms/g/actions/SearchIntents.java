package org.xms.g.actions;

/**
 * Constants for intents to perform in-app search from a Search Action.<br/>
 * Wrapper class for com.google.android.gms.actions.SearchIntents, but only the GMS API are provided.<br/>
 * com.google.android.gms.actions.SearchIntents: Constants for intents to perform in-app search from a Search Action.<br/>
 */
public class SearchIntents extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.actions.SearchIntents.SearchIntents(org.xms.g.utils.XBox) constructor of with ItemListIntents XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public SearchIntents(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.actions.SearchIntents.getACTION_SEARCH() Intent action for performing an in-app search.<br/>
     * com.google.android.gms.actions.SearchIntents.ACTION_SEARCH: <a href="https://developers.google.com/android/reference/com/google/android/gms/actions/SearchIntents?hl=en#ACTION_SEARCH">https://developers.google.com/android/reference/com/google/android/gms/actions/SearchIntents?hl=en#ACTION_SEARCH</a><br/>
     *
     * @return return object is String
     */
    public static java.lang.String getACTION_SEARCH() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.actions.SearchIntents.ACTION_SEARCH");
        return com.google.android.gms.actions.SearchIntents.ACTION_SEARCH;
    }
    
    /**
     * org.xms.g.actions.SearchIntents.getEXTRA_QUERY() Intent extra specifying the text query to use as a string for ACTION_SEARCH.<br/>
     * com.google.android.gms.actions.SearchIntents.EXTRA_QUERY: <a href="https://developers.google.com/android/reference/com/google/android/gms/actions/SearchIntents?hl=en#public-static-final-string-extra_query">https://developers.google.com/android/reference/com/google/android/gms/actions/SearchIntents?hl=en#public-static-final-string-extra_query</a><br/>
     *
     * @return return object is String
     */
    public static java.lang.String getEXTRA_QUERY() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.actions.SearchIntents.EXTRA_QUERY");
        return com.google.android.gms.actions.SearchIntents.EXTRA_QUERY;
    }
    
    /**
     * org.xms.g.actions.SearchIntents.dynamicCast(java.lang.Object) dynamic cast the input object to SearchIntents.<br/>
     *
     * @param param0 the param should instanceof java.lang.Object
     * @return SearchIntents object
     */
    public static org.xms.g.actions.SearchIntents dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.actions.SearchIntents) param0);
    }
    
    /**
     * org.xms.g.actions.SearchIntents.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.actions.SearchIntents;
    }
}