package org.xms.g.maps.model;

/**
 * An immutable class that aggregates all user point of view parameters.<br/>
 * Wrapper class for com.google.android.gms.maps.model.StreetViewPanoramaOrientation, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.StreetViewPanoramaOrientation: An immutable class that aggregates all user point of view parameters.<br/>
 */
public class StreetViewPanoramaOrientation extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.CREATOR: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.StreetViewPanoramaOrientation createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.maps.model.StreetViewPanoramaOrientation gReturn = com.google.android.gms.maps.model.StreetViewPanoramaOrientation.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.StreetViewPanoramaOrientation(new org.xms.g.utils.XBox(gReturn));
        }
        
        public org.xms.g.maps.model.StreetViewPanoramaOrientation[] newArray(int param0) {
            return new org.xms.g.maps.model.StreetViewPanoramaOrientation[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.StreetViewPanoramaOrientation(org.xms.g.utils.XBox) An immutable class that aggregates all user point of view parameters.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.StreetViewPanoramaOrientation(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public StreetViewPanoramaOrientation(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.getBearing() Direction of the orientation, in degrees clockwise from north.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.bearing: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-final-float-bearing">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-final-float-bearing</a><br/>
     *
     * @return the return object is float
     */
    public float getBearing() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).bearing");
        return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).bearing;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.getTilt() The angle, in degrees, of the orientation. See tilt for details of restrictions on the range of values.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.tilt: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-final-float-tilt">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-final-float-tilt</a><br/>
     *
     * @return the return object is float
     */
    public float getTilt() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).tilt");
        return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).tilt;
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.builder() Creates a builder for a Street View panorama orientation.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-static-streetviewpanoramaorientation.builder-builder">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-static-streetviewpanoramaorientation.builder-builder</a><br/>
     *
     * @return the return object is maps model StreetViewPanoramaOrientation Builder
     */
    public static org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder builder() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder()");
        com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder gReturn = com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.builder(org.xms.g.maps.model.StreetViewPanoramaOrientation) Creates a builder for a Street View panorama orientation.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder(com.google.android.gms.maps.model.StreetViewPanoramaOrientation): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-static-streetviewpanoramaorientation.builder-builder-streetviewpanoramaorientation-orientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-static-streetviewpanoramaorientation.builder-builder-streetviewpanoramaorientation-orientation</a><br/>
     *
     * @param param0 the param should instanceof maps model StreetViewPanoramaOrientation
     * @return the return object is maps model StreetViewPanoramaOrientation Builder
     */
    public static org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder builder(org.xms.g.maps.model.StreetViewPanoramaOrientation param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder(((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder gReturn = com.google.android.gms.maps.model.StreetViewPanoramaOrientation.builder(((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.equals(java.lang.Object) equals.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-boolean-equals-object-o">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-boolean-equals-object-o</a><br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.toString() to String.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.toString(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-string-tostring">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-string-tostring</a><br/>
     *
     * @return the return object is java lang String
     */
    public java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).toString()");
        return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.writeToParcel(android.os.Parcel,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-void-writetoparcel-parcel-out,-int-flags">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation#public-void-writetoparcel-parcel-out,-int-flags</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).writeToParcel(param0, param1)");
        ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) this.getGInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaOrientation.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model StreetViewPanoramaOrientation object
     */
    public static org.xms.g.maps.model.StreetViewPanoramaOrientation dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.StreetViewPanoramaOrientation) param0);
    }
    
    /**
     * org.xms.g.maps.model.StreetViewPanoramaOrientation.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.StreetViewPanoramaOrientation;
    }
    
    /**
     * Builds Street View panorama orientations.<br/>
     * Wrapper class for com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder, but only the GMS API are provided.<br/>
     * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder: Builds Street View panorama orientations.<br/>
     */
    public static final class Builder extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.Builder(org.xms.g.utils.XBox) An immutable class that aggregates all user point of view parameters.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.Builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation</a><br/>
         *
         * @param param0 the param should instanceof utils XBox
         */
        public Builder(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.Builder() An immutable class that aggregates all user point of view parameters.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.Builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation</a><br/>
         *
         */
        public Builder() {
            super(((org.xms.g.utils.XBox) null));
            this.setGInstance(new com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder());
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.Builder(org.xms.g.maps.model.StreetViewPanoramaOrientation) An immutable class that aggregates all user point of view parameters.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.Builder(com.google.android.gms.maps.model.StreetViewPanoramaOrientation): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation</a><br/>
         *
         * @param param0 the param should instanceof maps model StreetViewPanoramaOrientation
         */
        public Builder(org.xms.g.maps.model.StreetViewPanoramaOrientation param0) {
            super(((org.xms.g.utils.XBox) null));
            this.setGInstance(new com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder(((com.google.android.gms.maps.model.StreetViewPanoramaOrientation) ((param0) == null ? null : (param0.getGInstance())))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.getBearing() getBearing.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.bearing: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-float-bearing">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-float-bearing</a><br/>
         *
         * @return the return object is float
         */
        public float getBearing() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).bearing");
            return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).bearing;
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.getTilt() tilt.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.tilt: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-float-tilt">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-float-tilt</a><br/>
         *
         * @return the return object is float
         */
        public float getTilt() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).tilt");
            return ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).tilt;
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.bearing(float) Sets the direction of the orientation, in degrees clockwise from north.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.bearing(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation.builder-bearing-float-bearing">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation.builder-bearing-float-bearing</a><br/>
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model StreetViewPanoramaOrientation Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder bearing(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).bearing(param0)");
            com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder gReturn = ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).bearing(param0);
            return ((gReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.build() Builds a StreetViewPanoramaOrientation.<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.build(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation-build">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation-build</a><br/>
         *
         * @return the return object is maps model StreetViewPanoramaOrientation
         */
        public final org.xms.g.maps.model.StreetViewPanoramaOrientation build() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).build()");
            com.google.android.gms.maps.model.StreetViewPanoramaOrientation gReturn = ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).build();
            return ((gReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.tilt(float) Sets the angle, in degrees, of the orientation This value is restricted to being between-90(directly down)and 90(directly up).<br/>
         * com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder.tilt(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation.builder-tilt-float-tilt">https://developers.google.com/android/reference/com/google/android/gms/maps/model/StreetViewPanoramaOrientation.Builder#public-streetviewpanoramaorientation.builder-tilt-float-tilt</a><br/>
         *
         * @param param0 the param should instanceof float
         * @return the return object is maps model StreetViewPanoramaOrientation Builder
         */
        public final org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder tilt(float param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).tilt(param0)");
            com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder gReturn = ((com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder) this.getGInstance()).tilt(param0);
            return ((gReturn) == null ? null : (new org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.<br/>
         *
         * @param param0 the param should instanceof java lang Object
         * @return cast maps model StreetViewPanoramaOrientation Builder object
         */
        public static org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder) param0);
        }
        
        /**
         * org.xms.g.maps.model.StreetViewPanoramaOrientation.Builder.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.StreetViewPanoramaOrientation.Builder;
        }
    }
}