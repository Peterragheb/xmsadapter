package org.xms.g.common.api;

/**
 * The main entry point for services integration.<br/>
 * Wrapper class for com.google.android.gms.common.api.GoogleApiClient, but only the GMS API are provided.<br/>
 * com.google.android.gms.common.api.GoogleApiClient: The main entry point for Google Play services integration.<br/>
 */
public abstract class ExtensionApiClient extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.ExtensionApiClient(org.xms.g.utils.XBox) constructor of ExtensionApiClient with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionApiClient(org.xms.g.utils.XBox param0) {
        super(param0);
        wrapper = true;
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.ExtensionApiClient() constructor of ExtensionApiClient.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.GoogleApiClient(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-googleapiclient">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-googleapiclient</a><br/>
     *
     */
    public ExtensionApiClient() {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new GImpl());
        wrapper = false;
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.getSIGN_IN_MODE_OPTIONAL() return the value of SIGN_IN_MODE_OPTIONAL.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.SIGN_IN_MODE_OPTIONAL(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-static-final-int-sign_in_mode_optional">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-static-final-int-sign_in_mode_optional</a><br/>
     *
     * @return Constant Value.If authenticated APIs are present they will attempt to connect, but failure of an authenticated API will not cause the GoogleApiClient connection to fail
     */
    public static int getSIGN_IN_MODE_OPTIONAL() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.getSIGN_IN_MODE_REQUIRED() return the value of SIGN_IN_MODE_REQUIRED.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.SIGN_IN_MODE_REQUIRED(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-static-final-int-sign_in_mode_required">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-static-final-int-sign_in_mode_required</a><br/>
     *
     * @return Constant Value.If a required authenticated API fails to connect, the entire GoogleApiClient will fail to connect and a failed ConnectionResult will be delivered to OnConnectionFailedListener#onConnectionFailed
     */
    public static int getSIGN_IN_MODE_REQUIRED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.blockingConnect() Connects the client to Google Play services. Blocks until the connection either succeeds or fails.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.blockingConnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect</a><br/>
     *
     * @return the result of the connection
     */
    public abstract org.xms.g.common.ConnectionResult blockingConnect();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.blockingConnect(long,java.util.concurrent.TimeUnit) Connects the client to Google Play services. Blocks until the connection either succeeds or fails, or the timeout is reached.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.blockingConnect(long,java.util.concurrent.TimeUnit): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect-long-timeout,-timeunit-unit">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect-long-timeout,-timeunit-unit</a><br/>
     *
     * @param param0 the maximum time to wait
     * @param param1 the time unit of the timeout argument
     * @return the result of the connection
     */
    public abstract org.xms.g.common.ConnectionResult blockingConnect(long param0, java.util.concurrent.TimeUnit param1);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.clearDefaultAccountAndReconnect() Clears the account selected by the user and reconnects the client asking the user to pick an account again if useDefaultAccount() was set.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.clearDefaultAccountAndReconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-pendingresultstatus-cleardefaultaccountandreconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-pendingresultstatus-cleardefaultaccountandreconnect</a><br/>
     *
     * @return the pending result is fired once the default account has been cleared, but before the client is reconnected - for that ConnectionCallbacks can be used
     */
    public abstract org.xms.g.common.api.PendingResult<org.xms.g.common.api.Status> clearDefaultAccountAndReconnect();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.connect(int) Connects the client to Google Play services using the given sign in mode.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.connect(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-void-connect-int-signinmode">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-void-connect-int-signinmode</a><br/>
     *
     * @param param0 signIn Mode
     */
    public void connect(int param0) {
        if (wrapper) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).connect(param0)");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).connect(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance())).connectCallSuper(param0)");
            ((GImpl) ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance())).connectCallSuper(param0);
        }
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.connect() Connects the client to Google Play services.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.connect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-connect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-connect</a><br/>
     *
     */
    public abstract void connect();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.disconnect() Closes the connection to Google Play services.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.disconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-disconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-disconnect</a><br/>
     *
     */
    public abstract void disconnect();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.dump(java.lang.String,java.io.FileDescriptor,java.io.PrintWriter,java.lang.String[]) Prints the GoogleApiClient's state into the given stream.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.dump(java.lang.String,java.io.FileDescriptor,java.io.PrintWriter,java.lang.String[]): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-dump-string-prefix,-filedescriptor-fd,-printwriter-writer,-string[]-args">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-dump-string-prefix,-filedescriptor-fd,-printwriter-writer,-string[]-args</a><br/>
     *
     * @param param0 Desired prefix to prepend at each line of output
     * @param param1 The raw file descriptor that the dump is being sent to
     * @param param2 The PrintWriter to use for writing the dump
     * @param param3 Additional arguments to the dump request
     */
    public abstract void dump(java.lang.String param0, java.io.FileDescriptor param1, java.io.PrintWriter param2, java.lang.String[] param3);
    
    /**
     * XMS does not provide this api.<br/>
     */
    public static void dumpAll(java.lang.String param0, java.io.FileDescriptor param1, java.io.PrintWriter param2, java.lang.String[] param3) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.getConnectionResult(org.xms.g.common.api.Api<?>) Returns the ConnectionResult for the GoogleApiClient's connection to the specified API.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.getConnectionResult(com.google.android.gms.common.api.Api<?>): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-getconnectionresult-api-api">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-getconnectionresult-api-api</a><br/>
     *
     * @param param0 The Api to retrieve the ConnectionResult of. Passing an API that was not registered with the GoogleApiClient results in an IllegalArgumentException
     * @return the ConnectionResult
     */
    public abstract org.xms.g.common.ConnectionResult getConnectionResult(org.xms.g.common.api.Api<?> param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.hasConnectedApi(org.xms.g.common.api.Api<?>) Returns whether or not this GoogleApiClient has the specified API in a connected state.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.hasConnectedApi(com.google.android.gms.common.api.Api<?>): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-hasconnectedapi-api-api">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-hasconnectedapi-api-api</a><br/>
     *
     * @param param0 The Api to test the connection of
     * @return true if or not this GoogleApiClient has the specified API in a connected state
     */
    public abstract boolean hasConnectedApi(org.xms.g.common.api.Api<?> param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.isConnected() Checks if the client is currently connected to the service, so that requests to other methods will succeed.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.isConnected(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnected">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnected</a><br/>
     *
     * @return true if the client is connected to the service
     */
    public abstract boolean isConnected();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.isConnecting() Checks if the client is attempting to connect to the service.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.isConnecting(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnecting">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnecting</a><br/>
     *
     * @return true if the client is attempting to connect to the service
     */
    public abstract boolean isConnecting();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.isConnectionCallbacksRegistered(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Returns true if the specified listener is currently registered to receive connection events.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.isConnectionCallbacksRegistered(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectioncallbacksregistered-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectioncallbacksregistered-googleapiclient.connectioncallbacks-listener</a><br/>
     *
     * @param param0 The listener to check for
     * @return true if the specified listener is currently registered to receive connection events
     */
    public abstract boolean isConnectionCallbacksRegistered(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.isConnectionFailedListenerRegistered(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Returns true if the specified listener is currently registered to receive connection failed events.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.isConnectionFailedListenerRegistered(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectionfailedlistenerregistered-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectionfailedlistenerregistered-googleapiclient.onconnectionfailedlistener-listener</a><br/>
     *
     * @param param0 The listener to check for
     * @return true if the specified listener is currently registered to receive connection failed events
     */
    public abstract boolean isConnectionFailedListenerRegistered(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.reconnect() Closes the current connection to Google Play services and creates a new connection.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.reconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-reconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-reconnect</a><br/>
     *
     */
    public abstract void reconnect();
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.registerConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Registers a listener to receive connection events from this GoogleApiClient.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.registerConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectioncallbacks-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectioncallbacks-googleapiclient.connectioncallbacks-listener</a><br/>
     *
     * @param param0 the listener where the results of the asynchronous connect() call are delivered
     */
    public abstract void registerConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.registerConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Registers a listener to receive connection failed events from this GoogleApiClient.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.registerConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener</a><br/>
     *
     * @param param0 the listener where the results of the asynchronous connect() call are delivered
     */
    public abstract void registerConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.stopAutoManage(androidx.fragment.app.FragmentActivity) Disconnects the client and stops automatic lifecycle management.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.stopAutoManage(androidx.fragment.app.FragmentActivity): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-stopautomanage-fragmentactivity-lifecycleactivity">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-stopautomanage-fragmentactivity-lifecycleactivity</a><br/>
     *
     * @param param0 the activity managing the client's lifecycle
     * @throws java.lang.IllegalStateException if called from outside of the main thread
     */
    public abstract void stopAutoManage(androidx.fragment.app.FragmentActivity param0) throws java.lang.IllegalStateException;
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.unregisterConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Removes a connection listener from this GoogleApiClientbr/> Support running environments including both HMS and GMS which are chosen by users.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.unregisterConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectioncallbacks-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectioncallbacks-googleapiclient.connectioncallbacks-listener</a><br/>
     *
     * @param param0 the listener to unregister
     */
    public abstract void unregisterConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.unregisterConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Removes a connection failed listener from the GoogleApiClient.<br/>
     * com.google.android.gms.common.api.GoogleApiClien.unregisterConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener</a><br/>
     *
     * @param param0 the listener to unregister
     */
    public abstract void unregisterConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0);
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ExtensionApiClient.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionApiClient object
     */
    public static org.xms.g.common.api.ExtensionApiClient dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.api.ExtensionApiClient) param0);
    }
    
    /**
     * org.xms.g.common.api.ExtensionApiClient.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.GoogleApiClient;
    }
    
    private class GImpl extends com.google.android.gms.common.api.GoogleApiClient {
        
        public void connect(int param0) {
            org.xms.g.common.api.ExtensionApiClient.this.connect(param0);
        }
        
        public void connectCallSuper(int param0) {
            super.connect(param0);
        }
        
        public com.google.android.gms.common.ConnectionResult blockingConnect() {
            org.xms.g.common.ConnectionResult xResult = org.xms.g.common.api.ExtensionApiClient.this.blockingConnect();
            return ((com.google.android.gms.common.ConnectionResult) ((xResult) == null ? null : (xResult.getGInstance())));
        }
        
        public com.google.android.gms.common.ConnectionResult blockingConnect(long param0, java.util.concurrent.TimeUnit param1) {
            org.xms.g.common.ConnectionResult xResult = org.xms.g.common.api.ExtensionApiClient.this.blockingConnect(param0, param1);
            return ((com.google.android.gms.common.ConnectionResult) ((xResult) == null ? null : (xResult.getGInstance())));
        }
        
        public com.google.android.gms.common.api.PendingResult<com.google.android.gms.common.api.Status> clearDefaultAccountAndReconnect() {
            org.xms.g.common.api.PendingResult xResult = org.xms.g.common.api.ExtensionApiClient.this.clearDefaultAccountAndReconnect();
            return ((com.google.android.gms.common.api.PendingResult) ((xResult) == null ? null : (xResult.getGInstance())));
        }
        
        public void connect() {
            org.xms.g.common.api.ExtensionApiClient.this.connect();
        }
        
        public void disconnect() {
            org.xms.g.common.api.ExtensionApiClient.this.disconnect();
        }
        
        public void dump(java.lang.String param0, java.io.FileDescriptor param1, java.io.PrintWriter param2, java.lang.String[] param3) {
            org.xms.g.common.api.ExtensionApiClient.this.dump(param0, param1, param2, param3);
        }
        
        public com.google.android.gms.common.ConnectionResult getConnectionResult(com.google.android.gms.common.api.Api<?> param0) {
            org.xms.g.common.ConnectionResult xResult = org.xms.g.common.api.ExtensionApiClient.this.getConnectionResult(((param0) == null ? null : (new org.xms.g.common.api.Api(new org.xms.g.utils.XBox(param0)))));
            return ((com.google.android.gms.common.ConnectionResult) ((xResult) == null ? null : (xResult.getGInstance())));
        }
        
        public boolean hasConnectedApi(com.google.android.gms.common.api.Api<?> param0) {
            return org.xms.g.common.api.ExtensionApiClient.this.hasConnectedApi(((param0) == null ? null : (new org.xms.g.common.api.Api(new org.xms.g.utils.XBox(param0)))));
        }
        
        public boolean isConnected() {
            return org.xms.g.common.api.ExtensionApiClient.this.isConnected();
        }
        
        public boolean isConnecting() {
            return org.xms.g.common.api.ExtensionApiClient.this.isConnecting();
        }
        
        public boolean isConnectionCallbacksRegistered(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks param0) {
            return org.xms.g.common.api.ExtensionApiClient.this.isConnectionCallbacksRegistered(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public boolean isConnectionFailedListenerRegistered(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener param0) {
            return org.xms.g.common.api.ExtensionApiClient.this.isConnectionFailedListenerRegistered(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void reconnect() {
            org.xms.g.common.api.ExtensionApiClient.this.reconnect();
        }
        
        public void registerConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks param0) {
            org.xms.g.common.api.ExtensionApiClient.this.registerConnectionCallbacks(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void registerConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener param0) {
            org.xms.g.common.api.ExtensionApiClient.this.registerConnectionFailedListener(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void stopAutoManage(androidx.fragment.app.FragmentActivity param0) throws java.lang.IllegalStateException {
            org.xms.g.common.api.ExtensionApiClient.this.stopAutoManage(param0);
        }
        
        public void unregisterConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks param0) {
            org.xms.g.common.api.ExtensionApiClient.this.unregisterConnectionCallbacks(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public void unregisterConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener param0) {
            org.xms.g.common.api.ExtensionApiClient.this.unregisterConnectionFailedListener(((param0) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.XImpl(new org.xms.g.utils.XBox(param0)))));
        }
        
        public GImpl() {
            super();
        }
    }
    
    /**
     * Wrapper class of ExtensionApiClient which is the main entry point for services integration.<br/>
     * Wrapper class for com.google.android.gms.common.api.GoogleApiClient, but only the GMS API are provided.<br/>
     * com.google.android.gms.common.api.GoogleApiClient: The main entry point for Google Play services integration.<br/>
     */
    public static class XImpl extends org.xms.g.common.api.ExtensionApiClient {
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.blockingConnect() Connects the client to Google Play services. Blocks until the connection either succeeds or fails.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.blockingConnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect</a><br/>
         *
         * @return the result of the connection
         */
        public org.xms.g.common.ConnectionResult blockingConnect() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).blockingConnect()");
            com.google.android.gms.common.ConnectionResult gReturn = ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).blockingConnect();
            return ((gReturn) == null ? null : (new org.xms.g.common.ConnectionResult(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.blockingConnect(long,java.util.concurrent.TimeUnit) Connects the client to Google Play services. Blocks until the connection either succeeds or fails, or the timeout is reached.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.blockingConnect(long,java.util.concurrent.TimeUnit): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect-long-timeout,-timeunit-unit">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-blockingconnect-long-timeout,-timeunit-unit</a><br/>
         *
         * @param param0 the maximum time to wait
         * @param param1 the time unit of the timeout argument
         * @return the result of the connection
         */
        public org.xms.g.common.ConnectionResult blockingConnect(long param0, java.util.concurrent.TimeUnit param1) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).blockingConnect(param0, param1)");
            com.google.android.gms.common.ConnectionResult gReturn = ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).blockingConnect(param0, param1);
            return ((gReturn) == null ? null : (new org.xms.g.common.ConnectionResult(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.clearDefaultAccountAndReconnect() Clears the account selected by the user and reconnects the client asking the user to pick an account again if useDefaultAccount() was set.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.clearDefaultAccountAndReconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-pendingresultstatus-cleardefaultaccountandreconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-pendingresultstatus-cleardefaultaccountandreconnect</a><br/>
         *
         * @return the pending result is fired once the default account has been cleared, but before the client is reconnected for that ConnectionCallbacks can be used
         */
        public org.xms.g.common.api.PendingResult<org.xms.g.common.api.Status> clearDefaultAccountAndReconnect() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).clearDefaultAccountAndReconnect()");
            com.google.android.gms.common.api.PendingResult gReturn = ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).clearDefaultAccountAndReconnect();
            return ((gReturn) == null ? null : (new org.xms.g.common.api.PendingResult.XImpl(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.connect() Connects the client to Google Play services.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.connect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-connect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-connect</a><br/>
         *
         */
        public void connect() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).connect()");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).connect();
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.disconnect() Closes the connection to Google Play services.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.disconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-disconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-disconnect</a><br/>
         *
         */
        public void disconnect() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).disconnect()");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).disconnect();
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.dump(java.lang.String,java.io.FileDescriptor,java.io.PrintWriter,java.lang.String[]) Prints the GoogleApiClient's state into the given stream.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.dump(java.lang.String,java.io.FileDescriptor,java.io.PrintWriter,java.lang.String[]): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-dump-string-prefix,-filedescriptor-fd,-printwriter-writer,-string[]-args">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-dump-string-prefix,-filedescriptor-fd,-printwriter-writer,-string[]-args</a><br/>
         *
         * @param param0 Desired prefix to prepend at each line of output
         * @param param1 The raw file descriptor that the dump is being sent to
         * @param param2 The PrintWriter to use for writing the dump
         * @param param3 Additional arguments to the dump request
         */
        public void dump(java.lang.String param0, java.io.FileDescriptor param1, java.io.PrintWriter param2, java.lang.String[] param3) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).dump(param0, param1, param2, param3)");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).dump(param0, param1, param2, param3);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.getConnectionResult(org.xms.g.common.api.Api<?>) Returns the ConnectionResult for the GoogleApiClient's connection to the specified API.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.getConnectionResult(com.google.android.gms.common.api.Api<?>): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-getconnectionresult-api-api">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-connectionresult-getconnectionresult-api-api</a><br/>
         *
         * @param param0 The Api to retrieve the ConnectionResult of. Passing an API that was not registered with the GoogleApiClient results in an IllegalArgumentException
         * @return org.xms.g.common.ConnectionResult the ConnectionResult instance
         */
        public org.xms.g.common.ConnectionResult getConnectionResult(org.xms.g.common.api.Api<?> param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).getConnectionResult(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))))");
            com.google.android.gms.common.ConnectionResult gReturn = ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).getConnectionResult(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.common.ConnectionResult(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.hasConnectedApi(org.xms.g.common.api.Api<?>) Returns whether or not this GoogleApiClient has the specified API in a connected state.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.hasConnectedApi(com.google.android.gms.common.api.Api<?>): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-hasconnectedapi-api-api">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-hasconnectedapi-api-api</a><br/>
         *
         * @param param0 The Api to test the connection of
         * @return true if or not this GoogleApiClient has the specified API in a connected state
         */
        public boolean hasConnectedApi(org.xms.g.common.api.Api<?> param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).hasConnectedApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))))");
            return ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).hasConnectedApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.isConnected() Checks if the client is currently connected to the service, so that requests to other methods will succeed.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.isConnected(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnected">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnected</a><br/>
         *
         * @return true if the client is connected to the service
         */
        public boolean isConnected() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnected()");
            return ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnected();
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.isConnecting() Checks if the client is attempting to connect to the service.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.isConnecting(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnecting">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnecting</a><br/>
         *
         * @return true if the client is attempting to connect to the service
         */
        public boolean isConnecting() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnecting()");
            return ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnecting();
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.isConnectionCallbacksRegistered(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Returns true if the specified listener is currently registered to receive connection events.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.isConnectionCallbacksRegistered(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectioncallbacksregistered-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectioncallbacksregistered-googleapiclient.connectioncallbacks-listener</a><br/>
         *
         * @param param0 The listener to check for
         * @return true if the specified listener is currently registered to receive connection events
         */
        public boolean isConnectionCallbacksRegistered(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnectionCallbacksRegistered(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())))");
            return ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnectionCallbacksRegistered(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.isConnectionFailedListenerRegistered(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Returns true if the specified listener is currently registered to receive connection failed events.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.isConnectionFailedListenerRegistered(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectionfailedlistenerregistered-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-boolean-isconnectionfailedlistenerregistered-googleapiclient.onconnectionfailedlistener-listener</a><br/>
         *
         * @param param0 The listener to check for
         * @return true if the specified listener is currently registered to receive connection failed events
         */
        public boolean isConnectionFailedListenerRegistered(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnectionFailedListenerRegistered(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())))");
            return ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).isConnectionFailedListenerRegistered(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.reconnect() Closes the current connection to Google Play services and creates a new connection.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.reconnect(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-reconnect">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-reconnect</a><br/>
         *
         */
        public void reconnect() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).reconnect()");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).reconnect();
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.registerConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Registers a listener to receive connection events from this GoogleApiClient.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.registerConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectioncallbacks-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectioncallbacks-googleapiclient.connectioncallbacks-listener</a><br/>
         *
         * @param param0 the listener where the results of the asynchronous connect() call are delivered
         */
        public void registerConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).registerConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())))");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).registerConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.registerConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Registers a listener to receive connection failed events from this GoogleApiClient.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.registerConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-registerconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener</a><br/>
         *
         * @param param0 the listener where the results of the asynchronous connect() call are delivered
         */
        public void registerConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).registerConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())))");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).registerConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.stopAutoManage(androidx.fragment.app.FragmentActivity) Disconnects the client and stops automatic lifecycle management.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.stopAutoManage(androidx.fragment.app.FragmentActivity): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-stopautomanage-fragmentactivity-lifecycleactivity">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-stopautomanage-fragmentactivity-lifecycleactivity</a><br/>
         *
         * @param param0 the activity managing the client's lifecycle
         * @throws java.lang.IllegalStateException if called from outside of the main thread
         */
        public void stopAutoManage(androidx.fragment.app.FragmentActivity param0) throws java.lang.IllegalStateException {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).stopAutoManage(param0)");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).stopAutoManage(param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.unregisterConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Removes a connection listener from this GoogleApiClientbr/> Support running environments including both HMS and GMS which are chosen by users.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.unregisterConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectioncallbacks-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectioncallbacks-googleapiclient.connectioncallbacks-listener</a><br/>
         *
         * @param param0 the listener to unregister
         */
        public void unregisterConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).unregisterConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())))");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).unregisterConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.XImpl.unregisterConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Removes a connection failed listener from the GoogleApiClient.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.unregisterConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient#public-abstract-void-unregisterconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener</a><br/>
         *
         * @param param0 the listener to unregister
         */
        public void unregisterConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).unregisterConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())))");
            ((com.google.android.gms.common.api.GoogleApiClient) this.getGInstance()).unregisterConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())));
        }
    }
    
    /**
     * Wrapper class of Builder to configure a ExtensionApiClient.<br/>
     * Wrapper class for com.google.android.gms.common.api.GoogleApiClient.Builder, but only the GMS API are provided.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.Builder: Builder to configure a GoogleApiClient.<br/>
     */
    public static final class Builder extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.Builder(org.xms.g.utils.XBox) constructor of Builder with XBox.<br/>
         *
         * @param param0 the wrapper of xms instance
         */
        public Builder(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.Builder(android.content.Context) Builder to help construct the GoogleApiClient object.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.Builder(android.content.Context): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-context-context">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-context-context</a><br/>
         *
         * @param param0 The context to use for the connection
         */
        public Builder(android.content.Context param0) {
            super(((org.xms.g.utils.XBox) null));
            this.setGInstance(new com.google.android.gms.common.api.GoogleApiClient.Builder(param0));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.Builder(android.content.Context,org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks,org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Builder to help construct the GoogleApiClient object.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.Builder(android.content.Context,com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks,com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-context-context,-googleapiclient.connectioncallbacks-connectedlistener,-googleapiclient.onconnectionfailedlistener-connectionfailedlistener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-context-context,-googleapiclient.connectioncallbacks-connectedlistener,-googleapiclient.onconnectionfailedlistener-connectionfailedlistener</a><br/>
         *
         * @param param0 The context to use for the connection
         * @param param1 The listener where the results of the asynchronous connect() call are delivered
         * @param param2 The listener which will be notified if the connection attempt fails
         */
        public Builder(android.content.Context param0, org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param1, org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param2) {
            super(((org.xms.g.utils.XBox) null));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addApi(org.xms.g.common.api.Api<XO>,XO) Specify which Apis are requested by your app. See Api for more information.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addApi(com.google.android.gms.common.api.Api<O>,O): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapi-apio-api,-o-options">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapi-apio-api,-o-options</a><br/>
         *
         * @param param0 The Api requested by your app
         * @param param1 Any additional parameters required for the specific AP
         * @return the Builder
         */
        public final <XO extends org.xms.g.common.api.Api.ApiOptions.HasOptions> org.xms.g.common.api.ExtensionApiClient.Builder addApi(org.xms.g.common.api.Api<XO> param0, XO param1) {
            com.google.android.gms.common.api.Api.ApiOptions.HasOptions gObj1 = ((com.google.android.gms.common.api.Api.ApiOptions.HasOptions) org.xms.g.utils.Utils.getInstanceInInterface(param1, false));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), gObj1)");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), gObj1);
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addApi(org.xms.g.common.api.Api<? extends org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions>) Specify which Apis are requested by your app. See Api for more information.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addApi(com.google.android.gms.common.api.Api<? extends com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions>): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapi-api-extends-api.apioptions.notrequiredoptions-api">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapi-api-extends-api.apioptions.notrequiredoptions-api</a><br/>
         *
         * @param param0 The Api requested by your app
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder addApi(org.xms.g.common.api.Api<? extends org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions> param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApi(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        public final <XO extends org.xms.g.common.api.Api.ApiOptions.HasOptions> org.xms.g.common.api.ExtensionApiClient.Builder addApiIfAvailable(org.xms.g.common.api.Api<XO> param0, XO param1, org.xms.g.common.api.Scope... param2) {
            com.google.android.gms.common.api.Api.ApiOptions.HasOptions gObj1 = ((com.google.android.gms.common.api.Api.ApiOptions.HasOptions) org.xms.g.utils.Utils.getInstanceInInterface(param1, false));
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApiIfAvailable(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), gObj1, ((com.google.android.gms.common.api.Scope[]) org.xms.g.utils.Utils.genericArrayCopy(param2, com.google.android.gms.common.api.Scope.class, x -> (com.google.android.gms.common.api.Scope)x.getGInstance())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApiIfAvailable(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), gObj1, ((com.google.android.gms.common.api.Scope[]) org.xms.g.utils.Utils.genericArrayCopy(param2, com.google.android.gms.common.api.Scope.class, x -> (com.google.android.gms.common.api.Scope)x.getGInstance())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addApiIfAvailable(org.xms.g.common.api.Api<? extends org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions>,org.xms.g.common.api.Scope[]) Specify which Apis should attempt to connect, but are not strictly required for your app.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addApiIfAvailable(com.google.android.gms.common.api.Api<? extends com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions>,com.google.android.gms.common.api.Scope[]): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapiifavailable-api-extends-api.apioptions.notrequiredoptions-api,-scope...-scopes">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addapiifavailable-api-extends-api.apioptions.notrequiredoptions-api,-scope...-scopes</a><br/>
         *
         * @param param0 The Api requested by your app
         * @param param1 Scopes required by this API
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder addApiIfAvailable(org.xms.g.common.api.Api<? extends org.xms.g.common.api.Api.ApiOptions.NotRequiredOptions> param0, org.xms.g.common.api.Scope[] param1) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApiIfAvailable(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.common.api.Scope[]) org.xms.g.utils.Utils.genericArrayCopy(param1, com.google.android.gms.common.api.Scope.class, x -> (com.google.android.gms.common.api.Scope)x.getGInstance())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addApiIfAvailable(((com.google.android.gms.common.api.Api) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.common.api.Scope[]) org.xms.g.utils.Utils.genericArrayCopy(param1, com.google.android.gms.common.api.Scope.class, x -> (com.google.android.gms.common.api.Scope)x.getGInstance())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) Registers a listener to receive connection events from this GoogleApiClient.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addConnectionCallbacks(com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addconnectioncallbacks-googleapiclient.connectioncallbacks-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addconnectioncallbacks-googleapiclient.connectioncallbacks-listener</a><br/>
         *
         * @param param0 the listener where the results of the asynchronous connect() call are delivered
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder addConnectionCallbacks(org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addConnectionCallbacks(((param0) == null ? null : (param0.getGInstanceConnectionCallbacks())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addOnConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Adds a listener to register to receive connection failed events from this GoogleApiClient.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addOnConnectionFailedListener(com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addonconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addonconnectionfailedlistener-googleapiclient.onconnectionfailedlistener-listener</a><br/>
         *
         * @param param0 the listener where the results of the asynchronous connect() call are delivered
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder addOnConnectionFailedListener(org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addOnConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addOnConnectionFailedListener(((param0) == null ? null : (param0.getGInstanceOnConnectionFailedListener())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.addScope(org.xms.g.common.api.Scope) Specify the OAuth 2.0 scopes requested by your app.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.addScope(com.google.android.gms.common.api.Scope): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addscope-scope-scope">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-addscope-scope-scope</a><br/>
         *
         * @param param0 The OAuth 2.0 scopes requested by your app
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder addScope(org.xms.g.common.api.Scope param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addScope(((com.google.android.gms.common.api.Scope) ((param0) == null ? null : (param0.getGInstance()))))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).addScope(((com.google.android.gms.common.api.Scope) ((param0) == null ? null : (param0.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.build() Builds a new GoogleApiClient object for communicating with the Google APIs.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.build(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient-build">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient-build</a><br/>
         *
         * @return The GoogleApiClient object
         */
        public final org.xms.g.common.api.ExtensionApiClient build() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).build()");
            com.google.android.gms.common.api.GoogleApiClient gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).build();
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.XImpl(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.enableAutoManage(androidx.fragment.app.FragmentActivity,org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Enables automatic lifecycle management in a support library FragmentActivity that connects the client in onStart() and disconnects it in onStop().<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.enableAutoManage(androidx.fragment.app.FragmentActivity,com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-enableautomanage-fragmentactivity-fragmentactivity,-googleapiclient.onconnectionfailedlistener-unresolvedconnectionfailedlistener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-enableautomanage-fragmentactivity-fragmentactivity,-googleapiclient.onconnectionfailedlistener-unresolvedconnectionfailedlistener</a><br/>
         *
         * @param param0 The activity that uses the GoogleApiClient. For lifecycle management to work correctly the activity must call its parent's onActivityResult(int, int, android.content.Intent)
         * @param param1 Called if the connection failed and there was no resolution or the user chose not to complete the provided resolution. If this listener is called, the client will no longer be auto-managed, and a new instance must be built. In the event that the user chooses not to complete a resolution, the ConnectionResult will have a status code of CANCELED
         * @throws java.lang.NullPointerException if fragmentActivity is null
         * @throws java.lang.IllegalStateException if another GoogleApiClient is already being auto-managed with the default clientId
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder enableAutoManage(androidx.fragment.app.FragmentActivity param0, org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param1) throws java.lang.NullPointerException, java.lang.IllegalStateException {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).enableAutoManage(param0, ((param1) == null ? null : (param1.getGInstanceOnConnectionFailedListener())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).enableAutoManage(param0, ((param1) == null ? null : (param1.getGInstanceOnConnectionFailedListener())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.enableAutoManage(androidx.fragment.app.FragmentActivity,int,org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) Enables automatic lifecycle management in a support library FragmentActivity that connects the client in onStart() and disconnects it in onStop().<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.enableAutoManage(androidx.fragment.app.FragmentActivity,int,com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-enableautomanage-fragmentactivity-fragmentactivity,-int-clientid,-googleapiclient.onconnectionfailedlistener-unresolvedconnectionfailedlistener">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-enableautomanage-fragmentactivity-fragmentactivity,-int-clientid,-googleapiclient.onconnectionfailedlistener-unresolvedconnectionfailedlistener</a><br/>
         *
         * @param param0 The activity that uses the GoogleApiClient. For lifecycle management to work correctly the activity must call its parent's onActivityResult(int, int, android.content.Intent)
         * @param param1 A non-negative identifier for this client. At any given time, only one auto-managed client is allowed per id. To reuse an id you must first call stopAutoManage(FragmentActivity) on the previous client
         * @param param2 The listener instance
         * @throws java.lang.NullPointerException if fragmentActivity is null
         * @throws java.lang.IllegalArgumentException if clientId is negative
         * @throws java.lang.IllegalStateException if clientId is already being auto-managed
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder enableAutoManage(androidx.fragment.app.FragmentActivity param0, int param1, org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener param2) throws java.lang.NullPointerException, java.lang.IllegalArgumentException, java.lang.IllegalStateException {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).enableAutoManage(param0, param1, ((param2) == null ? null : (param2.getGInstanceOnConnectionFailedListener())))");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).enableAutoManage(param0, param1, ((param2) == null ? null : (param2.getGInstanceOnConnectionFailedListener())));
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.setAccountName(java.lang.String) Specify an account name on the device that should be used.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.setAccountName(java.lang.String): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setaccountname-string-accountname">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setaccountname-string-accountname</a><br/>
         *
         * @param param0 The account name on the device that should be used by GoogleApiClient
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder setAccountName(java.lang.String param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setAccountName(param0)");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setAccountName(param0);
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.setGravityForPopups(int) Specifies the part of the screen at which games service popups (for example, "welcome back" or "achievement unlocked" popups) will be displayed using gravity.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.setGravityForPopups(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setgravityforpopups-int-gravityforpopups">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setgravityforpopups-int-gravityforpopups</a><br/>
         *
         * @param param0 The gravity which controls the placement of games service popups
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder setGravityForPopups(int param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setGravityForPopups(param0)");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setGravityForPopups(param0);
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.setHandler(android.os.Handler) Sets a Handler to indicate which thread to use when invoking callbacks. Will not be used directly to handle callbacks. If this is not called then the application's main thread will be used.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.setHandler(android.os.Handler): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-sethandler-handler-handler">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-sethandler-handler-handler</a><br/>
         *
         * @param param0 A Handler instance
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder setHandler(android.os.Handler param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setHandler(param0)");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setHandler(param0);
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.setViewForPopups(android.view.View) Sets the View to use as a content view for popups.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.setViewForPopups(android.view.View): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setviewforpopups-view-viewforpopups">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-setviewforpopups-view-viewforpopups</a><br/>
         *
         * @param param0 The view to use as a content view for popups. View cannot be null
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder setViewForPopups(android.view.View param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setViewForPopups(param0)");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).setViewForPopups(param0);
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.useDefaultAccount() Specify that the default account should be used when connecting to services.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.Builder.useDefaultAccount(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-usedefaultaccount">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.Builder#public-googleapiclient.builder-usedefaultaccount</a><br/>
         *
         * @return the Builder
         */
        public final org.xms.g.common.api.ExtensionApiClient.Builder useDefaultAccount() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).useDefaultAccount()");
            com.google.android.gms.common.api.GoogleApiClient.Builder gReturn = ((com.google.android.gms.common.api.GoogleApiClient.Builder) this.getGInstance()).useDefaultAccount();
            return ((gReturn) == null ? null : (new org.xms.g.common.api.ExtensionApiClient.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ExtensionApiClient.Builder.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionApiClient.Builder object
         */
        public static org.xms.g.common.api.ExtensionApiClient.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.common.api.ExtensionApiClient.Builder) param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.Builder.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.GoogleApiClient.Builder;
        }
    }
    
    /**
     * Provides callbacks that are called when the client is connected or disconnected from the service.<br/>
     * Wrapper class for com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks, but only the GMS API are provided.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks: Provides callbacks that are called when the client is connected or disconnected from the service.<br/>
     */
    public static interface ConnectionCallbacks extends org.xms.g.utils.XInterface {
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.getCAUSE_NETWORK_LOST() return the value of CAUSE_NETWORK_LOST.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_NETWORK_LOST: <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.ConnectionCallbacks#public-static-final-int-cause_network_lost">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.ConnectionCallbacks#public-static-final-int-cause_network_lost</a><br/>
         *
         * @return Constant Value.A suspension cause informing you that a peer device connection was lost
         */
        public static int getCAUSE_NETWORK_LOST() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_NETWORK_LOST");
            return com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_NETWORK_LOST;
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.getCAUSE_SERVICE_DISCONNECTED() return the value of CAUSE_SERVICE_DISCONNECTED.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_SERVICE_DISCONNECTED: <a href="https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.ConnectionCallbacks#public-static-final-int-cause_service_disconnected">https://developers.google.com/android/reference/com/google/android/gms/common/api/GoogleApiClient.ConnectionCallbacks#public-static-final-int-cause_service_disconnected</a><br/>
         *
         * @return Constant Value. A suspension cause informing that the service has been killed
         */
        public static int getCAUSE_SERVICE_DISCONNECTED() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_SERVICE_DISCONNECTED");
            return com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.CAUSE_SERVICE_DISCONNECTED;
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.onConnected(android.os.Bundle) Called when attempt to connect the client to the service.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.onConnected(android.os.Bundle)
         *
         * @param param0 Bundle instance
         */
        public void onConnected(android.os.Bundle param0);
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.onConnectionSuspended(int) Called when connection with the client is Suspended.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.onConnectionSuspended(int)
         *
         * @param param0 the value about connection
         */
        public void onConnectionSuspended(int param0);
        
        default java.lang.Object getZInstanceConnectionCallbacks() {
            return getGInstanceConnectionCallbacks();
        }
        
        default com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks getGInstanceConnectionCallbacks() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks() {
                
                public void onConnected(android.os.Bundle param0) {
                    org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.this.onConnected(param0);
                }
                
                public void onConnectionSuspended(int param0) {
                    org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.this.onConnectionSuspended(param0);
                }
            };
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionApiClient.ConnectionCallbacks object
         */
        public static org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks) param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
            }
            return param0 instanceof org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks;
        }
        
        /**
         * Wrapper class of ConnectionCallbacks which provides callbacks that are called when the client is connected or disconnected from the service.<br/>
         * Wrapper class for com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks: Provides callbacks that are called when the client is connected or disconnected from the service.<br/>
         */
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks {
            
            /**
             * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
             *
             * @param param0 the wrapper of xms instance
             */
            public XImpl(org.xms.g.utils.XBox param0) {
                super(param0);
            }
            
            /**
             * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl.onConnected(android.os.Bundle) Called when attempt to connect the client to the service.<br/>
             * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.onConnected(android.os.Bundle)
             *
             * @param param0 Bundle instance
             */
            public void onConnected(android.os.Bundle param0) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) this.getGInstance()).onConnected(param0)");
                ((com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) this.getGInstance()).onConnected(param0);
            }
            
            /**
             * org.xms.g.common.api.ExtensionApiClient.ConnectionCallbacks.XImpl.onConnectionSuspended(int) Called when connection with the client is Suspended.<br/>
             * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks.onConnectionSuspended(int)
             *
             * @param param0 the value about connection
             */
            public void onConnectionSuspended(int param0) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) this.getGInstance()).onConnectionSuspended(param0)");
                ((com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) this.getGInstance()).onConnectionSuspended(param0);
            }
        }
    }
    
    /**
     * Provides callbacks for scenarios that result in a failed attempt to connect the client to the service.<br/>
     * Wrapper class for com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener, but only the GMS API are provided.<br/>
     * com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener: Provides callbacks for scenarios that result in a failed attempt to connect the client to the service.<br/>
     */
    public static interface OnConnectionFailedListener extends org.xms.g.utils.XInterface {
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.onConnectionFailed(org.xms.g.common.ConnectionResult) Called when connect with client is failed.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener(com.google.android.gms.common.ConnectionResult)
         *
         * @param param0 ConnectionResult instance
         */
        public void onConnectionFailed(org.xms.g.common.ConnectionResult param0);
        
        default java.lang.Object getZInstanceOnConnectionFailedListener() {
            return getGInstanceOnConnectionFailedListener();
        }
        
        default com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener getGInstanceOnConnectionFailedListener() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener() {
                
                public void onConnectionFailed(com.google.android.gms.common.ConnectionResult param0) {
                    org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.this.onConnectionFailed(((param0) == null ? null : (new org.xms.g.common.ConnectionResult(new org.xms.g.utils.XBox(param0)))));
                }
            };
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.<br/>
         *
         * @param param0 the input object
         * @return casted ExtensionApiClient.OnConnectionFailedListener object
         */
        public static org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener) param0);
        }
        
        /**
         * org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
            }
            return param0 instanceof org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener;
        }
        
        /**
         * Wrapper class of OnConnectionFailedListener which provides callbacks for scenarios that result in a failed attempt to connect the client to the service.<br/>
         * Wrapper class for com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener, but only the GMS API are provided.<br/>
         * com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener: Provides callbacks for scenarios that result in a failed attempt to connect the client to the service.<br/>
         */
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener {
            
            /**
             * org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl with XBox.<br/>
             *
             * @param param0 the wrapper of xms instance
             */
            public XImpl(org.xms.g.utils.XBox param0) {
                super(param0);
            }
            
            /**
             * org.xms.g.common.api.ExtensionApiClient.OnConnectionFailedListener.XImpl.onConnectionFailed(org.xms.g.common.ConnectionResult) Called when connect with client is failed.<br/>
             * com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener.onConnectionFailed(com.google.android.gms.common.ConnectionResult)
             *
             * @param param0 ConnectionResult instance
             */
            public void onConnectionFailed(org.xms.g.common.ConnectionResult param0) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener) this.getGInstance()).onConnectionFailed(((com.google.android.gms.common.ConnectionResult) ((param0) == null ? null : (param0.getGInstance()))))");
                ((com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener) this.getGInstance()).onConnectionFailed(((com.google.android.gms.common.ConnectionResult) ((param0) == null ? null : (param0.getGInstance()))));
            }
        }
    }
}