package org.xms.g.tasks;

/**
 * Provides the ability to create Task-based APIs.<br/>
 * Wrapper class for com.google.android.gms.tasks.TaskCompletionSource<TResult>, but only the GMS API are provided.<br/>
 * com.google.android.gms.tasks.TaskCompletionSource<TResult>: Provides the ability to create Task-based APIs.<br/>
 */
public class TaskCompletionSource<XTResult> extends org.xms.g.utils.XObject {
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.TaskCompletionSource(org.xms.g.utils.XBox) constructor of TaskCompletionSource with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public TaskCompletionSource(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.getTask() Returns the Task.<br/>
     * com.google.android.gms.tasks.TaskCompletionSource.getTask(): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-tasktresult-gettask">https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-tasktresult-gettask</a><br/>
     *
     * @return the return object is Task
     */
    public org.xms.g.tasks.Task<XTResult> getTask() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).getTask()");
        com.google.android.gms.tasks.Task gReturn = ((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).getTask();
        return ((gReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.setException(java.lang.Exception) Completes the Task with the specified exception.<br/>
     * com.google.android.gms.tasks.TaskCompletionSource.setException(java.lang.Exception): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-void-setexception-exception-e">https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-void-setexception-exception-e</a><br/>
     *
     * @param param0 the specified exception
     */
    public void setException(java.lang.Exception param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).setException(param0)");
        ((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).setException(param0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.setResult(XTResult) Completes the Task with the specified result.<br/>
     * com.google.android.gms.tasks.TaskCompletionSource.setResult(TResult): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-void-setresult-tresult-result">https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-void-setresult-tresult-result</a><br/>
     *
     * @param param0 the specified result
     */
    public void setResult(XTResult param0) {
        java.lang.Object gObj0 = ((java.lang.Object) org.xms.g.utils.Utils.getInstanceInInterface(param0, false));
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).setResult(gObj0)");
        ((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).setResult(gObj0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.trySetException(java.lang.Exception) Completes the Task with the specified exception, unless the Task has already completed. If the Task has already completed, the call does nothing.<br/>
     * com.google.android.gms.tasks.TaskCompletionSource.trySetException(java.lang.Exception): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-boolean-trysetexception-exception-e">https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-boolean-trysetexception-exception-e</a><br/>
     *
     * @param param0 the specified exception
     * @return true if the exception was set successfully, false otherwise
     */
    public boolean trySetException(java.lang.Exception param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).trySetException(param0)");
        return ((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).trySetException(param0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.trySetResult(XTResult) Completes the Task with the specified result, unless the Task has already completed. If the Task has already completed, the call does nothing.<br/>
     * com.google.android.gms.tasks.TaskCompletionSource.trySetResult(TResult): <a href="https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-boolean-trysetresult-tresult-result">https://developers.google.com/android/reference/com/google/android/gms/tasks/TaskCompletionSource#public-boolean-trysetresult-tresult-result</a><br/>
     *
     * @param param0 the specified result
     * @return true if the result was set successfully, false otherwise
     */
    public boolean trySetResult(XTResult param0) {
        java.lang.Object gObj0 = ((java.lang.Object) org.xms.g.utils.Utils.getInstanceInInterface(param0, false));
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).trySetResult(gObj0)");
        return ((com.google.android.gms.tasks.TaskCompletionSource) this.getGInstance()).trySetResult(gObj0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.tasks.TaskCompletionSource.<br/>
     *
     * @param param0 the input object
     * @return casted TaskCompletionSource object
     */
    public static org.xms.g.tasks.TaskCompletionSource dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.tasks.TaskCompletionSource) param0);
    }
    
    /**
     * org.xms.g.tasks.TaskCompletionSource.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.tasks.TaskCompletionSource;
    }
}