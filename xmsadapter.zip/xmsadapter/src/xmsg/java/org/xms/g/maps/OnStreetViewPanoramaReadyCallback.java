package org.xms.g.maps;

/**
 * xms Callback interface for when the Street View panorama is ready to be used.<br/>
 * Wrapper class for com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback: Callback interface for when the Street View panorama is ready to be used.<br/>
 */
public interface OnStreetViewPanoramaReadyCallback extends org.xms.g.utils.XInterface {
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama) Callback interface for when the Street View panorama is ready to be used.<br/>
     * com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(com.google.android.gms.maps.StreetViewPanorama): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/OnStreetViewPanoramaReadyCallback#public-abstract-void-onstreetviewpanoramaready-streetviewpanorama-panorama">https://developers.google.com/android/reference/com/google/android/gms/maps/OnStreetViewPanoramaReadyCallback#public-abstract-void-onstreetviewpanoramaready-streetviewpanorama-panorama</a><br/>
     *
     * @param param0 A non-null instance of a StreetViewPanorama associated with the StreetViewPanoramaFragment or StreetViewPanoramaView that defines the callback
     */
    public void onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama param0);
    
    default java.lang.Object getZInstanceOnStreetViewPanoramaReadyCallback() {
        return getGInstanceOnStreetViewPanoramaReadyCallback();
    }
    
    default com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback getGInstanceOnStreetViewPanoramaReadyCallback() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback) ((org.xms.g.utils.XGettable) this).getGInstance());
        }
        return new com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback() {
            
            public void onStreetViewPanoramaReady(com.google.android.gms.maps.StreetViewPanorama param0) {
                org.xms.g.maps.OnStreetViewPanoramaReadyCallback.this.onStreetViewPanoramaReady(((param0) == null ? null : (new org.xms.g.maps.StreetViewPanorama(new org.xms.g.utils.XBox(param0)))));
            }
        };
    }
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.OnStreetViewPanoramaReadyCallback.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps OnStreetViewPanoramaReadyCallback object
     */
    public static org.xms.g.maps.OnStreetViewPanoramaReadyCallback dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.OnStreetViewPanoramaReadyCallback) param0);
    }
    
    /**
     * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
        }
        return param0 instanceof org.xms.g.maps.OnStreetViewPanoramaReadyCallback;
    }
    
    /**
     * xms Callback interface for when the Street View panorama is ready to be used.<br/>
     * Wrapper class for com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback, but only the GMS API are provided.<br/>
     * com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback: Callback interface for when the Street View panorama is ready to be used.<br/>
     */
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.maps.OnStreetViewPanoramaReadyCallback {
        
        /**
         * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.XImpl.XImpl(org.xms.g.utils.XBox) constructor of XImpl .<br/>
         *
         * @param param0 this param is utils XBox
         */
        public XImpl(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.OnStreetViewPanoramaReadyCallback.XImpl.onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama) Callback interface for when the Street View panorama is ready to be used.<br/>
         * com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback.onStreetViewPanoramaReady(com.google.android.gms.maps.StreetViewPanorama): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/OnStreetViewPanoramaReadyCallback#public-abstract-void-onstreetviewpanoramaready-streetviewpanorama-panorama">https://developers.google.com/android/reference/com/google/android/gms/maps/OnStreetViewPanoramaReadyCallback#public-abstract-void-onstreetviewpanoramaready-streetviewpanorama-panorama</a><br/>
         *
         * @param param0 A non-null instance of a StreetViewPanorama associated with the StreetViewPanoramaFragment or StreetViewPanoramaView that defines the callback
         */
        public void onStreetViewPanoramaReady(org.xms.g.maps.StreetViewPanorama param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback) this.getGInstance()).onStreetViewPanoramaReady(((com.google.android.gms.maps.StreetViewPanorama) ((param0) == null ? null : (param0.getGInstance()))))");
            ((com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback) this.getGInstance()).onStreetViewPanoramaReady(((com.google.android.gms.maps.StreetViewPanorama) ((param0) == null ? null : (param0.getGInstance()))));
        }
    }
}