package org.xms.g.common;

/**
 * Indicates services is not available.<br/>
 * Wrapper class for com.google.android.gms.common.GooglePlayServicesNotAvailableException, but only the GMS API are provided.<br/>
 * com.google.android.gms.common.GooglePlayServicesNotAvailableException: Indicates Google Play services is not available.<br/>
 */
public final class ExtensionPlayServicesNotAvailableException extends java.lang.Exception implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.ExtensionPlayServicesNotAvailableException(org.xms.g.utils.XBox) constructor of ExtensionPlayServicesNotAvailableException with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public ExtensionPlayServicesNotAvailableException(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.ExtensionPlayServicesNotAvailableException(int) constructor of ExtensionPlayServicesNotAvailableException.<br/>
     * com.google.android.gms.common.GooglePlayServicesNotAvailableException.GooglePlayServicesNotAvailableException(int): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/GooglePlayServicesNotAvailableException#public-googleplayservicesnotavailableexception-int-errorcode">https://developers.google.com/android/reference/com/google/android/gms/common/GooglePlayServicesNotAvailableException#public-googleplayservicesnotavailableexception-int-errorcode</a><br/>
     *
     * @param param0 the errorCode
     */
    public ExtensionPlayServicesNotAvailableException(int param0) {
        this.setGInstance(new com.google.android.gms.common.GooglePlayServicesNotAvailableException(param0));
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.getErrorCode() return the value of errorCode.<br/>
     * com.google.android.gms.common.GooglePlayServicesNotAvailableException.ErrorCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/common/GooglePlayServicesNotAvailableException#public-final-int-errorcode">https://developers.google.com/android/reference/com/google/android/gms/common/GooglePlayServicesNotAvailableException#public-final-int-errorcode</a><br/>
     *
     * @return the ErrorCode
     */
    public int getErrorCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.GooglePlayServicesNotAvailableException) this.getGInstance()).errorCode");
        return ((com.google.android.gms.common.GooglePlayServicesNotAvailableException) this.getGInstance()).errorCode;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.common.ExtensionPlayServicesNotAvailableException.<br/>
     *
     * @param param0 the input object
     * @return casted ExtensionPlayServicesNotAvailableException object
     */
    public static org.xms.g.common.ExtensionPlayServicesNotAvailableException dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.ExtensionPlayServicesNotAvailableException) param0);
    }
    
    /**
     * org.xms.g.common.ExtensionPlayServicesNotAvailableException.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.GooglePlayServicesNotAvailableException;
    }
}