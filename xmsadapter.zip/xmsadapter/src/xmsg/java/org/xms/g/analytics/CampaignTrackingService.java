package org.xms.g.analytics;

/**
 * This Service is no longer invoked. Campaign tracking happens in the receiver only. Remains for compatibility reasons.<br/>
 * Wrapper class for com.google.android.gms.analytics.CampaignTrackingService, but only the GMS API are provided.<br/>
 * com.google.android.gms.analytics.CampaignTrackingService: This Service is no longer invoked. Campaign tracking happens in the receiver only. Remains for compatibility reasons.<br/>
 */
public class CampaignTrackingService extends android.app.Service implements org.xms.g.utils.XGettable {
    public java.lang.Object gInstance;
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.CampaignTrackingService(org.xms.g.utils.XBox) constructor of CampaignTrackingService with XBox.<br/>
     *
     * @param param0 the wrapper of xms instance
     */
    public CampaignTrackingService(org.xms.g.utils.XBox param0) {
        if (param0 == null) {
            return;
        }
        this.setGInstance(param0.getGInstance());
    }
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.CampaignTrackingService() constructor of CampaignTrackingService.<br/>
     * com.google.android.gms.analytics.CampaignTrackingService.CampaignTrackingService(): <a href="https://developers.google.com/android/reference/com/google/android/gms/analytics/CampaignTrackingService#public-campaigntrackingservice">https://developers.google.com/android/reference/com/google/android/gms/analytics/CampaignTrackingService#public-campaigntrackingservice</a><br/>
     *
     */
    public CampaignTrackingService() {
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public android.os.IBinder onBind(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.setGInstance(java.lang.Object) set the gms instance for the corresponding xms instance.<br/>
     *
     * @param param0 the instance of gms
     */
    public void setGInstance(java.lang.Object param0) {
        this.gInstance = param0;
    }
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.getGInstance() get the gms instance from the corresponding xms instance.<br/>
     *
     * @return the instance of gms
     */
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.analytics.CampaignTrackingService.<br/>
     *
     * @param param0 the input object
     * @return casted CampaignTrackingService object
     */
    public static org.xms.g.analytics.CampaignTrackingService dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.analytics.CampaignTrackingService.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}