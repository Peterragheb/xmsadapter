package org.xms.g.maps.model;

/**
 * xms An immutable class representing a latitude/longitude aligned rectangle.<br/>
 * Wrapper class for com.google.android.gms.maps.model.LatLngBounds, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.LatLngBounds: An immutable class representing a latitude/longitude aligned rectangle.<br/>
 */
public final class LatLngBounds extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.google.android.gms.maps.model.LatLngBounds.CREATOR: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.LatLngBounds createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.maps.model.LatLngBounds gReturn = com.google.android.gms.maps.model.LatLngBounds.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn));
        }
        
        public org.xms.g.maps.model.LatLngBounds[] newArray(int param0) {
            return new org.xms.g.maps.model.LatLngBounds[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.LatLngBounds.LatLngBounds(org.xms.g.utils.XBox) An immutable class representing a latitude/longitude aligned rectangle.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.LatLngBounds(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public LatLngBounds(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.LatLngBounds(org.xms.g.maps.model.LatLng,org.xms.g.maps.model.LatLng) An immutable class representing a latitude/longitude aligned rectangle.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.LatLngBounds(com.google.android.gms.maps.model.LatLng,com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlngbounds-latlng-southwest,-latlng-northeast">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlngbounds-latlng-southwest,-latlng-northeast</a><br/>
     *
     * @param param0 southwest corner
     * @param param1 northeast corner
     */
    public LatLngBounds(org.xms.g.maps.model.LatLng param0, org.xms.g.maps.model.LatLng param1) {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.LatLngBounds(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.maps.model.LatLng) ((param1) == null ? null : (param1.getGInstance())))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.getNortheast() Northeast corner of the bound.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.northeast: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-final-latlng-northeast">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-final-latlng-northeast</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getNortheast() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).northeast");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).northeast;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.getSouthwest() Southwest corner of the bound.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.southwest: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-final-latlng-southwest">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-final-latlng-southwest</a><br/>
     *
     * @return the return object is maps model LatLng
     */
    public org.xms.g.maps.model.LatLng getSouthwest() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).southwest");
        com.google.android.gms.maps.model.LatLng gReturn = null;
        gReturn = ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).southwest;
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.builder() Creates a new builder.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-static-latlngbounds.builder-builder">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-static-latlngbounds.builder-builder</a><br/>
     *
     * @return the return object is maps model LatLngBounds Builder
     */
    public static final org.xms.g.maps.model.LatLngBounds.Builder builder() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.maps.model.LatLngBounds.builder()");
        com.google.android.gms.maps.model.LatLngBounds.Builder gReturn = com.google.android.gms.maps.model.LatLngBounds.builder();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds.Builder(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.contains(org.xms.g.maps.model.LatLng) Checks whether a LatLngBounds object contains a specified location.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.contains(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-boolean-contains-latlng-point">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-boolean-contains-latlng-point</a><br/>
     *
     * @param param0 the LatLng to test
     * @return true if this contains the given point; false if not
     */
    public final boolean contains(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).contains(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        return ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).contains(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.createFromAttributes(android.content.Context,android.util.AttributeSet) Creates a LatLngBounds object using specified attributes.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.createFromAttributes(android.content.Context,android.util.AttributeSet): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-static-latlngbounds-createfromattributes-context-context,-attributeset-attrs">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-static-latlngbounds-createfromattributes-context-context,-attributeset-attrs</a><br/>
     *
     * @param param0 the param should instanceof android content Context
     * @param param1 the param should instanceof android util AttributeSet
     * @return the return object is maps model LatLngBounds
     */
    public static final org.xms.g.maps.model.LatLngBounds createFromAttributes(android.content.Context param0, android.util.AttributeSet param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.maps.model.LatLngBounds.createFromAttributes(param0, param1)");
        com.google.android.gms.maps.model.LatLngBounds gReturn = com.google.android.gms.maps.model.LatLngBounds.createFromAttributes(param0, param1);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.equals(java.lang.Object) equals.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.equals(java.lang.Object): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-boolean-equals-object-o">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-boolean-equals-object-o</a><br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return the return object is boolean
     */
    public final boolean equals(java.lang.Object param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).equals(param0)");
        return ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).equals(param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.getCenter() Obtains the center of a longitude/latitude bounding box.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.getCenter(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlng-getcenter">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlng-getcenter</a><br/>
     *
     * @return A LatLng that is the center of the LatLngBounds
     */
    public final org.xms.g.maps.model.LatLng getCenter() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).getCenter()");
        com.google.android.gms.maps.model.LatLng gReturn = ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).getCenter();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.hashCode() hash Code.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.hashCode(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-int-hashcode">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-int-hashcode</a><br/>
     *
     * @return the return object is int
     */
    public final int hashCode() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).hashCode()");
        return ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).hashCode();
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.including(org.xms.g.maps.model.LatLng) Obtains a LatLngBounds object that contains a specified location.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.including(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlngbounds-including-latlng-point">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-latlngbounds-including-latlng-point</a><br/>
     *
     * @param param0 a LatLng to be included in the new bounds
     * @return A new LatLngBounds that contains this and the extra point
     */
    public final org.xms.g.maps.model.LatLngBounds including(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).including(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.LatLngBounds gReturn = ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).including(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.toString() to String.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.toString(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-string-tostring">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-string-tostring</a><br/>
     *
     * @return the return object is java lang String
     */
    public final java.lang.String toString() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).toString()");
        return ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).toString();
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.writeToParcel(android.os.Parcel,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-void-writetoparcel-parcel-out,-int-flags">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds#public-void-writetoparcel-parcel-out,-int-flags</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).writeToParcel(param0, param1)");
        ((com.google.android.gms.maps.model.LatLngBounds) this.getGInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.LatLngBounds.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model LatLngBounds object
     */
    public static org.xms.g.maps.model.LatLngBounds dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.LatLngBounds) param0);
    }
    
    /**
     * org.xms.g.maps.model.LatLngBounds.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.LatLngBounds;
    }
    
    /**
     * This is a builder that is able to create a minimum bound based on a set of LatLng points.<br/>
     * Wrapper class for com.google.android.gms.maps.model.LatLngBounds.Builder, but only the GMS API are provided.<br/>
     * com.google.android.gms.maps.model.LatLngBounds.Builder: This is a builder that is able to create a minimum bound based on a set of LatLng points.<br/>
     */
    public static final class Builder extends org.xms.g.utils.XObject {
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.Builder(org.xms.g.utils.XBox) This is a builder that is able to create a minimum bound based on a set of LatLng points.<br/>
         * com.google.android.gms.maps.model.LatLngBounds.Builder.Builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder</a><br/>
         *
         * @param param0 the param should instanceof utils XBox
         */
        public Builder(org.xms.g.utils.XBox param0) {
            super(param0);
        }
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.Builder() This is a builder that is able to create a minimum bound based on a set of LatLng points.<br/>
         * com.google.android.gms.maps.model.LatLngBounds.Builder.Builder(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds-build">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds-build</a><br/>
         *
         */
        public Builder() {
            super(((org.xms.g.utils.XBox) null));
            this.setGInstance(new com.google.android.gms.maps.model.LatLngBounds.Builder());
        }
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.build() Creates the LatLng bounds.<br/>
         * com.google.android.gms.maps.model.LatLngBounds.Builder.build(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds-build">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds-build</a><br/>
         *
         * @throws java.lang.IllegalStateException if no points have been included
         * @return the return object is maps model LatLngBounds
         */
        public final org.xms.g.maps.model.LatLngBounds build() {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds.Builder) this.getGInstance()).build()");
            com.google.android.gms.maps.model.LatLngBounds gReturn = ((com.google.android.gms.maps.model.LatLngBounds.Builder) this.getGInstance()).build();
            return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.include(org.xms.g.maps.model.LatLng) Includes this point for building of the bounds. The bounds will be extended in a minimum way to include this point.<br/>
         * com.google.android.gms.maps.model.LatLngBounds.Builder.include(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds.builder-include-latlng-point">https://developers.google.com/android/reference/com/google/android/gms/maps/model/LatLngBounds.Builder#public-latlngbounds.builder-include-latlng-point</a><br/>
         *
         * @param param0 A LatLng to be included in the bounds
         * @return This builder object with a new point added
         */
        public final org.xms.g.maps.model.LatLngBounds.Builder include(org.xms.g.maps.model.LatLng param0) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.LatLngBounds.Builder) this.getGInstance()).include(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
            com.google.android.gms.maps.model.LatLngBounds.Builder gReturn = ((com.google.android.gms.maps.model.LatLngBounds.Builder) this.getGInstance()).include(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLngBounds.Builder(new org.xms.g.utils.XBox(gReturn))));
        }
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.LatLngBounds.Builder.<br/>
         *
         * @param param0 the param should instanceof java lang Object
         * @return cast maps model LatLngBounds Builder object
         */
        public static org.xms.g.maps.model.LatLngBounds.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.maps.model.LatLngBounds.Builder) param0);
        }
        
        /**
         * org.xms.g.maps.model.LatLngBounds.Builder.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
         *
         * @param param0 the input object
         * @return true if the Object is XMS instance, otherwise false
         */
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.LatLngBounds.Builder;
        }
    }
}