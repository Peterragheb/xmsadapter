package org.xms.g.maps.model;

/**
 * xms Defines MarkerOptions for a marker.<br/>
 * Wrapper class for com.google.android.gms.maps.model.MarkerOptions, but only the GMS API are provided.<br/>
 * com.google.android.gms.maps.model.MarkerOptions: Defines MarkerOptions for a marker.<br/>
 */
public final class MarkerOptions extends org.xms.g.utils.XObject implements android.os.Parcelable {
    /**
     * android.os.Parcelable.Creator.CREATOR a public CREATOR field that generates instances of your Parcelable class from a Parcel.<br/>
     * <p>
     * com.google.android.gms.maps.model.MarkerOptions.CREATOR: <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions</a><br/>
     */
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.maps.model.MarkerOptions createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.maps.model.MarkerOptions gReturn = com.google.android.gms.maps.model.MarkerOptions.CREATOR.createFromParcel(param0);
            return new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn));
        }
        
        public org.xms.g.maps.model.MarkerOptions[] newArray(int param0) {
            return new org.xms.g.maps.model.MarkerOptions[param0];
        }
    };
    
    /**
     * org.xms.g.maps.model.MarkerOptions.MarkerOptions(org.xms.g.utils.XBox) Creates a new set of marker options.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.MarkerOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions</a><br/>
     *
     * @param param0 the param should instanceof utils XBox
     */
    public MarkerOptions(org.xms.g.utils.XBox param0) {
        super(param0);
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.MarkerOptions() Creates a new set of marker options.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.MarkerOptions(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions</a><br/>
     *
     */
    public MarkerOptions() {
        super(((org.xms.g.utils.XBox) null));
        this.setGInstance(new com.google.android.gms.maps.model.MarkerOptions());
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.alpha(float) Sets the alpha(opacity)of the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.alpha(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-alpha-float-alpha">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-alpha-float-alpha</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return the object for which the method was called, with the new alpha set
     */
    public final org.xms.g.maps.model.MarkerOptions alpha(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).alpha(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).alpha(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.anchor(float,float) Specifies the anchor to be at a particular point in the marker image.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.anchor(float,float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-anchor-float-u,-float-v">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-anchor-float-u,-float-v</a><br/>
     *
     * @param param0 u-coordinate of the anchor, as a ratio of the image width (in the range [0, 1])
     * @param param1 v-coordinate of the anchor, as a ratio of the image height (in the range [0, 1])
     * @return the object for which the method was called, with the new anchor set
     */
    public final org.xms.g.maps.model.MarkerOptions anchor(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).anchor(param0, param1)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).anchor(param0, param1);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.draggable(boolean) Sets the draggability for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.draggable(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-draggable-boolean-draggable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-draggable-boolean-draggable</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return the object for which the method was called, with the new draggable state set
     */
    public final org.xms.g.maps.model.MarkerOptions draggable(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).draggable(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).draggable(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.flat(boolean) Sets whether this marker should be flat against the map true or a billboard facing the camera false. If the marker is flat against the map, it will remain stuck to the map as the camera rotates and tilts but will still remain the same size as the camera zooms, unlike a GroundOverlay. If the marker is a billboard, it will always be drawn facing the camera and will rotate and tilt with the camera. The default value is false.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.flat(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-flat-boolean-flat">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-flat-boolean-flat</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return the object for which the method was called, with the new flat state set
     */
    public final org.xms.g.maps.model.MarkerOptions flat(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).flat(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).flat(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getAlpha() Gets the alpha set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getAlpha(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getalpha">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getalpha</a><br/>
     *
     * @return the alpha of the marker in the range [0, 1]
     */
    public final float getAlpha() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAlpha()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAlpha();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getAnchorU() Horizontal distance, normalized to[0, 1], of the anchor from the left edge.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getAnchorU(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getanchoru">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getanchoru</a><br/>
     *
     * @return the u value of the anchor
     */
    public final float getAnchorU() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAnchorU()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAnchorU();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getAnchorV() Vertical distance, normalized to[0, 1], of the anchor from the top edge.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getAnchorV(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getanchorv">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getanchorv</a><br/>
     *
     * @return the v value of the anchor
     */
    public final float getAnchorV() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAnchorV()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getAnchorV();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getIcon() Gets the custom icon descriptor set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getIcon(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-bitmapdescriptor-geticon">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-bitmapdescriptor-geticon</a><br/>
     *
     * @return A BitmapDescriptor representing the custom icon, or null if no custom icon is set
     */
    public final org.xms.g.maps.model.BitmapDescriptor getIcon() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getIcon()");
        com.google.android.gms.maps.model.BitmapDescriptor gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getIcon();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.BitmapDescriptor(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getInfoWindowAnchorU() Horizontal distance, normalized to[0, 1], of the info window anchor from the left edge.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getInfoWindowAnchorU(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getinfowindowanchoru">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getinfowindowanchoru</a><br/>
     *
     * @return the u value of the info window anchor
     */
    public final float getInfoWindowAnchorU() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getInfoWindowAnchorU()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getInfoWindowAnchorU();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getInfoWindowAnchorV() Vertical distance, normalized to[0, 1], of the info window anchor from the top edge.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getInfoWindowAnchorV(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getinfowindowanchorv">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getinfowindowanchorv</a><br/>
     *
     * @return the v value of the info window anchor
     */
    public final float getInfoWindowAnchorV() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getInfoWindowAnchorV()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getInfoWindowAnchorV();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getPosition() Returns the position set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getPosition(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-latlng-getposition">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-latlng-getposition</a><br/>
     *
     * @return A LatLng object specifying the marker's current position
     */
    public final org.xms.g.maps.model.LatLng getPosition() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getPosition()");
        com.google.android.gms.maps.model.LatLng gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getPosition();
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.LatLng(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getRotation() Gets the rotation set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getRotation(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getrotation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getrotation</a><br/>
     *
     * @return the rotation of the marker in degrees clockwise from the default position
     */
    public final float getRotation() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getRotation()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getRotation();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getSnippet() Gets the snippet set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getSnippet(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-string-getsnippet">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-string-getsnippet</a><br/>
     *
     * @return A string containing the marker's snippet
     */
    public final java.lang.String getSnippet() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getSnippet()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getSnippet();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getTitle() Gets the title set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getTitle(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-string-gettitle">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-string-gettitle</a><br/>
     *
     * @return A string containing the marker's title
     */
    public final java.lang.String getTitle() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getTitle()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getTitle();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.getZIndex() Gets the zIndex set for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.getZIndex(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getzindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-float-getzindex</a><br/>
     *
     * @return the zIndex of the marker
     */
    public final float getZIndex() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getZIndex()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).getZIndex();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.icon(org.xms.g.maps.model.BitmapDescriptor) Sets the icon for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.icon(com.google.android.gms.maps.model.BitmapDescriptor): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-icon-bitmapdescriptor-icondescriptor">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-icon-bitmapdescriptor-icondescriptor</a><br/>
     *
     * @param param0 if null, the default marker is used
     * @return the object for which the method was called, with the new icon descriptor set
     */
    public final org.xms.g.maps.model.MarkerOptions icon(org.xms.g.maps.model.BitmapDescriptor param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).icon(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).icon(((com.google.android.gms.maps.model.BitmapDescriptor) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.infoWindowAnchor(float,float) Specifies the anchor point of the info window on the marker image. This is specified in the same coordinate system as the anchor. See anchor(float, float)for more details. The default is the top middle of the image.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.infoWindowAnchor(float,float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-infowindowanchor-float-u,-float-v">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-infowindowanchor-float-u,-float-v</a><br/>
     *
     * @param param0 u-coordinate of the info window anchor, as a ratio of the image width (in the range [0, 1])
     * @param param1 v-coordinate of the info window anchor, as a ratio of the image height (in the range [0, 1])
     * @return the object for which the method was called, with the new info window anchor set
     */
    public final org.xms.g.maps.model.MarkerOptions infoWindowAnchor(float param0, float param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).infoWindowAnchor(param0, param1)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).infoWindowAnchor(param0, param1);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.isDraggable() Gets the draggability setting for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.isDraggable(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isdraggable">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isdraggable</a><br/>
     *
     * @return true if the marker is draggable; otherwise, returns false
     */
    public final boolean isDraggable() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isDraggable()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isDraggable();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.isFlat() Gets the flat setting for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.isFlat(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isflat">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isflat</a><br/>
     *
     * @return true if the marker is flat against the map; false if the marker should face the camera
     */
    public final boolean isFlat() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isFlat()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isFlat();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.isVisible() Gets the visibility setting for this MarkerOptions object.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.isVisible(): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isvisible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-boolean-isvisible</a><br/>
     *
     * @return true if the marker is visible; otherwise, returns false
     */
    public final boolean isVisible() {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isVisible()");
        return ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).isVisible();
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.position(org.xms.g.maps.model.LatLng) Sets the location for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.position(com.google.android.gms.maps.model.LatLng): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-position-latlng-latlng">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-position-latlng-latlng</a><br/>
     *
     * @param param0 the param should instanceof maps model LatLng
     * @return the object for which the method was called, with the new position set
     */
    public final org.xms.g.maps.model.MarkerOptions position(org.xms.g.maps.model.LatLng param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).position(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).position(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.rotation(float) Sets the rotation of the marker in degrees clockwise about the marker's anchor point.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.rotation(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-rotation-float-rotation">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-rotation-float-rotation</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return the object for which the method was called, with the new rotation set
     */
    public final org.xms.g.maps.model.MarkerOptions rotation(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).rotation(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).rotation(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.snippet(java.lang.String) Sets the snippet for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.snippet(java.lang.String): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-snippet-string-snippet">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-snippet-string-snippet</a><br/>
     *
     * @param param0 the param should instanceof java lang String
     * @return the object for which the method was called, with the new snippet set
     */
    public final org.xms.g.maps.model.MarkerOptions snippet(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).snippet(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).snippet(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.title(java.lang.String) Sets the title for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.title(java.lang.String): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-title-string-title">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-title-string-title</a><br/>
     *
     * @param param0 the param should instanceof java lang String
     * @return the object for which the method was called, with the new title set
     */
    public final org.xms.g.maps.model.MarkerOptions title(java.lang.String param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).title(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).title(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.visible(boolean) Sets the visibility for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.visible(boolean): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-visible-boolean-visible">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-visible-boolean-visible</a><br/>
     *
     * @param param0 the param should instanceof boolean
     * @return the object for which the method was called, with the new visibility state set
     */
    public final org.xms.g.maps.model.MarkerOptions visible(boolean param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).visible(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).visible(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.writeToParcel(android.os.Parcel,int) writeToParcel.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.writeToParcel(android.os.Parcel,int): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-void-writetoparcel-parcel-out,-int-flags">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-void-writetoparcel-parcel-out,-int-flags</a><br/>
     *
     * @param param0 the param should instanceof android os Parcel
     * @param param1 the param should instanceof int
     */
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).writeToParcel(param0, param1)");
        ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).writeToParcel(param0, param1);
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.zIndex(float) Sets the zIndex for the marker.<br/>
     * com.google.android.gms.maps.model.MarkerOptions.zIndex(float): <a href="https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-zindex-float-zindex">https://developers.google.com/android/reference/com/google/android/gms/maps/model/MarkerOptions#public-markeroptions-zindex-float-zindex</a><br/>
     *
     * @param param0 the param should instanceof float
     * @return the object for which the method was called, with the new zIndex set
     */
    public final org.xms.g.maps.model.MarkerOptions zIndex(float param0) {
        org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).zIndex(param0)");
        com.google.android.gms.maps.model.MarkerOptions gReturn = ((com.google.android.gms.maps.model.MarkerOptions) this.getGInstance()).zIndex(param0);
        return ((gReturn) == null ? null : (new org.xms.g.maps.model.MarkerOptions(new org.xms.g.utils.XBox(gReturn))));
    }
    
    /**
     * XMS does not provide this api.<br/>
     */
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.dynamicCast(java.lang.Object) dynamic cast the input object to org.xms.g.maps.model.MarkerOptions.<br/>
     *
     * @param param0 the param should instanceof java lang Object
     * @return cast maps model MarkerOptions object
     */
    public static org.xms.g.maps.model.MarkerOptions dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.maps.model.MarkerOptions) param0);
    }
    
    /**
     * org.xms.g.maps.model.MarkerOptions.isInstance(java.lang.Object) judge whether the Object is XMS instance or not.<br/>
     *
     * @param param0 the input object
     * @return true if the Object is XMS instance, otherwise false
     */
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.maps.model.MarkerOptions;
    }
}